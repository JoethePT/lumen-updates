// The player: one shared <video> that can sit in a preview window or fill the screen,
// with zapping, number entry, catch-up, tracks, sleep timer, stats and next-episode.
import { h, add, clear, fmtClock, fmtDur, toast, logoTile, srtToVtt } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import { Engine } from '../player.js';
import { hasNative, NativeVideo, NativeEngine, nativeLayout, nativePrefs } from '../native.js';
import { net } from '../net.js';
import {
  S, nowNext, recordPlay, savePosition, getPosition, isFav, toggleFav, canCatchup, catchupUrl,
  setSetting, lookup, recentChannels, ensureGuide, bus, alternatesOf, getAccount,
} from '../store.js';
import { xtreamAccount } from '../xtream.js';
import { castAvailable, chooseAndCast } from '../cast.js';
import { menu, openLayer, channelRow, unlockIfNeeded } from './common.js';
import { VList } from '../vlist.js';

const stage = document.getElementById('stage');
// On the Android TV app the picture comes from the native player; elsewhere from <video>.
const native = hasNative();
const video = native ? new NativeVideo() : document.getElementById('video');
const engine = native ? new NativeEngine(video) : new Engine(video);
if (native) document.documentElement.classList.add('has-native');

const ui = h('div.pui',
  h('div.scrim-top'), h('div.scrim-bot'),
  h('div.top'), h('div.bottom'),
  h('div.pstate'),
);
stage.append(ui);
const top = ui.querySelector('.top');
const bottom = ui.querySelector('.bottom');
const pstate = ui.querySelector('.pstate');

const P = {
  item: null, list: [], mode: 'hidden', anchor: null, catchup: null, lastLive: null,
  idleT: 0, zapT: 0, numBuf: '', numT: 0, sleepAt: 0, sleepT: 0, statsOn: false, statsT: 0,
  retries: 0, stallT: 0, saveT: 0, nextUpT: 0, onExit: null, layerOn: false, speed: 1,
};

function engineOpts() {
  engine.opts = { lowLatency: S.settings.lowLatency, prefer: S.settings.engine };
  if (native) nativePrefs(S.settings.audioLang, S.settings.subLang, S.settings.videoOutput);
}

// Native subtitles arrive as text and are drawn by the interface.
const subsEl = h('div.native-subs');
if (native) {
  ui.append(subsEl);
  video.addEventListener('cues', (e) => { subsEl.textContent = e.text; subsEl.hidden = !e.text; });
}

// ---------- placement ----------
let ro;
function placeMini() {
  if (!P.anchor || !P.anchor.isConnected) return;
  const r = P.anchor.getBoundingClientRect();
  stage.style.setProperty('--sx', r.left + 'px');
  stage.style.setProperty('--sy', r.top + 'px');
  stage.style.setProperty('--sw', r.width + 'px');
  stage.style.setProperty('--sh', r.height + 'px');
  stage.style.setProperty('--sr', getComputedStyle(P.anchor).borderRadius);
  stage.classList.toggle('offscreen', r.bottom < 0 || r.top > innerHeight);
  // The native picture covers the page, so only show it once video is on screen.
  if (native) nativeLayout(r.bottom < 0 || r.top > innerHeight || video.readyState < 4 ? 'hidden' : 'mini', P.anchor, S.settings.aspect, parseFloat(getComputedStyle(P.anchor).borderTopLeftRadius) || 0);
}
window.addEventListener('resize', () => { if (P.mode === 'mini') placeMini(); });

function setMode(mode) {
  P.mode = mode;
  stage.hidden = mode === 'hidden';
  stage.classList.toggle('mini', mode === 'mini');
  stage.classList.toggle('full', mode === 'full');
  stage.dataset.aspect = S.settings.aspect;
  if (mode === 'full') {
    if (!P.layerOn) { nav.push(ui, back); P.layerOn = true; }
    requestAnimationFrame(() => wake(true));
  } else if (P.layerOn) {
    P.layerOn = false;
    nav.pop(ui, true);
  }
  if (mode === 'mini') placeMini();
  else if (native) nativeLayout(mode, null, S.settings.aspect);
  if (mode !== 'full') closeSide();
}

// ---------- loading ----------
async function load(item, startAt = 0, url) {
  engineOpts();
  P.retries = 0;
  showState('loading');
  const live = item.type === 'live' && !P.catchup;
  const ok = await engine.load({ url: url || item.url, ua: item.ua, ref: item.ref, live }, startAt);
  if (ok && P.item === item) {
    showState(null);
    video.playbackRate = live ? 1 : P.speed;
    applyPrefs();
  }
}

engine.on('fatal', (msg) => {
  // Without the relay, retrying a stream the browser isn't allowed to load can't succeed.
  if (window.LUMEN_PREVIEW) { showState('preview'); return; }
  if (!net.relay && !native) { showState('error', 'This channel doesn\'t allow browsers to play it directly. Start Lumen with node server.js and open the address it prints, so the stream can be relayed.'); return; }
  const permanent = /\((403|404|410|451)\)/.test(msg);
  // A provider account refusing a stream (403) is usually about the account, not the channel:
  // its stream limit is in use, or the subscription changed. Ask the provider before deciding.
  if (/\((401|403)\)/.test(msg) && P.item && getAccount(P.item.pl)) { explainRefusal(msg); return; }
  P.lastDetail = '';
  if (permanent && P.item && P.item.type === 'live') markUnavailable(P.item.id);
  // With a backup available, retry once rather than twice: a working copy beats waiting on a dead one.
  const tries = nextBackup() ? 1 : 2;
  if (!permanent && P.item && P.item.type === 'live' && !P.catchup && S.settings.reconnect && P.retries < tries) {
    const wait = [3, 6, 10][P.retries++];
    showState('retry', msg, wait);
    clearTimeout(P.stallT);
    P.stallT = setTimeout(() => P.item && reload(), wait * 1000);
    return;
  }
  if (failover()) return;
  const n = P.tried ? P.tried.size : 1;
  showState('error', n > 1 ? `None of the ${n} versions of ${(P.home || P.item).name} responded. ${msg}` : msg);
});

// ---------- refused by the provider (403) ----------
async function explainRefusal(msg) {
  const item = P.item;
  // The player says which request was refused ("request 2, to the provider link …"); keep it to show.
  const where = /\((request [^)]*)\)/.exec(msg);
  P.lastDetail = where ? where[1] : '';
  const unauthorised = /\(401\)/.test(msg);
  showState('retry-plain', 'Checking your subscription with the provider…');
  let u = null;
  try { u = await xtreamAccount(getAccount(item.pl)); } catch {}
  if (P.item !== item) return;
  const plName = (S.playlists.find((p) => p.id === item.pl) || {}).name || 'your provider';
  // Some providers hold your stream for about two minutes after it stops, and stop answering
  // account checks meanwhile. Wait it out rather than calling the channel blocked.
  const held = (detail) => {
    P.busyTries = (P.busyTries || 0) + 1;
    const waits = [30, 45, 60];
    if (P.busyTries > waits.length) return showState('error', `${plName} is still refusing new streams. ${detail} Stop playback on any other device using this login, wait two minutes, then try again.`);
    const wait = waits[P.busyTries - 1];
    showState('retry', `${detail} ${plName} usually lets go about two minutes after a stream stops.`, wait);
    clearTimeout(P.stallT);
    P.stallT = setTimeout(() => { if (P.item === item) reload(); }, wait * 1000);
  };
  if (!u) return held('Your one stream is probably still held by the provider, from the last thing you watched or another device.');
  if (u) {
    const exp = Number(u.exp_date) * 1000;
    if (Number(u.auth) === 0) return showState('error', `${plName} didn’t accept your login. If extending your subscription gave you new details, update them in Settings → Playlists.`);
    if (u.status && u.status !== 'Active') return showState('error', `${plName} says your subscription is “${u.status}”. Check with your provider.`);
    if (exp && exp < Date.now()) return showState('error', `Your ${plName} subscription ended on ${new Date(exp).toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' })}. Once it’s renewed, this plays again.`);
    // 401 is how providers refuse while your one stream is still held, even when their account
    // service already says nothing is playing. Wait for it rather than calling the stream blocked.
    if (unauthorised) return held('Your one stream is still held by the provider, from the last thing you watched or another device.');
    const max = Number(u.max_connections) || 0, used = Number(u.active_cons) || 0;
    if (max && used >= max) {
      // The stream limit is taken: another device, or the last channel hasn't been let go yet.
      // Providers free it within seconds, so wait and try again instead of giving up.
      const many = max === 1 ? 'one stream at a time' : `${max} streams at a time`;
      return held(`${plName} allows ${many} and ${used >= 2 ? 'they are' : 'it’s'} in use, on another device or by what you just watched.`);
    }
  }
  // The account is fine (or couldn't be checked): this stream itself is refused.
  if (item.type === 'live') markUnavailable(item.id);
  if (failover()) return;
  showState('error', msg);
}

// ---------- backup streams ----------
// Providers list most channels several times (HD, FHD, SD, [BK] backups). When the one you're
// watching fails, play the next copy instead of stopping. P.home is the channel you chose;
// P.item is the copy actually playing.
function nextBackup() {
  if (!S.settings.autoBackup || !P.item || P.item.type !== 'live' || P.catchup) return null;
  const tried = P.tried || new Set();
  return alternatesOf(P.home || P.item).find((c) => !tried.has(c.id) && c.id !== P.item.id) || null;
}
function failover() {
  const alt = nextBackup();
  if (!alt) return false;
  (P.tried ||= new Set()).add(P.item.id);
  P.tried.add(alt.id);
  const from = P.item;
  playVersion(alt);
  showState('switch', `${from.name} isn't responding. Trying ${alt.name}.`);
  P.switched = true;
  return true;
}
// Play another copy of the current channel, keeping your place in the channel list.
function playVersion(ch) {
  clearTimeout(P.stallT);
  P.item = ch;
  prefsApplied = false;
  ensureGuide(ch);
  if (P.mode === 'full') buildChrome();
  load(ch);
}
function versionsMenu(anchor) {
  const home = P.home || P.item;
  const all = [home, ...alternatesOf(home)];
  menu(anchor, 'Versions of this channel', all.map((c) => ({
    label: c.name + (c === home ? ' · your pick' : ''), on: c.id === P.item.id,
    run: () => { if (c.id !== P.item.id) { (P.tried ||= new Set()).add(c.id); playVersion(c); } },
  })), { dark: true });
}
engine.on('fatal-runtime', () => { if (P.item) reload(); });
engine.on('blocked', () => showState('blocked'));
// Let error messages in the preview window show instead of a black native picture.
document.addEventListener('lumen:native-error', () => { if (P.mode === 'mini') placeMini(); });
engine.on('tracks', () => applyPrefs());

// Channels that refused or were offline recently get a "Not available here" tag in lists.
function markUnavailable(id) {
  try {
    const m = JSON.parse(localStorage.getItem('lumen.unavailable') || '{}');
    m[id] = Date.now();
    localStorage.setItem('lumen.unavailable', JSON.stringify(m));
  } catch {}
}

function clearUnavailable(id) {
  try {
    const m = JSON.parse(localStorage.getItem('lumen.unavailable') || '{}');
    if (m[id]) { delete m[id]; localStorage.setItem('lumen.unavailable', JSON.stringify(m)); }
  } catch {}
}

function reload() {
  const pos = P.item && P.item.type !== 'live' ? video.currentTime : 0;
  const retries = P.retries;
  const url = P.catchup ? catchupUrl(P.item, P.catchup) : P.item.url;
  load(P.item, pos, url).then(() => { P.retries = retries; });
}

let prefsApplied = false;
function applyPrefs() {
  if (prefsApplied) return;
  const { audioLang, subLang } = S.settings;
  if (audioLang) {
    const t = engine.audioTracks().find((a) => (a.lang || '').toLowerCase().startsWith(audioLang));
    if (t) engine.setAudio(t.id);
  }
  if (subLang) {
    const t = engine.subTracks().find((a) => (a.lang || '').toLowerCase().startsWith(subLang));
    if (t) engine.setSub(t.id);
  }
  prefsApplied = engine.audioTracks().length > 0 || engine.subTracks().length > 0;
}

video.addEventListener('waiting', () => {
  if (!P.item) return;
  clearTimeout(P.stallT);
  P.stallT = setTimeout(() => {
    if (!(P.item && P.item.type === 'live' && !P.catchup && S.settings.reconnect)) return;
    // A second stall within a minute and a half means this copy is struggling: try a backup.
    const now = Date.now();
    P.stalls = P.lastStall && now - P.lastStall < 90000 ? (P.stalls || 0) + 1 : 1;
    P.lastStall = now;
    if (P.stalls >= 2 && failover()) { P.stalls = 0; return; }
    reload();
  }, 12000);
});
video.addEventListener('playing', () => {
  if (P.switched && P.item) { P.switched = false; toast(`Playing ${P.item.name} instead`); }
  clearTimeout(P.stallT); showState(null); P.retries = 0; P.busyTries = 0;
  // It plays here after all: drop any "Not available here" tag from an earlier refusal.
  if (P.item) clearUnavailable(P.item.id); paintPlay(); if (native && P.mode === 'mini') placeMini(); });
if (native) video.addEventListener('loadeddata', () => { if (P.mode === 'mini') placeMini(); });
video.addEventListener('pause', paintPlay);
video.addEventListener('ended', () => {
  if (!P.item) return;
  if (P.item.type === 'live' && !P.catchup) return reload();
  savePosition(P.item, video.duration || 0, video.duration || 0);
  nextUp(true);
});
video.addEventListener('timeupdate', () => {
  paintSeek();
  if (!P.item || P.item.type === 'live') return;
  const now = Date.now();
  if (now - P.saveT > 5000 && video.duration && isFinite(video.duration)) {
    P.saveT = now;
    savePosition(P.item, video.currentTime, video.duration);
  }
  if (video.duration && video.duration - video.currentTime < 25 && video.duration > 300) nextUp(false);
});

function showState(kind, msg, wait) {
  clear(pstate);
  if (!kind) return;
  if (kind === 'loading') { pstate.append(h('div.spinner.lg')); return; }
  if (kind === 'blocked') {
    pstate.append(h('div.card.glass-strong', h('h3', 'Ready to play'), h('p', 'Your browser needs a tap before sound can start.'),
      h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => { video.play(); showState(null); } }, icon('play'), 'Play')));
    if (P.mode === 'full') nav.focusFirst(pstate);
    return;
  }
  if (kind === 'preview') {
    pstate.append(h('div.card.glass-strong', h('h3', 'Video is off in this preview'),
      h('p', 'This preview page blocks video from other sites. Run Lumen with node server.js on your computer or TV box to watch.'),
      P.mode === 'full' ? h('button.btn.btn-primary', { 'data-autofocus': '', onclick: leave, style: { marginTop: '.6rem' } }, 'Close') : null));
    if (P.mode === 'full') nav.focusFirst(pstate);
    return;
  }
  if (kind === 'retry-plain') {
    pstate.append(h('div.card.glass-strong', h('div.spinner'), h('p', msg)));
    return;
  }
  if (kind === 'switch') {
    pstate.append(h('div.card.glass-strong', h('div.spinner'), h('h3', 'Switching to a backup'), h('p', msg)));
    return;
  }
  const detail = P.lastDetail ? h('p.state-detail', 'Details: refused on ' + P.lastDetail) : null;
  if (kind === 'retry') {
    pstate.append(h('div.card.glass-strong', h('div.spinner'), h('h3', 'Reconnecting'), h('p', `${msg} Trying again in ${wait} seconds.`), detail));
    return;
  }
  pstate.append(h('div.card.glass-strong',
    h('h3', P.item && P.item.type === 'live' ? "This channel isn't responding" : "This title won't play"),
    h('p', (msg || 'The stream could not be loaded.').replace(/ \((request [^)]*)\)/, '')),
    detail,
    h('div.row', { style: { justifyContent: 'center', marginTop: '.6rem' } },
      P.item && P.item.type === 'live' && !P.catchup && P.list.length > 1 ? h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => zap(1) }, icon('chUp'), 'Next channel') : null,
      h('button.btn' + (P.item && P.item.type === 'live' && P.list.length > 1 ? '' : '.btn-primary'), { 'data-autofocus': P.item && P.item.type === 'live' && P.list.length > 1 ? null : '', onclick: () => reload() }, icon('refresh'), 'Try again'),
      P.mode === 'full' ? h('button.btn', { onclick: close }, 'Close') : null,
    )));
  if (P.mode === 'full') nav.focusFirst(pstate);
}

// ---------- chrome ----------
function cbtn(ic, tip, fn, cls = '') {
  return h('button.cbtn' + cls, { 'data-tip': tip, 'aria-label': tip, onclick: (e) => { e.stopPropagation(); fn(e.currentTarget); } }, icon(ic));
}

let playBtn, seekbar, seekPos, seekBuf, seekKnob, tCur, tEnd, liveBar;
function paintPlay() {
  if (!playBtn) return;
  playBtn.replaceChildren(icon(video.paused ? 'play' : 'pause'));
}

function isSeekable() { return P.item && (P.item.type !== 'live' || P.catchup); }

function paintSeek() {
  if (P.mode !== 'full' || !P.item) return;
  if (isSeekable() && seekbar) {
    const d = video.duration;
    const total = isFinite(d) && d ? d : (P.catchup ? (P.catchup[1] - P.catchup[0]) / 1000 : 0);
    const c = video.currentTime;
    const pct = total ? Math.min(100, (c / total) * 100) : 0;
    seekPos.style.width = pct + '%';
    seekKnob.style.left = pct + '%';
    let b = 0;
    for (let i = 0; i < video.buffered.length; i++) if (video.buffered.start(i) <= c + 1) b = video.buffered.end(i);
    seekBuf.style.width = total ? Math.min(100, (b / total) * 100) + '%' : '0';
    if (P.catchup) {
      tCur.textContent = fmtClock(P.catchup[0] + c * 1000);
      tEnd.textContent = fmtClock(P.catchup[1]);
    } else {
      tCur.textContent = fmtDur(c);
      tEnd.textContent = '-' + fmtDur(Math.max(0, total - c));
    }
  } else if (liveBar) {
    const { now, p } = nowNext(P.item);
    liveBar.style.width = (now ? p * 100 : 0) + '%';
  }
}

function buildChrome() {
  const it = P.item;
  clear(top); clear(bottom);
  const live = it.type === 'live';
  const title = live ? it.name : it.ep ? it.ep.show : it.name;
  add(top, 
    live ? logoTile(it.name, it.logo) : null,
    h('div', live && S.settings.showNumbers ? h('div.chnum', 'CH ' + it.num) : null, live || it.ep ? h('div.chname', title) : null),
    live && !P.catchup ? h('span.badge.live', 'Live') : null,
    P.catchup ? h('span.badge', icon('rewind'), 'Catch-up') : null,
    h('div.clock', fmtClock(new Date())),
  );

  const info = h('div', { style: { display: 'flex', flexDirection: 'column', gap: '.5rem' } });
  if (live) {
    const prog = P.catchup || nowNext(it).now;
    const nn = nowNext(it);
    add(info, 
      prog ? h('div.ptitle', prog[2]) : h('div.ptitle', { style: { fontSize: '1.4rem', color: 'var(--fg-2)' } }, 'No programme information'),
      h('div.psub',
        prog ? h('span', `${fmtClock(prog[0])} – ${fmtClock(prog[1])}`) : h('span', it.group),
        prog && prog[5] ? h('span', prog[5]) : null,
        !P.catchup && nn.next ? h('span.faint', `Next ${fmtClock(nn.next[0])} · ${nn.next[2]}`) : null),
      prog && prog[3] ? h('div.pdesc', prog[3]) : null,
    );
  } else {
    add(info, 
      h('div.ptitle', it.ep ? (it.ep.title || `Episode ${it.ep.e}`) : it.name),
      h('div.psub', it.ep ? h('span', `Season ${it.ep.s} · Episode ${it.ep.e}`) : null, it.year ? h('span', it.year) : null, h('span', it.group)),
    );
  }
  bottom.append(info);

  seekbar = liveBar = null;
  if (isSeekable()) {
    seekPos = h('div.pos'); seekBuf = h('div.buf'); seekKnob = h('div.knob');
    const tip = h('div.tip');
    seekbar = h('div.seekbar', { tabindex: '0', role: 'slider', 'aria-label': 'Seek' }, seekBuf, seekPos, seekKnob, tip);
    seekbar.addEventListener('click', (e) => {
      const r = seekbar.getBoundingClientRect();
      const d = duration();
      if (d) video.currentTime = ((e.clientX - r.left) / r.width) * d;
    });
    seekbar.addEventListener('mousemove', (e) => {
      const r = seekbar.getBoundingClientRect();
      const f = (e.clientX - r.left) / r.width;
      tip.style.left = f * 100 + '%';
      tip.textContent = P.catchup ? fmtClock(P.catchup[0] + f * duration() * 1000) : fmtDur(f * duration());
    });
    nav.custom(seekbar, (k) => {
      if (k === 'left' || k === 'right') { seekBy(k === 'left' ? -10 : 10); return true; }
      return false;
    });
    tCur = h('span'); tEnd = h('span');
    bottom.append(h('div.seek', tCur, seekbar, tEnd));
  } else if (live) {
    const nn = nowNext(it);
    if (nn.now) {
      liveBar = h('i');
      bottom.append(h('div.seek', h('span', fmtClock(nn.now[0])), h('div.bar', { style: { height: '.36rem', background: 'rgba(255,255,255,.22)' } }, liveBar), h('span', fmtClock(nn.now[1]))));
      liveBar.style.background = '#fff';
    }
  }

  playBtn = cbtn('pause', 'Play / Pause', () => togglePlay(), '.big');
  const ctl = h('div.controls');
  if (isSeekable()) ctl.append(cbtn('back10', 'Back 10 s', () => seekBy(-10)), playBtn, cbtn('fwd10', 'Forward 10 s', () => seekBy(10)));
  else ctl.append(playBtn);
  if (live) ctl.append(cbtn('chDown', 'Previous channel', () => zap(-1)), cbtn('chUp', 'Next channel', () => zap(1)));
  if (live && !P.catchup && it.catchup && nowNext(it).now) ctl.append(cbtn('rewind', 'Start over', () => startOver()));
  if (P.catchup) ctl.append(h('button.btn.btn-sm', { onclick: () => goLive() }, h('span.badge.live', 'Live'), 'Back to live'));
  if (it.ep && nextEpisode()) ctl.append(cbtn('next', 'Next episode', () => playNextEpisode()));
  ctl.append(h('div.sp'));
  if (live) ctl.append(cbtn('list', 'Channels', () => openSide()));
  if (live && !P.catchup && alternatesOf(P.home || it).length) ctl.append(cbtn('server', 'Versions', (b) => versionsMenu(b)));
  // Send to a Chromecast: films carry on from here, channels keep your channel list for
  // switching from the phone. The phone stops playing.
  if (castAvailable()) ctl.append(cbtn('cast', 'Cast', (b) => { const it2 = P.item, at = live ? 0 : video.currentTime || 0, list = live ? P.list : null; chooseAndCast(b, it2, () => { close(); return at; }, list); }));
  ctl.append(
    cbtn('audio', 'Audio', (b) => audioMenu(b)),
    cbtn('cc', 'Subtitles', (b) => subMenu(b)),
    cbtn('quality', 'Quality', (b) => qualityMenu(b)),
    cbtn('aspect', 'Picture', (b) => aspectMenu(b)),
  );
  if (isSeekable()) ctl.append(cbtn('speed', 'Speed', (b) => speedMenu(b)));
  ctl.append(cbtn('moon', 'Sleep timer', (b) => sleepMenu(b), P.sleepAt ? '.on' : ''));
  if (document.pictureInPictureEnabled && !native) ctl.append(cbtn('pip', 'Picture in picture', () => pip()));
  if (live) ctl.append(cbtn('grid', 'Multiview', () => import('./multiview.js').then((m) => { const ch = P.item; close(); m.openMultiview(ch); })));
  ctl.append(
    cbtn(isFav(it.id) ? 'heartFill' : 'heart', 'Favourite', (b) => { const on = toggleFav(it.showId && !live ? it.showId : it.id); b.replaceChildren(icon(on ? 'heartFill' : 'heart')); toast(on ? 'Added to favourites' : 'Removed from favourites'); }),
    cbtn('stats', 'Stream info', (b) => { P.statsOn = !P.statsOn; b.classList.toggle('on', P.statsOn); paintStats(); }, P.statsOn ? '.on' : ''),
    cbtn('fullscreen', 'Full screen', () => toggleFs()),
    cbtn('close', 'Stop and close', () => close()),
  );
  bottom.append(ctl);
  paintPlay();
  paintSeek();
  paintStats();
}

function duration() {
  const d = video.duration;
  if (isFinite(d) && d) return d;
  return P.catchup ? (P.catchup[1] - P.catchup[0]) / 1000 : 0;
}

let seekAcc = 0, seekAccT = 0;
function seekBy(s) {
  if (!isSeekable()) return;
  const now = Date.now();
  seekAcc = now - seekAccT < 600 ? Math.min(seekAcc + 1, 8) : 0;
  seekAccT = now;
  const step = s * (seekAcc > 5 ? 6 : seekAcc > 2 ? 3 : 1);
  video.currentTime = Math.max(0, Math.min(duration() - 1, video.currentTime + step));
  wake();
}

function togglePlay() {
  if (video.paused) video.play().catch(() => {}); else video.pause();
  wake();
}

function wake(focus) {
  ui.classList.remove('idle');
  clearTimeout(P.idleT);
  if (focus && P.mode === 'full' && !ui.contains(document.activeElement)) {
    nav.focus(playBtn || ui.querySelector('.cbtn'), { scroll: false });
  }
  P.idleT = setTimeout(() => {
    if (!video.paused && !document.querySelector('.layer') && !sideEl) ui.classList.add('idle');
  }, 4500);
}
ui.addEventListener('mousemove', () => wake());
ui.addEventListener('click', (e) => { if (e.target === ui || e.target.classList.contains('pstate')) { if (ui.classList.contains('idle')) wake(true); else togglePlay(); } });
ui.addEventListener('dblclick', (e) => { if (e.target === ui) toggleFs(); });
stage.addEventListener('click', () => { if (P.mode === 'mini') full(); });

// ---------- menus ----------
function audioMenu(b) {
  const tracks = engine.audioTracks();
  const items = tracks.map((t) => ({ label: t.label + (t.lang && t.lang !== t.label ? ` (${t.lang})` : ''), on: t.on, run: () => { engine.setAudio(t.id); if (t.lang) setSetting('audioLang', t.lang.toLowerCase().slice(0, 2)); } }));
  items.push({ label: video.muted ? 'Unmute' : 'Mute', on: false, run: () => { video.muted = !video.muted; } });
  if (!tracks.length) items.unshift({ label: 'Default audio', on: true });
  menu(b, 'Audio', items, { dark: true });
}

function subMenu(b) {
  const tracks = engine.subTracks();
  const anyOn = tracks.some((t) => t.on);
  const items = [{ label: 'Off', on: !anyOn, run: () => { engine.setSub(-1); setSetting('subLang', ''); } }];
  for (const t of tracks) items.push({ label: t.label, on: t.on, run: () => { engine.setSub(t.id); if (t.lang) setSetting('subLang', t.lang.toLowerCase().slice(0, 2)); } });
  items.push({ label: 'Load subtitle file…', run: () => pickSubs() });
  items.push({ label: `Text size ${S.settings.subSize}%`, run: () => { const sizes = [80, 100, 125, 150]; const n = sizes[(sizes.indexOf(S.settings.subSize) + 1) % sizes.length]; setSetting('subSize', n); applySubStyle(); } });
  menu(b, 'Subtitles', items, { dark: true });
}

function pickSubs() {
  const inp = h('input', { type: 'file', accept: '.srt,.vtt,text/vtt' });
  inp.onchange = async () => {
    const f = inp.files[0];
    if (!f) return;
    const label = f.name.replace(/\.\w+$/, '');
    let sub;
    try { sub = await engine.addSubFile(srtToVtt(await f.text()), label); } catch (e) { toast(e.message); return; }
    // Remember it for this title, so casting sends it to the Chromecast too.
    if (sub && sub.lan && P.item) { P.subFiles = { id: P.item.id, list: [...(P.subFiles && P.subFiles.id === P.item.id ? P.subFiles.list : []), { url: sub.lan, label }] }; }
    toast('Subtitles loaded');
  };
  inp.click();
}

export function applySubStyle() {
  document.documentElement.style.setProperty('--sub', S.settings.subSize);
  document.documentElement.style.setProperty('--subbg', S.settings.subBg ? 'rgba(0,0,0,.55)' : 'transparent');
}

function qualityMenu(b) {
  const lv = engine.levels();
  const items = [{ label: 'Automatic', on: engine.autoLevel, run: () => engine.setLevel(-1) }];
  for (const l of lv.slice().reverse()) items.push({ label: `${l.label} · ${(l.bitrate / 1e6).toFixed(1)} Mbps`, on: !engine.autoLevel && engine.level === l.id, run: () => engine.setLevel(l.id) });
  if (!lv.length) items[0].label = 'Automatic (single quality stream)';
  menu(b, 'Quality', items, { dark: true });
}

function aspectMenu(b) {
  const opts = [['fit', 'Fit'], ['fill', 'Fill screen'], ['zoom', 'Zoom'], ['stretch', 'Stretch'], ['16:9', '16:9'], ['4:3', '4:3']];
  const items = opts.map(([k, l]) => ({ label: l, on: S.settings.aspect === k, run: () => { setSetting('aspect', k); stage.dataset.aspect = k; if (native) nativeLayout(P.mode, P.mode === 'mini' ? P.anchor : null, k); } }));
  // Green or black picture with sound: some TV boxes need the other way of drawing video.
  if (native && window.LumenNative?.setOutput) {
    const tex = S.settings.videoOutput === 'texture';
    items.push({ label: tex ? 'Video output: Compatibility (switch to Standard)' : 'Green or black picture? Try Compatibility', run: () => { setSetting('videoOutput', tex ? 'surface' : 'texture'); engineOpts(); } });
  }
  menu(b, 'Picture', items, { dark: true });
}

function speedMenu(b) {
  menu(b, 'Speed', [0.5, 0.75, 1, 1.25, 1.5, 2].map((s) => ({ label: s === 1 ? 'Normal' : s + '×', on: P.speed === s, run: () => { P.speed = s; video.playbackRate = s; } })), { dark: true });
}

function sleepMenu(b) {
  const left = P.sleepAt ? Math.max(1, Math.round((P.sleepAt - Date.now()) / 60000)) : 0;
  const opts = [0, 15, 30, 45, 60, 90, 120];
  menu(b, left ? `Sleep timer · ${left} min left` : 'Sleep timer', opts.map((m) => ({
    label: m ? `${m} minutes` : 'Off', on: m === 0 ? !P.sleepAt : false,
    run: () => {
      clearTimeout(P.sleepT);
      P.sleepAt = m ? Date.now() + m * 60000 : 0;
      if (m) {
        P.sleepT = setTimeout(() => { close(); toast('Sleep timer stopped playback'); P.sleepAt = 0; }, m * 60000);
        toast(`Playback stops in ${m} minutes`);
      }
      b.classList.toggle('on', !!m);
    },
  })), { dark: true });
}

async function pip() {
  try {
    if (document.pictureInPictureElement) await document.exitPictureInPicture();
    else await video.requestPictureInPicture();
  } catch { toast('Picture in picture is not available for this stream'); }
}

function toggleFs() {
  try {
    if (document.fullscreenElement) document.exitFullscreen();
    else document.documentElement.requestFullscreen();
  } catch {}
}

let statsEl;
function paintStats() {
  clearInterval(P.statsT);
  if (statsEl) { statsEl.remove(); statsEl = null; }
  if (!P.statsOn || P.mode !== 'full') return;
  const draw = () => {
    const s = engine.stats();
    const rows = [['Engine', s.engine], ['Relay', s.relay], ['Resolution', s.res], ['Bitrate', s.bitrate], ['Bandwidth', s.bandwidth], ['Codecs', s.codec], ['Frame rate', s.fps], ['Buffer', s.buffer], ['Latency', s.latency], ['Dropped frames', s.dropped]];
    const dl = h('dl.stats-card.glass-strong', rows.filter((r) => r[1]).map(([k, v]) => [h('dt', k), h('dd', v)]));
    if (statsEl) statsEl.replaceWith(dl); else ui.append(dl);
    statsEl = dl;
  };
  draw();
  P.statsT = setInterval(draw, 1000);
}

// ---------- zapping & number entry ----------
function zap(dir) {
  if (!P.list.length || !P.item || P.item.type !== 'live') return;
  const at = P.home || P.item;
  let i = P.list.findIndex((c) => c.id === at.id);
  i = (i + dir + P.list.length) % P.list.length;
  tune(P.list[i]);
}

async function tune(ch) {
  if (!(await unlockIfNeeded('live', ch.group))) return;
  if (P.item && P.item.type === 'live') P.lastLive = P.item;
  P.item = ch;
  P.home = ch; P.tried = null; P.switched = false; P.stalls = 0; P.busyTries = 0; P.lastDetail = '';
  P.catchup = null;
  prefsApplied = false;
  ensureGuide(ch);
  recordPlay(ch);
  if (P.mode === 'full') { buildChrome(); showZap(ch); }
  clearTimeout(P.zapT);
  P.zapT = setTimeout(() => load(ch), 280);
  document.dispatchEvent(new CustomEvent('lumen:tuned', { detail: ch }));
}

let zapEl, zapHide;
// The provider's now/next can arrive a moment after you change channel.
bus.on('epg', () => { if (zapEl && zapEl.isConnected && P.item && P.item.type === 'live') showZap(P.item); });
function showZap(ch) {
  if (zapEl) zapEl.remove();
  if (!ui.classList.contains('idle')) return;
  const { now, next, p } = nowNext(ch);
  zapEl = h('div.zap.glass-strong',
    logoTile(ch.name, ch.logo),
    h('div', { style: { minWidth: 0 } },
      h('div.zt', ch.name),
      h('div.zs', now ? `${fmtClock(now[0])}  ${now[2]}` : ch.group),
      next ? h('div.zs.faint', `${fmtClock(next[0])}  ${next[2]}`) : null,
      now ? h('div.bar', h('i', { style: { width: p * 100 + '%' } })) : null),
    S.settings.showNumbers ? h('div.zn', P.positions ? P.list.indexOf(ch) + 1 : ch.num) : null);
  ui.append(zapEl);
  clearTimeout(zapHide);
  zapHide = setTimeout(() => { if (zapEl) { zapEl.remove(); zapEl = null; } }, 4000);
}

let numEl;
function numKey(d) {
  P.numBuf = (P.numBuf + d).slice(-4);
  if (numEl) numEl.remove();
  numEl = h('div.osd-num.glass-strong', P.numBuf);
  ui.append(numEl);
  clearTimeout(P.numT);
  P.numT = setTimeout(() => {
    const n = Number(P.numBuf);
    P.numBuf = '';
    if (numEl) { numEl.remove(); numEl = null; }
    const pool = P.list.length ? P.list : S.live;
    const ch = (P.positions ? pool[n - 1] : pool.find((c) => c.num === n)) || S.live.find((c) => c.num === n);
    if (ch) tune(ch); else toast(`No channel ${n}`);
  }, 1500);
}

// ---------- side channel list ----------
let sideEl, sideList;
function openSide() {
  if (sideEl) return closeSide();
  const list = P.list.length ? P.list : S.live;
  sideList = new VList({
    count: list.length,
    rowHeight: () => Math.round(parseFloat(getComputedStyle(document.documentElement).fontSize) * 4.4),
    render: (i) => channelRow(list[i], { compact: true, playing: P.item && list[i].id === P.item.id, onclick: () => { tune(list[i]); closeSide(); } }),
  });
  sideEl = h('div.side.glass-strong', h('h3', 'Channels'), sideList.el);
  ui.append(sideEl);
  ui.classList.remove('idle');
  nav.push(sideEl, closeSide);
  requestAnimationFrame(() => {
    sideList.layout();
    const i = Math.max(0, list.findIndex((c) => P.item && c.id === P.item.id));
    const el = sideList.scrollToIndex(i);
    if (el) nav.focus(el, { scroll: false });
  });
}
function closeSide() {
  if (!sideEl) return;
  nav.pop(sideEl, true);
  sideList.destroy();
  sideEl.remove(); sideEl = null;
  wake();
}

// ---------- next episode ----------
function nextEpisode() {
  const it = P.item;
  if (!it || !it.ep) return null;
  const show = lookup(it.showId);
  const eps = (show && show.episodes) || (S.meta.get('ser:' + it.showId) || {}).episodes || P.list;
  const sorted = eps.slice().sort((a, b) => a.ep.s - b.ep.s || a.ep.e - b.ep.e);
  const i = sorted.findIndex((e) => e.id === it.id);
  return i >= 0 ? sorted[i + 1] || null : null;
}

function playNextEpisode() {
  const n = nextEpisode();
  if (n) open(n, { list: P.list });
}

let nextEl, nextCount;
function nextUp(ended) {
  const n = nextEpisode();
  if (!n || !S.settings.autoNext) { if (ended) back(); return; }
  if (nextEl) { if (ended && !nextCount) playNextEpisode(); return; }
  let s = ended ? 5 : Math.max(5, Math.round(video.duration - video.currentTime));
  const cnt = h('span');
  nextEl = h('div.nextup.glass-strong',
    h('div.eyebrow', 'Up next'),
    h('div', { style: { fontWeight: 700, fontSize: '1.1rem' } }, `S${n.ep.s} E${n.ep.e}${n.ep.title ? ' · ' + n.ep.title : ''}`),
    h('div.row', h('button.btn.btn-primary.btn-sm', { onclick: () => playNextEpisode() }, icon('play'), 'Play now ', cnt),
      h('button.btn.btn-sm', { onclick: () => { clearInterval(nextCount); nextCount = 0; nextEl.remove(); } }, 'Cancel')));
  ui.append(nextEl);
  ui.classList.remove('idle');
  nav.focusFirst(nextEl);
  cnt.textContent = `(${s})`;
  nextCount = setInterval(() => {
    s--;
    cnt.textContent = `(${s})`;
    if (s <= 0) { clearInterval(nextCount); nextCount = 0; playNextEpisode(); }
  }, 1000);
}
function clearNextUp() { clearInterval(nextCount); nextCount = 0; if (nextEl) { nextEl.remove(); nextEl = null; } }

// ---------- catch-up ----------
function startOver() {
  const { now } = nowNext(P.item);
  if (now) playCatchup(P.item, now);
}

export async function playCatchup(ch, prog, opts = {}) {
  if (!(await unlockIfNeeded('live', ch.group))) return;
  if (!canCatchup(ch, prog) && !(prog[0] <= Date.now() && prog[1] > Date.now() && ch.catchup)) { toast('Catch-up is not available for this programme'); return; }
  clearNextUp();
  P.item = ch;
  P.catchup = prog;
  P.list = opts.list || P.list || [];
  prefsApplied = false;
  setMode('full');
  buildChrome();
  load(ch, 0, catchupUrl(ch, prog));
}

function goLive() {
  P.catchup = null;
  buildChrome();
  load(P.item);
}

// ---------- public api ----------
export async function open(item, opts = {}) {
  const type = item.type === 'live' ? 'live' : item.type === 'movie' ? 'movie' : 'series';
  if (!(await unlockIfNeeded(type, item.group))) return;
  clearNextUp();
  if (P.item && P.item.type === 'live' && item.type === 'live' && P.item.id !== item.id) P.lastLive = P.item;
  const same = P.item && P.item.id === item.id && !P.catchup && engine.src;
  P.item = item;
  P.home = item; P.tried = null; P.switched = false; P.stalls = 0; P.busyTries = 0; P.lastDetail = '';
  if (item.type === 'live') ensureGuide(item);
  P.catchup = null;
  P.list = opts.list || (item.type === 'live' ? S.live : []);
  // From My channels, numbers are positions in your list.
  P.positions = !!opts.positions;
  P.onExit = opts.onExit || null;
  P.speed = 1;
  if (opts.anchor) { P.anchor = opts.anchor; } else if (!opts.keepAnchor) P.anchor = null;
  setMode(opts.mini ? 'mini' : 'full');
  if (P.mode === 'full') buildChrome();
  if (same) return;
  prefsApplied = false;
  recordPlay(item);
  let start = opts.startAt != null ? opts.startAt : 0;
  if (opts.startAt == null && item.type !== 'live' && S.settings.resume) start = getPosition(item.id);
  load(item, start);
}

export function preview(ch, anchor, list) {
  if (!S.settings.previewPlay) return;
  open(ch, { mini: true, anchor, list });
}

export function full() {
  if (!P.item) return;
  setMode('full');
  buildChrome();
}

function back() {
  if (sideEl) return closeSide();
  if (P.mode !== 'full') return;
  if (!ui.classList.contains('idle') && !nextEl && !pstate.firstChild) {
    ui.classList.add('idle');
    return;
  }
  leave();
}

// Leave full screen for good: back to the preview window if there is one, otherwise stop.
// Works at any moment, including while a stream is still loading or retrying.
function leave() {
  if (sideEl) closeSide();
  clearTimeout(P.stallT);
  if (P.anchor && P.anchor.isConnected && P.item && P.item.type === 'live' && !P.catchup) {
    setMode('mini');
    document.dispatchEvent(new CustomEvent('lumen:tuned', { detail: P.item }));
    return;
  }
  close();
}

export function close() {
  clearNextUp();
  if (P.item && P.item.type !== 'live' && video.duration && isFinite(video.duration)) savePosition(P.item, video.currentTime, video.duration);
  engine.stop();
  P.item = null; P.catchup = null; P.anchor = null;
  clearInterval(P.statsT);
  if (statsEl) { statsEl.remove(); statsEl = null; }
  setMode('hidden');
  const cb = P.onExit; P.onExit = null;
  cb && cb();
  document.dispatchEvent(new CustomEvent('lumen:playerclosed'));
}

export function detachMini() {
  if (P.mode === 'mini') close();
}

export function current() { return P.item; }
// Subtitle files loaded for a title this session (their Wi-Fi addresses, for casting).
export function subFilesFor(id) { return P.subFiles && P.subFiles.id === id ? P.subFiles.list : []; }
export function playList() { return P.list || []; }
export function mode() { return P.mode; }
export function refreshMini() { if (P.mode === 'mini') placeMini(); }

// ---------- keys while full screen ----------
nav.onKey((k, e) => {
  if (P.mode !== 'full') return false;
  const topLayer = nav.top();
  if (topLayer && topLayer.el !== ui) return false;
  const idle = ui.classList.contains('idle');
  const live = P.item && P.item.type === 'live' && !P.catchup;

  if (k === 'digit' && live) { numKey(e.key); return true; }
  if (k === 'chup') { if (live) zap(1); return true; }
  if (k === 'chdown') { if (live) zap(-1); return true; }
  if (k === 'playpause' || (k === 'space' && document.activeElement && !document.activeElement.matches('button'))) { togglePlay(); return true; }
  if (k === 'play') { video.play(); return true; }
  if (k === 'pause') { video.pause(); return true; }
  if (k === 'stop') { close(); return true; }
  if (k === 'ff') { seekBy(30); return true; }
  if (k === 'rw') { seekBy(-30); return true; }
  if (k === 'guide' || k === 'green') { if (live) openSide(); return true; }
  if (k === 'yellow' && P.lastLive) { tune(P.lastLive); return true; }
  if (k === 'info' || k === 'blue') { P.statsOn = !P.statsOn; paintStats(); return true; }
  if (e.key === 'm') { video.muted = !video.muted; toast(video.muted ? 'Muted' : 'Sound on', { ms: 1200 }); return true; }
  if (e.key === 'f') { toggleFs(); return true; }

  if (idle) {
    if (k === 'up' || k === 'down') {
      if (live) { zap(k === 'up' ? 1 : -1); return true; }
      wake(true); return true;
    }
    if (k === 'left' || k === 'right') {
      if (isSeekable()) { seekBy(k === 'left' ? -10 : 10); if (seekbar) nav.focus(seekbar, { scroll: false }); return true; }
      if (k === 'left') { openSide(); return true; }
      wake(true); return true;
    }
    if (k === 'enter') { wake(true); return true; }
  }
  if (k && k !== 'back') wake();
  return false;
});

document.addEventListener('lumen:back', () => {});

// Keep the clock in the player chrome current.
setInterval(() => {
  if (P.mode !== 'full') return;
  const c = top.querySelector('.clock');
  if (c) c.textContent = fmtClock(new Date());
  paintSeek();
}, 15000);

export const playerState = P;
export { recentChannels };
