// Keeping Lumen on your phone and TV in step over home Wi-Fi: favourites, Continue watching,
// settings and playlists. The Android app finds and links the devices and passes data between
// linked ones (Sync.java); this works out what changed here, describes each title in a way the
// other device understands, and merges what the other devices send.
//
// Titles can't be sent by id: ids are made from a playlist id that differs on each device. A
// title travels as [playlist, kind, key]: the provider login or link, and the stream's number or
// address, which are the same everywhere. Each change carries the time it was made; the newest
// wins, and removals are remembered so they aren't undone by a device that still has the title.
import { ls, hash, normName, debounce, toast } from './util.js';
import { net } from './net.js';
import {
  S, bus, DEFAULTS, savePlaylists, saveSettings, loadLibrary, refreshPlaylist, removePlaylist, lookup, rememberSnap,
} from './store.js';

// Settings that belong to one device (its screen, how it draws video) aren't shared.
const LOCAL_ONLY = new Set(['uiScale', 'videoOutput', 'engine', 'relay', 'lowLatency', 'previewPlay', 'refreshOnStart', 'countryHint', 'autoBackup']);

export const syncAvailable = () => !!(net.info && net.info.app === 'android');

let meta = ls.get('sync', null) || { set: {}, fav: {}, gone: {}, pl: {}, hist: [] };
const saveMeta = () => ls.set('sync', meta);
const h = (v) => hash(JSON.stringify(v === undefined ? null : v));

// ---------- describing titles ----------

function plKey(pl) {
  if (!pl) return '';
  if (pl.builtin) return 'b:' + pl.builtin;
  if (pl.kind === 'xtream' && pl.acc) return 'x:' + String(pl.acc.server || '').replace(/\/+$/, '').toLowerCase() + '|' + pl.acc.user;
  if (pl.kind === 'm3u-url' && pl.url) return 'u:' + pl.url;
  return ''; // a playlist from a file has nothing the other device could load
}

// What a playlist looks like to other devices. Built-in sources only share on/off and Home.
function def(pl) {
  return pl.builtin
    ? { builtin: pl.builtin, name: pl.name, enabled: pl.enabled !== false, hideHome: !!pl.hideHome }
    : { name: pl.name, kind: pl.kind, url: pl.url, acc: pl.acc, enabled: pl.enabled !== false, hideHome: !!pl.hideHome, main: !!pl.main };
}

function refOf(id) {
  const it = lookup(id);
  if (!it) return null;
  const pl = S.playlists.find((p) => p.id === it.pl);
  const key = plKey(pl);
  if (!key) return null;
  if (pl.kind === 'xtream') {
    const x = it.xc || {};
    if (x.sid != null) return [key, 'live', String(x.sid)];
    if (x.vid != null) return [key, 'vod', String(x.vid)];
    if (x.series != null) return [key, 'series', String(x.series)];
    const m = /\/series\/[^/]+\/[^/]+\/([^/.]+)\.\w+$/.exec(it.url || '');
    return m ? [key, 'ep', m[1]] : null;
  }
  if (!it.type && it.name) return [key, 'mshow', normName(it.name)];
  return it.url ? [key, 'm3u', it.url] : null;
}

// The same title's id on this device, if this device has that playlist.
let urlIndex = null;
function resolve(ref) {
  if (!Array.isArray(ref)) return null;
  const [key, t, k] = ref;
  const pl = S.playlists.find((p) => plKey(p) === key);
  if (!pl) return null;
  if (t === 'live' || t === 'vod' || t === 'series' || t === 'ep') return pl.kind === 'xtream' ? hash(pl.id + '|' + t + '|' + k) : null;
  if (t === 'mshow') return hash('show|' + pl.id + '|' + k);
  if (t === 'm3u') {
    if (!urlIndex) { urlIndex = new Map(); for (const i of S.items) urlIndex.set(i.pl + '|' + i.url, i.id); }
    return urlIndex.get(pl.id + '|' + k) || null;
  }
  return null;
}

// Enough of a title to show it in Favourites and Continue watching before its category is opened.
function slim(it) {
  if (!it) return undefined;
  const { name, logo, group, url, type, year, rating, ep, xc, added, backdrop } = it;
  return { name, logo, group, url, type, year, rating, ep, xc, added, backdrop, plot: it.plot ? String(it.plot).slice(0, 400) : undefined };
}

function remember(s, id, ref, showId) {
  if (!s || lookup(id)) return;
  const pl = S.playlists.find((p) => plKey(p) === ref[0]);
  if (pl) rememberSnap({ ...s, id, pl: pl.id, lazy: true, showId: showId || undefined });
}

// ---------- what changed here ----------
// Compares what Lumen holds now with what it held last time, and dates each change. Things
// that were already here when sync first ran are dated 0, so linking two devices merges them
// instead of one overwriting the other.
function scan() {
  const first = !meta.base;
  const now = Date.now();
  for (const [k, v] of Object.entries(S.settings)) {
    if (LOCAL_ONLY.has(k)) continue;
    const e = meta.set[k], hv = h(v);
    if (!e) meta.set[k] = { h: hv, at: 0 };
    else if (e.h !== hv) meta.set[k] = { h: hv, at: now };
  }
  for (const id of S.favs) { const e = meta.fav[id]; if (!e || !e.on) meta.fav[id] = { on: true, at: first ? 0 : now }; }
  for (const [id, e] of Object.entries(meta.fav)) if (e.on && !S.favs.has(id)) meta.fav[id] = { on: false, at: now };
  const ids = new Set(S.history.map((e) => e.id));
  if (!first) for (const id of meta.hist || []) if (!ids.has(id)) meta.gone[id] = now;
  meta.hist = [...ids];
  const keys = new Set();
  for (const pl of S.playlists) {
    const key = plKey(pl);
    if (!key) continue;
    keys.add(key);
    const e = meta.pl[key], hv = h(def(pl));
    if (!e) meta.pl[key] = { h: hv, at: first ? 0 : now };
    else if (e.h !== hv || e.deleted) meta.pl[key] = { h: hv, at: now };
  }
  for (const [key, e] of Object.entries(meta.pl)) if (!e.deleted && !keys.has(key)) meta.pl[key] = { deleted: true, at: now };
  // Old removals stop mattering after a month.
  for (const [id, at] of Object.entries(meta.gone)) if (now - at > 30 * 86400000) delete meta.gone[id];
  meta.base = true;
  saveMeta();
}

function buildDoc() {
  const cache = new Map();
  const R = (id) => { if (!cache.has(id)) cache.set(id, refOf(id)); return cache.get(id); };
  const favs = [];
  for (const [id, e] of Object.entries(meta.fav)) { const r = R(id); if (r) favs.push({ r, on: e.on, at: e.at, s: e.on ? slim(lookup(id)) : undefined }); }
  const hist = [];
  for (const e of S.history) {
    const r = R(e.id);
    if (!r) continue;
    hist.push({ r, type: e.type, pos: e.pos, dur: e.dur, at: e.at, sr: e.showId ? R(e.showId) : null,
      s: e.type === 'live' ? undefined : slim(lookup(e.id)), ss: e.showId ? slim(lookup(e.showId)) : undefined });
  }
  const gone = [];
  for (const [id, at] of Object.entries(meta.gone)) { const r = R(id); if (r) gone.push({ r, at }); }
  const settings = {};
  for (const [k, e] of Object.entries(meta.set)) {
    let v = S.settings[k];
    if (k === 'myList') v = (v || []).map(R).filter(Boolean);
    settings[k] = { v, at: e.at };
  }
  const playlists = [];
  for (const pl of S.playlists) { const key = plKey(pl); if (key) playlists.push({ key, id: pl.id, d: def(pl), at: (meta.pl[key] || {}).at || 0 }); }
  for (const [key, e] of Object.entries(meta.pl)) if (e.deleted) playlists.push({ key, deleted: true, at: e.at });
  return { v: 1, at: Date.now(), favs, hist, gone, settings, playlists };
}

// ---------- merging another device's changes ----------

async function merge(d, from) {
  if (!d || d.v !== 1) return;
  scan();
  urlIndex = null;
  let lib = false, favs = false, hist = false, sets = false;
  const added = [];

  for (const p of d.playlists || []) {
    const local = S.playlists.find((x) => plKey(x) === p.key);
    const e = meta.pl[p.key];
    const at = e ? e.at : -1;
    if (p.deleted) {
      if (local && !local.builtin && p.at > at) { meta.pl[p.key] = { deleted: true, at: p.at }; await removePlaylist(local.id); }
      if (p.at > at) meta.pl[p.key] = { deleted: true, at: p.at };
      continue;
    }
    if (!local) {
      if ((e && e.deleted && e.at >= p.at) || p.d.builtin) continue;
      const pl = { id: S.playlists.some((x) => x.id === p.id) ? hash(p.id + Date.now()) : p.id, name: p.d.name, kind: p.d.kind, url: p.d.url, acc: p.d.acc, enabled: p.d.enabled, hideHome: p.d.hideHome, updated: 0 };
      if (p.d.main || !S.playlists.some((x) => !x.builtin)) { for (const x of S.playlists) x.main = false; pl.main = true; }
      S.playlists.push(pl);
      savePlaylists();
      meta.pl[p.key] = { h: h(def(pl)), at: p.at };
      added.push(pl);
      continue;
    }
    if (p.at > at) {
      const before = h(def(local));
      local.name = p.d.name; local.enabled = p.d.enabled; local.hideHome = p.d.hideHome;
      if (!local.builtin && p.d.main && !local.main) { for (const x of S.playlists) x.main = false; local.main = true; }
      if (h(def(local)) !== before) { savePlaylists(); lib = true; }
      meta.pl[p.key] = { h: h(def(local)), at: p.at };
    }
  }

  for (const [k, r] of Object.entries(d.settings || {})) {
    if (LOCAL_ONLY.has(k) || !(k in DEFAULTS)) continue;
    const e = meta.set[k];
    const at = e ? e.at : 0;
    let v = r.v;
    if (k === 'myList') {
      const ids = (v || []).map(resolve);
      if (ids.some((x) => !x)) continue; // a playlist that's still loading: try again next time
      v = ids;
    }
    const cur = S.settings[k];
    if (h(cur) === h(v)) { if (r.at > at) meta.set[k] = { h: h(cur), at: r.at }; continue; }
    // Both untouched since linking: a choice beats a default (a new TV picks up the phone's setup).
    const tie = r.at === at && h(cur) === h(DEFAULTS[k]);
    if (r.at > at || tie) { S.settings[k] = v; meta.set[k] = { h: h(v), at: r.at }; sets = true; }
  }
  if (sets) saveSettings();

  for (const f of d.favs || []) {
    const id = resolve(f.r);
    if (!id) continue;
    const e = meta.fav[id];
    if (e && f.at <= e.at) continue;
    if (f.on && !S.favs.has(id)) { remember(f.s, id, f.r); S.favs.add(id); favs = true; }
    if (!f.on && S.favs.has(id)) { S.favs.delete(id); favs = true; }
    meta.fav[id] = { on: f.on, at: f.at };
  }
  if (favs) { ls.set('favs', [...S.favs]); bus.emit('favs'); }

  for (const g of d.gone || []) { const id = resolve(g.r); if (id && (meta.gone[id] || 0) < g.at) meta.gone[id] = g.at; }
  for (const x of d.hist || []) {
    const id = resolve(x.r);
    if (!id || (meta.gone[id] || 0) >= x.at) continue;
    const e = S.history.find((y) => y.id === id);
    if (e && e.at >= x.at) continue;
    const showId = x.sr ? resolve(x.sr) || undefined : undefined;
    if (showId) remember(x.ss, showId, x.sr);
    remember(x.s, id, x.r, showId);
    const n = { id, type: x.type, pos: x.pos, dur: x.dur, at: x.at, showId };
    if (e) Object.assign(e, n); else S.history.push(n);
    hist = true;
  }
  const n = S.history.length;
  S.history = S.history.filter((e) => !((meta.gone[e.id] || 0) >= e.at));
  if (hist || S.history.length !== n) {
    S.history.sort((a, b) => b.at - a.at);
    S.history = S.history.slice(0, 200);
    ls.set('history', S.history);
    bus.emit('history');
  }

  // What merging changed isn't a change made here: take it as the new starting point.
  meta.hist = S.history.map((e) => e.id);
  saveMeta();

  for (const pl of added) {
    toast(`Adding ${pl.name} from ${from}…`, { ms: 5000 });
    try { await refreshPlaylist(pl.id); } catch (e) { pl.error = e.message; savePlaylists(); }
  }
  if (lib && !added.length) await loadLibrary();
  if (added.length) bus.emit('synced');
}

// ---------- talking to the app ----------

export async function syncStatus() {
  try { const r = await fetch('/api/sync/status', { cache: 'no-store' }); return r.ok ? await r.json() : null; } catch { return null; }
}

async function publish() {
  scan();
  try { await fetch('/api/sync/publish', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(buildDoc()) }); } catch {}
}

let busy = null;
export function syncNow() {
  if (busy) return busy;
  busy = (async () => {
    const st = await syncStatus();
    for (const p of (st && st.linked) || []) {
      try {
        const r = await fetch('/api/sync/fetch?id=' + encodeURIComponent(p.id), { cache: 'no-store' });
        if (r.ok) await merge(await r.json(), p.name);
      } catch {}
    }
    await publish();
  })().finally(() => { busy = null; });
  return busy;
}

export async function linkDevice(host, port, pin) {
  const r = await fetch('/api/sync/link', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ host, port, pin }) });
  const j = await r.json().catch(() => ({}));
  if (!j.ok) throw new Error(j.error || 'Couldn’t link with that device. Check it’s on the same Wi-Fi with Lumen open.');
  await publish();
  syncNow();
  return j;
}

export async function unlinkDevice(id) {
  await fetch('/api/sync/unlink', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
}

let started = false;
export function startSync() {
  if (started || !syncAvailable()) return;
  started = true;
  const soon = debounce(publish, 1500);
  for (const ev of ['favs', 'history', 'settings', 'library', 'sources']) bus.on(ev, soon);
  publish();
  // Every 20 seconds while Lumen is on screen, and as soon as it comes back to the front.
  const loop = () => { (document.hidden ? Promise.resolve() : syncNow()).catch(() => {}).finally(() => setTimeout(loop, 20000)); };
  setTimeout(loop, 3000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) syncNow().catch(() => {}); });
}
