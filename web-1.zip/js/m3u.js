// M3U / M3U Plus parser. Understands tvg-*, group-title, catch-up attributes,
// #EXTGRP, #EXTVLCOPT user-agent/referrer and #KODIPROP headers, and sorts
// every entry into live TV, movies or series.
import { hash } from './util.js';

const VOD_EXT = /\.(mp4|mkv|avi|mov|m4v|webm|wmv|flv|mpg|mpeg|divx)(\?|$)/i;
const SERIES_RX = /^(.*?)[\s._\-|:]*(?:S(\d{1,2})[\s._-]*E(\d{1,3})|(\d{1,2})x(\d{2,3})|Season\s*(\d+)\s*Episode\s*(\d+))(.*)$/i;
const MOVIE_GROUP = /\b(vod|movie|movies|film|films|cinema|kino|peliculas|filmes)\b/i;
const SERIES_GROUP = /\b(series|serie|tv shows|shows|seasons|séries)\b/i;

function attrs(str) {
  const out = {};
  const rx = /([\w-]+)=("([^"]*)"|'([^']*)'|([^\s,]+))/g;
  let m;
  while ((m = rx.exec(str))) out[m[1].toLowerCase()] = m[3] ?? m[4] ?? m[5] ?? '';
  return out;
}

// Split '#EXTINF:-1 a="b" c="d",Name' into attributes and title, respecting quotes.
function splitExtinf(line) {
  const body = line.slice(line.indexOf(':') + 1);
  let q = null;
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (q) { if (c === q) q = null; }
    else if (c === '"' || c === "'") q = c;
    else if (c === ',') return [body.slice(0, i), body.slice(i + 1).trim()];
  }
  return [body, ''];
}

export function parseSeriesName(name) {
  const m = SERIES_RX.exec(name);
  if (!m) return null;
  const show = m[1].replace(/[\s._\-|:]+$/, '').trim();
  if (!show) return null;
  return {
    show,
    s: Number(m[2] || m[4] || m[6]),
    e: Number(m[3] || m[5] || m[7]),
    title: (m[8] || '').replace(/^[\s._\-|:]+/, '').trim(),
  };
}

export function classify(item) {
  const t = (item.tvgType || '').toLowerCase();
  if (t === 'movie' || t === 'vod') return 'movie';
  if (t === 'series') return 'series';
  if (t === 'live') return 'live';
  let path = '';
  try { path = new URL(item.url).pathname; } catch { path = item.url; }
  if (/\/series\//i.test(path)) return 'series';
  if (/\/movies?\//i.test(path)) return 'movie';
  const vodFile = VOD_EXT.test(path);
  const ep = parseSeriesName(item.name);
  if (SERIES_GROUP.test(item.group) && (ep || vodFile)) return 'series';
  if (ep && vodFile) return 'series';
  if (vodFile) return ep ? 'series' : 'movie';
  // A "Movies" group of HLS or TS streams is a live movie channel, not a VOD library.
  if (MOVIE_GROUP.test(item.group) && !/\.(m3u8|ts)$/i.test(path)) return ep ? 'series' : 'movie';
  return 'live';
}

// "Name (1080p) [Geo-blocked]" -> name "Name", q "1080p", tags ["Geo-blocked"]
function cleanName(it) {
  let n = it.name;
  const tags = [];
  n = n.replace(/\s*\[([^\]]+)\]\s*/g, (_, t) => { for (const x of t.split(';')) if (/^(geo-blocked|not 24\/7)$/i.test(x.trim())) tags.push(x.trim()); return ' '; });
  const q = /\s*\((\d{3,4}p|4K|UHD)\)\s*/i.exec(n);
  if (q) { it.q = q[1]; n = n.replace(q[0], ' '); }
  n = n.replace(/\s+/g, ' ').trim();
  if (n) it.name = n;
  if (tags.length) it.tags = tags;
}

export function parseM3U(text, plId, options = {}) {
  const lines = text.replace(/^﻿/, '').split(/\r?\n/);
  const header = { epg: [] };
  const items = [];
  let cur = null;
  let opts = {};
  let extgrp = '';
  const seen = new Map();

  for (let raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith('#EXTM3U')) {
      const a = attrs(line);
      for (const k of ['url-tvg', 'x-tvg-url', 'tvg-url']) {
        if (a[k]) header.epg.push(...a[k].split(',').map((s) => s.trim()).filter(Boolean));
      }
      if (a.catchup) header.catchup = a.catchup;
      if (a['catchup-source']) header.catchupSource = a['catchup-source'];
      continue;
    }
    if (line.startsWith('#EXTINF')) {
      const [a, title] = splitExtinf(line);
      const at = attrs(a);
      cur = {
        name: title || at['tvg-name'] || 'Untitled',
        tvgId: at['tvg-id'] || '',
        tvgName: at['tvg-name'] || '',
        logo: at['tvg-logo'] || at.logo || '',
        group: at['group-title'] || '',
        chno: Number(at['tvg-chno'] || at['channel-number'] || at['tvg-num']) || 0,
        tvgType: at['tvg-type'] || at.type || '',
        catchup: at.catchup || at['catchup-type'] || (at['tvg-rec'] || at['timeshift'] ? 'shift' : '') || '',
        catchupSource: at['catchup-source'] || '',
        catchupDays: Number(at['catchup-days'] || at['tvg-rec'] || at.timeshift) || 0,
        shift: Number(at['tvg-shift']) || 0,
      };
      if (at['http-user-agent']) opts.ua = at['http-user-agent'];
      if (at['http-referrer'] || at['http-referer']) opts.ref = at['http-referrer'] || at['http-referer'];
      continue;
    }
    if (line.startsWith('#EXTGRP:')) { extgrp = line.slice(8).trim(); continue; }
    if (line.startsWith('#EXTVLCOPT:')) {
      const kv = line.slice(11);
      const [k, ...v] = kv.split('=');
      const key = k.trim().toLowerCase();
      if (key === 'http-user-agent') opts.ua = v.join('=').trim();
      if (key === 'http-referrer' || key === 'http-referer') opts.ref = v.join('=').trim();
      continue;
    }
    if (line.startsWith('#KODIPROP:')) {
      const m = /stream_headers=(.*)$/i.exec(line);
      if (m) {
        for (const pair of m[1].split('&')) {
          const [k, v] = pair.split('=');
          if (/user-agent/i.test(k)) opts.ua = decodeURIComponent(v || '');
          if (/referr?er/i.test(k)) opts.ref = decodeURIComponent(v || '');
        }
      }
      continue;
    }
    if (line.startsWith('#')) continue;

    // A URL line closes the current entry.
    let url = line;
    // Pipe-style headers: url|User-Agent=..&Referer=..
    const pipe = url.indexOf('|');
    if (pipe > 0) {
      for (const pair of url.slice(pipe + 1).split('&')) {
        const [k, v] = pair.split('=');
        if (/user-agent/i.test(k)) opts.ua = decodeURIComponent(v || '');
        if (/referr?er/i.test(k)) opts.ref = decodeURIComponent(v || '');
      }
      url = url.slice(0, pipe);
    }
    const it = cur || { name: url.split('/').pop() || 'Stream', group: '', logo: '', tvgId: '', tvgName: '', chno: 0, catchup: '', catchupSource: '', catchupDays: 0 };
    it.url = url;
    if (!it.group) it.group = extgrp || '';
    // iptv-org style "A;B" groups: keep the first.
    if (it.group.includes(';')) it.group = it.group.split(';')[0].trim();
    if (it.group === 'Undefined') it.group = '';
    cleanName(it);
    if (opts.ua) it.ua = opts.ua;
    if (opts.ref) it.ref = opts.ref;
    if (!it.catchup && header.catchup) it.catchup = header.catchup;
    if (!it.catchupSource && header.catchupSource) it.catchupSource = header.catchupSource;
    it.type = options.forceType || classify(it);
    it.group = it.group || (it.type === 'live' ? 'Uncategorised' : it.type === 'movie' ? 'Movies' : 'Series');
    let id = hash(plId + '|' + url + '|' + it.name);
    const n = seen.get(id) || 0;
    seen.set(id, n + 1);
    if (n) id += '-' + n;
    it.id = id;
    it.pl = plId;
    it.idx = items.length;
    if (it.type === 'series') {
      const ep = parseSeriesName(it.name);
      if (ep) it.ep = ep;
      else it.ep = { show: it.group, s: 1, e: items.length, title: it.name };
    }
    const y = /\((19|20)\d\d\)|\b(19|20)\d\d\b/.exec(it.name);
    if (y && it.type !== 'live') it.year = Number(y[0].replace(/\D/g, ''));
    delete it.tvgType;
    if (!it.catchup) { delete it.catchup; delete it.catchupSource; delete it.catchupDays; }
    if (!it.shift) delete it.shift;
    items.push(it);
    cur = null; opts = {}; extgrp = '';
  }
  return { header, items };
}
