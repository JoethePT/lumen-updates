// Lumen boot, navigation rail and router.
import { h, clear, toast } from './util.js';
import { icon } from './icons.js';
import { nav } from './nav.js';
import { markBooted } from './updates.js';
import { net } from './net.js';
import { S, bus, loadLibrary, loadEpg, refreshPlaylist, dueReminders, ensureBuiltins, syncBuiltins } from './store.js';
import { ls } from './util.js';
import { startCompanion, pairPanel, companion } from './companion.js';
import { applyTheme } from './theme.js';
import { homeView, liveView, guideView, vodView, searchView, favouritesView, serviceView, setGo } from './ui/views.js';
import { settingsView } from './ui/settings.js';
import { playlistForm, refreshGuide } from './ui/sources.js';
import * as player from './ui/player-ui.js';

const VIEWS = {
  home: () => homeView(),
  live: (p) => liveView(p),
  guide: () => guideView(),
  movies: (p) => vodView('movie', p),
  series: (p) => vodView('series', p),
  service: (p) => serviceView(p),
  search: () => searchView(),
  favourites: () => favouritesView(),
  settings: (p) => settingsView(p),
  welcome: () => welcomeView(),
};

const RAIL = [
  ['home', 'Home', 'home'], ['live', 'Live TV', 'live'], ['guide', 'Guide', 'guide'],
  ['movies', 'Movies', 'movie'], ['series', 'Series', 'series'], ['search', 'Search', 'search'],
  ['favourites', 'Favourites', 'heart'],
];

const viewHost = document.getElementById('view');
const rail = document.getElementById('rail');
let current = null;
let currentName = '';

function buildRail() {
  clear(rail);
  rail.append(h('div.rail-logo', h('span.mark'), h('b', 'Lumen')));
  for (const [k, l, ic] of RAIL) {
    rail.append(h('button.rail-btn', { dataset: { view: k }, 'aria-label': l, onclick: () => go(k) }, icon(ic), h('span.lbl', l)));
  }
  rail.append(h('div.rail-spacer'), h('div.rail-sep'), h('button.rail-btn', { dataset: { view: 'settings' }, 'aria-label': 'Settings', onclick: () => go('settings') }, icon('settings'), h('span.lbl', 'Settings')));
}

function markRail() {
  for (const b of rail.querySelectorAll('.rail-btn')) b.classList.toggle('on', b.dataset.view === currentName);
}

export function go(name, params = {}) {
  if (needsWelcome() && name !== 'welcome') name = 'welcome';
  if (current && current.destroy) { try { current.destroy(); } catch (e) { console.error(e); } }
  currentName = name;
  rail.hidden = name === 'welcome';
  const v = VIEWS[name](params);
  current = v;
  clear(viewHost).append(v.el);
  v.el.classList.add('enter');
  markRail();
  requestAnimationFrame(() => {
    if (v.onShow) v.onShow(); else nav.focusFirst(v.el);
  });
}
setGo(go);

function needsWelcome() {
  return !ls.get('onboarded') && !S.playlists.some((p) => !p.builtin);
}

// Download the built-in free sources in the background, then refresh the guide.
function startFreeSources() {
  syncBuiltins().then((n) => { if (n) loadEpg(true).catch(() => {}); }).catch((e) => console.warn(e));
}

function welcomeView() {
  const feats = [
    ['live', 'Live TV with preview', 'Browse groups and watch in a preview window.'],
    ['guide', 'Full TV guide', 'XMLTV with catch-up, reminders and search.'],
    ['movie', 'Movies and series', 'Posters, seasons, resume and next episode.'],
    ['grid', 'Multiview', 'Up to four channels at once.'],
    ['shield', 'Parental PIN', 'Lock or hide any group.'],
    ['server', 'Xtream Codes', 'Sign in with your provider login.'],
  ];
  const el = h('div.view');
  const card = h('div.welcome-card.glass-strong', h('h2', { style: { fontSize: '1.6rem', marginBottom: '.4rem' } }, 'Add your first playlist'),
    h('p.muted', { style: { margin: '0 0 1.4rem' } }, 'Your playlist stays on this device.'),
    companion.info ? [pairPanel(), h('div.or', h('span', 'or type it here'))] : null,
    playlistForm(() => { go('home'); startFreeSources(); }, {
      main: true,
      freeStart: () => { ls.set('onboarded', true); go('home'); startFreeSources(); },
    }));
  el.append(h('div.welcome',
    h('div', h('div.eyebrow', 'Welcome to Lumen'), h('h1', 'All your channels, ', h('em', 'beautifully'), ' arranged.'),
      h('p.lead', 'Add your own M3U playlist or Xtream login as your main source. Thousands of free channels from iptv-org, Plex, Pluto TV, Samsung TV Plus and Roku come built in.'),
      h('div.feat', feats.map(([ic, t, d]) => h('div', icon(ic), h('span', h('b', t), d))))),
    card));
  return { el, onShow() { nav.focusFirst(card); } };
}

// Back from a top-level screen returns Home, then focuses the rail.
document.addEventListener('lumen:back', (e) => {
  // Some screens step back to their parent first (a category grid back to the Movies rows).
  if (current && current.back) { current.back(); e.preventDefault(); return; }
  if (currentName !== 'home' && currentName !== 'welcome') { go('home'); e.preventDefault(); return; }
  const b = rail.querySelector('.rail-btn.on') || rail.querySelector('.rail-btn');
  if (b && !rail.contains(document.activeElement) && !rail.hidden) { nav.focus(b); e.preventDefault(); }
});

// Rebuild the open screen when the library changes, unless the viewer is busy watching.
// Background refreshes (free sources updating) wait until the remote has been idle, so the
// screen never redraws and moves focus while you're navigating.
let pending = false;
let lastKey = 0;
document.addEventListener('keydown', () => { lastKey = Date.now(); }, true);
const busy = () => player.mode() === 'full' || document.querySelector('.layer');
bus.on('library', () => {
  if (busy() || (S.bgRefresh && Date.now() - lastKey < 8000)) { pending = true; return; }
  refreshView();
});
setInterval(() => {
  if (pending && !busy() && Date.now() - lastKey > 8000) { pending = false; refreshView(); }
}, 2000);
document.addEventListener('lumen:playerclosed', () => { if (pending && Date.now() - lastKey > 8000) { pending = false; refreshView(); } });

// Redraw the open screen in place: same group and channel in Live TV, same row and tile on
// Home and Favourites, same scroll. Screens a library refresh barely changes (Movies, Series,
// Search, the guide) aren't redrawn; they pick up changes the next time they're opened.
const REDRAW = new Set(['home', 'live', 'favourites']);
function refreshView() {
  if (!REDRAW.has(currentName)) return;
  const params = current && current.snapshot ? current.snapshot() : {};
  const path = focusPath();
  go(currentName, params);
  if (currentName !== 'live') requestAnimationFrame(() => requestAnimationFrame(() => restoreFocus(path)));
}
const sectionsOf = (v) => [...v.querySelectorAll(':scope > .section, :scope > .hero, :scope > .country-hint')];
function focusPath() {
  const v = viewHost.firstElementChild;
  if (!v) return null;
  const a = document.activeElement;
  const out = { scroll: v.scrollTop };
  if (!a || !v.contains(a)) return out;
  const sec = a.closest('.section, .hero, .country-hint');
  if (!sec) return out;
  const items = [...sec.querySelectorAll('.f, button')];
  return { ...out, row: sec.dataset.row || null, rowIndex: sectionsOf(v).indexOf(sec), item: items.indexOf(a), text: (a.textContent || '').trim().slice(0, 60) };
}
function restoreFocus(path) {
  const v = viewHost.firstElementChild;
  if (!path || !v) return;
  v.scrollTop = path.scroll;
  if (path.rowIndex == null) return;
  const secs = sectionsOf(v);
  const sec = (path.row && v.querySelector(`[data-row="${path.row}"]`)) || secs[path.rowIndex];
  if (!sec) return;
  const items = [...sec.querySelectorAll('.f, button')];
  const el = items.find((x) => (x.textContent || '').trim().slice(0, 60) === path.text) || items[Math.min(path.item, items.length - 1)];
  if (el) { nav.focus(el, { scroll: false }); el.scrollIntoView({ block: 'nearest', inline: 'nearest' }); }
}

function checkReminders() {
  for (const r of dueReminders()) {
    const ch = S.byId.get(r.ch);
    if (!ch) continue;
    toast(`${r.title} is starting on ${ch.name}`, { ms: 15000, action: { label: 'Watch', run: () => player.open(ch) } });
  }
}

async function boot() {
  applyTheme();
  player.applySubStyle();
  net.mode = S.settings.relay;
  if (!window.LUMEN_PREVIEW) await net.detect();
  buildRail();
  startCompanion();
  ensureBuiltins();
  await loadLibrary();
  go(needsWelcome() ? 'welcome' : 'home');
  markBooted();
  if (!needsWelcome()) startFreeSources();

  if (S.playlists.some((p) => !p.builtin)) {
    const demoOnly = S.playlists.filter((p) => !p.builtin).every((p) => p.kind === 'demo');
    if (demoOnly) {
      if (!S.epg.updated || Date.now() - S.epg.updated > 6 * 3600000) refreshGuide().catch(() => {});
      else loadEpg(false).catch(() => {});
    } else {
      loadEpg(false).catch((e) => console.warn(e));
    }
    if (S.settings.refreshOnStart) {
      for (const pl of S.playlists) if (pl.kind !== 'm3u-file' && !pl.builtin) refreshPlaylist(pl.id).catch((e) => toast(`${pl.name}: ${e.message}`));
    }
  }
  setInterval(checkReminders, 30000);
  if (window.LUMEN_PREVIEW) toast('Design preview: video is turned off on this page. Run Lumen on your own network to watch.', { ms: 9000 });
}

boot().catch((e) => {
  console.error(e);
  document.getElementById('view').append(h('div.view', h('div.empty-state', h('h3', 'Lumen could not start'), h('p', String(e && e.message || e)))));
});
