// Updates from Lumen's GitHub update repository (Android app only). The Android side checks,
// verifies and downloads (Updater.java); this shows what's available and lets you install it.
import { toast, ls } from './util.js';

const api = () => window.LumenUpdate || null;
export const updatesAvailable = () => !!api();
export function updateStatus() { try { return JSON.parse(api().status()); } catch { return null; } }
export function checkForUpdates() { api() && api().check(); }
export function installAppUpdate() { api() && api().installApp(); }
export function restartForUpdate() { api() && api().restart(); }

const listeners = new Set();
export function onUpdate(fn) { listeners.add(fn); return () => listeners.delete(fn); }

window.lumenUpdateEvent = (st) => {
  for (const fn of listeners) fn(st);
  // Tell the viewer once per version, without interrupting.
  if (st.app && ls.get('updateToldApp') !== st.app.version) {
    ls.set('updateToldApp', st.app.version);
    toast(`Lumen ${st.app.version} is available`, { ms: 9000, action: { label: 'Update', run: () => installAppUpdate() } });
  }
  if (st.state === 'web-ready' && ls.get('updateToldWeb') !== st.webReady) {
    ls.set('updateToldWeb', st.webReady);
    toast('An update to Lumen’s screens is ready', { ms: 9000, action: { label: 'Restart now', run: () => restartForUpdate() } });
  }
  if (st.state === 'needs-permission') toast('Allow Lumen to install apps, then come back and tap Update again.', { ms: 9000 });
};

// The interface started properly: the app keeps using this version (otherwise, after two failed
// starts, it goes back to the one built in).
export function markBooted() { if (api()) setTimeout(() => { try { api().booted(); } catch {} }, 4000); }
