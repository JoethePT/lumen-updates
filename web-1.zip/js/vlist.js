// Virtualised list / grid. Only rows near the viewport exist in the DOM,
// so playlists with tens of thousands of entries stay smooth on TV hardware.
import { h } from './util.js';

export class VList {
  // opts: { count, render(i), rowHeight(width) -> px, cols(width) -> n, gap px, overscan rows, className }
  constructor(opts) {
    this.o = { overscan: 4, gap: 0, cols: () => 1, ...opts };
    this.el = h('div.vl' + (opts.className ? '.' + opts.className : ''), { 'data-remember': '' });
    this.inner = h('div.vl-inner');
    this.el.append(this.inner);
    this.rows = new Map();
    this.count = opts.count;
    this.el.addEventListener('scroll', () => this.paint(), { passive: true });
    // Keep rows around the focused item rendered even while a smooth scroll lags behind a held key.
    this.focusRow = -1;
    this.el.addEventListener('focusin', (e) => {
      const it = e.target.closest('[data-vi]');
      if (!it || !this.el.contains(it)) return;
      this.focusRow = Math.floor(Number(it.dataset.vi) / (this.cols || 1));
      this.paint();
    });
    this.ro = new ResizeObserver(() => this.layout());
    this.ro.observe(this.el);
  }

  layout() {
    const w = this.el.clientWidth;
    if (!w) return;
    const cols = Math.max(1, this.o.cols(w));
    const rh = this.o.rowHeight(w, cols);
    if (cols !== this.cols || rh !== this.rh) {
      this.cols = cols; this.rh = rh;
      this.clearRows();
    }
    this.inner.style.height = this.totalRows() * (this.rh + this.o.gap) + 'px';
    this.paint();
  }

  totalRows() { return Math.ceil(this.count / (this.cols || 1)); }

  clearRows() {
    for (const r of this.rows.values()) r.remove();
    this.rows.clear();
  }

  paint() {
    if (!this.rh) return;
    const step = this.rh + this.o.gap;
    const top = this.el.scrollTop, hgt = this.el.clientHeight || 800;
    const max = this.totalRows() - 1;
    const first = Math.max(0, Math.floor(top / step) - this.o.overscan);
    const last = Math.min(max, Math.ceil((top + hgt) / step) + this.o.overscan);
    const fr = this.focusRow;
    const fFirst = fr >= 0 ? Math.max(0, fr - this.o.overscan) : -1;
    const fLast = fr >= 0 ? Math.min(max, fr + this.o.overscan) : -2;
    const want = (i) => (i >= first && i <= last) || (i >= fFirst && i <= fLast);
    const active = document.activeElement;
    for (const [i, row] of this.rows) {
      if (!want(i) && !row.contains(active)) { row.remove(); this.rows.delete(i); }
    }
    const add = (i) => {
      if (this.rows.has(i)) return;
      const row = this.makeRow(i);
      this.rows.set(i, row);
      this.inner.append(row);
    };
    for (let i = first; i <= last; i++) add(i);
    for (let i = fFirst; i <= fLast; i++) add(i);
  }

  makeRow(r) {
    const row = h('div.vl-row', { style: { transform: `translateY(${r * (this.rh + this.o.gap)}px)`, height: this.rh + 'px' } });
    row.dataset.row = r;
    if (this.cols > 1) row.style.gridTemplateColumns = `repeat(${this.cols}, minmax(0, 1fr))`;
    const start = r * this.cols;
    for (let i = start; i < Math.min(this.count, start + this.cols); i++) {
      const el = this.o.render(i);
      el.dataset.vi = i;
      row.append(el);
    }
    return row;
  }

  setCount(n) {
    this.count = n;
    this.focusRow = -1;
    this.clearRows();
    this.el.scrollTop = 0;
    this.layout();
  }

  refresh() {
    const active = document.activeElement;
    const vi = active && active.dataset ? active.dataset.vi : null;
    this.clearRows();
    this.paint();
    if (vi != null) { const el = this.itemEl(Number(vi)); if (el) el.focus({ preventScroll: true }); }
  }

  itemEl(i) {
    const r = this.rows.get(Math.floor(i / this.cols));
    return r ? r.querySelector(`[data-vi="${i}"]`) : null;
  }

  scrollToIndex(i, align = 'center') {
    const step = this.rh + this.o.gap;
    const r = Math.floor(i / this.cols);
    const y = align === 'center' ? r * step - this.el.clientHeight / 2 + step / 2 : r * step;
    this.el.scrollTop = Math.max(0, y);
    this.paint();
    return this.itemEl(i);
  }

  destroy() { this.ro.disconnect(); }
}
