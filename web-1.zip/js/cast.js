// Casting films, episodes and live channels to a Chromecast or Google TV, from the phone and
// tablet app. The Android side (CastBridge.java) finds devices, connects and plays; this draws
// the device picker and the "now casting" bar, sends subtitle files along, and keeps resume
// points up to date while casting.
import { h, fmtDur, toast, srtToVtt } from './util.js';
import { icon } from './icons.js';
import { S, savePosition, getPosition, nowNext } from './store.js';
import { menu } from './ui/common.js';
import { uploadSub } from './native.js';

const api = () => window.LumenCast || null;
export const castAvailable = () => { try { return !!(api() && api().available()); } catch { return false; } };

let current = null;     // the item being cast
let list = null;        // for live channels: the channel list, so the bar can change channel
let bar = null, poll = 0, waiting = null, retry = null;

const parse = (s, d) => { try { return JSON.parse(s); } catch { return d; } };
const status = () => parse(api().status(), { connected: false });
const devices = () => parse(api().devices(), []);
const isLive = (it) => it && it.type === 'live';

window.lumenCastEvent = (e) => {
  if (e.type === 'devices' && waiting) waiting();
  if (e.type === 'connecting') paintBar({ state: 'connecting' });
  if (e.type === 'connected') { toast(`Connected to ${e.text}`); startPolling(); }
  if (e.type === 'loaded') { retry = null; startPolling(); }
  if (e.type === 'error') failed(e.text);
  if (e.type === 'ended') stopBar();
};

// A live channel that won't start is usually the provider still holding the last stream for a
// minute or two (one-stream subscriptions). Try again a few times before giving up.
function failed(text) {
  if (current && isLive(current)) {
    retry = retry || { n: 0, item: current };
    if (retry.item === current && retry.n < 3) {
      const wait = [30, 45, 60][retry.n++];
      paintBar({ state: 'waiting', wait });
      setTimeout(() => { if (current === retry?.item) castItem(current, 0); }, wait * 1000);
      return;
    }
  }
  retry = null;
  toast(text, { ms: 7000 });
}

// The Cast button: pick a device (or use the one already connected), then play there.
export function castButton(item, getStart, cls = '.btn') {
  if (!castAvailable()) return null;
  const b = h('button' + cls, { 'aria-label': 'Cast', onclick: () => chooseAndCast(b, item, getStart) }, icon('cast'), cls === '.btn' ? 'Cast' : null);
  return b;
}

export function chooseAndCast(anchor, item, getStart = () => (isLive(item) ? 0 : getPosition(item.id)), channels = null) {
  if (isLive(item)) list = channels && channels.length ? channels : null;
  if (status().connected) return castItem(item, getStart());
  const found = devices();
  // Devices can take a moment to show up after the app opens: open the list when they do.
  if (!found.length) {
    toast('Looking for Chromecasts on your Wi-Fi…');
    waiting = () => { if (devices().length && anchor.isConnected) { waiting = null; chooseAndCast(anchor, item, getStart, channels); } };
    setTimeout(() => { if (waiting) { waiting = null; toast('No Chromecast found. Check it’s on and on the same Wi-Fi as this device.', { ms: 6000 }); } }, 12000);
    return;
  }
  menu(anchor, 'Cast to', found.map((d) => ({ label: d.name, run: async () => {
    current = item;
    paintBar({ state: 'connecting', device: d.name });
    api().connect(d.id);
    api().load(JSON.stringify(await payload(item, getStart())));
  } })));
}

async function payload(item, start) {
  const live = isLive(item);
  // Chromecasts play live channels as HLS; Xtream providers serve every channel both ways.
  let url = item.url;
  if (live && item.xc && /\.ts(\?|$)/.test(url)) url = url.replace(/\.ts(\?|$)/, '.m3u8$1');
  const { now } = live ? nowNext(item) : {};
  const { subFilesFor } = await import('./ui/player-ui.js');
  const subs = subFilesFor(item.id).map((s, i, a) => ({ ...s, on: i === a.length - 1 }));
  return {
    url, live,
    title: live ? item.name : item.ep ? item.ep.show || item.name : item.name,
    subtitle: live ? (now ? now[2] : item.group || '') : item.ep ? `Season ${item.ep.s}, episode ${item.ep.e}${item.ep.title ? ': ' + item.ep.title : ''}` : (item.year ? String(item.year) : ''),
    poster: item.logo || '', start: start || 0, episode: !!item.ep,
    subs, subScale: (S.settings.subSize || 100) / 100, subBox: !!S.settings.subBg,
  };
}

export async function castItem(item, start) {
  current = item;
  paintBar({ state: 'buffering' });
  api().load(JSON.stringify(await payload(item, start)));
}

function zap(d) {
  if (!list || !current) return;
  const i = list.findIndex((c) => c.id === current.id);
  const next = list[(i + d + list.length) % list.length];
  retry = null;
  castItem(next, 0);
}

// ---------- subtitles while casting ----------
function subtitlesMenu(anchor) {
  const t = parse(api().tracks(), { tracks: [], active: [] });
  const on = new Set(t.active);
  const items = [{ label: 'Off', on: !t.tracks.some((x) => on.has(x.id)), run: () => api().setTrack(-1) }];
  for (const x of t.tracks) items.push({ label: x.name || (x.lang && x.lang !== 'und' ? x.lang.toUpperCase() : 'Subtitles'), on: on.has(x.id), run: () => api().setTrack(x.id) });
  items.push({ label: 'Load subtitle file…', run: () => pickSubFile() });
  if (!t.tracks.length) items.push({ label: 'Subtitles inside the film file can’t be shown on a Chromecast; load a file instead.', run: () => {} });
  menu(anchor, 'Subtitles on your TV', items);
}

function pickSubFile() {
  const inp = h('input', { type: 'file', accept: '.srt,.vtt,text/vtt' });
  inp.onchange = async () => {
    const f = inp.files[0];
    if (!f) return;
    try {
      const sub = await uploadSub(srtToVtt(await f.text()));
      api().addSub(JSON.stringify({ url: sub.lan, label: f.name.replace(/\.\w+$/, '') }));
      toast('Subtitles sent to your TV');
    } catch (e) { toast(e.message || 'Couldn’t load the subtitle file.'); }
  };
  inp.click();
}

// ---------- the "now casting" bar ----------
function startPolling() {
  clearInterval(poll);
  const tick = () => {
    const st = status();
    if (!st.connected) { stopBar(); return; }
    paintBar(st);
    // Keep resume points while casting, so Continue watching picks up where the TV left off.
    if (current && !isLive(current) && st.duration > 60 && st.position > 5) savePosition(current, st.position, st.duration);
  };
  tick();
  poll = setInterval(tick, 1000);
}

function stopBar() {
  clearInterval(poll); poll = 0;
  if (bar) { bar.remove(); bar = null; }
  document.documentElement.classList.remove('casting');
  current = null; list = null; retry = null;
}

function paintBar(st) {
  if (!bar) {
    bar = h('div.cast-bar.glass-strong');
    document.body.append(bar);
    document.documentElement.classList.add('casting');
  }
  const live = isLive(current) || st.live;
  const title = (current && (live ? current.name : current.ep ? current.ep.show || current.name : current.name)) || st.title || 'Casting';
  const where = st.device || 'your TV';
  const state = st.state === 'connecting' ? `Connecting to ${where}…`
    : st.state === 'waiting' ? `Your provider is still holding the last stream. Trying again in ${st.wait} s…`
    : st.state === 'buffering' ? 'Loading on your TV…'
    : st.state === 'error' ? 'Your TV couldn’t play this'
    : `${st.state === 'paused' ? 'Paused' : live ? 'Live' : 'Playing'} on ${where}`;
  const now = live && current ? nowNext(current).now : null;
  const pct = !live && st.duration ? Math.min(100, (st.position / st.duration) * 100) : 0;
  const btn = (label, ic, fn) => h('button.btn.btn-icon', { 'aria-label': label, onclick: fn }, icon(ic));
  bar.replaceChildren(
    h('div.cb-icon', icon('cast')),
    h('div.cb-txt', h('div.cb-t', title),
      h('div.cb-d', state + (live ? (now ? ` · ${now[2]}` : '') : st.duration ? ` · ${fmtDur(st.position)} / ${fmtDur(st.duration)}` : '')),
      live ? null : h('div.bar', h('i', { style: { width: pct + '%' } }))),
    h('div.cb-btns',
      live && list ? btn('Previous channel', 'chDown', () => zap(-1)) : null,
      live ? null : btn('Back 10 seconds', 'back10', () => api().control('seekBy', -10)),
      btn(st.state === 'paused' ? 'Play' : 'Pause', st.state === 'paused' ? 'play' : 'pause', () => api().control('toggle', 0)),
      live ? null : btn('Forward 10 seconds', 'fwd10', () => api().control('seekBy', 10)),
      live && list ? btn('Next channel', 'chUp', () => zap(1)) : null,
      btn('Subtitles', 'cc', (e) => subtitlesMenu(e.currentTarget)),
      btn('Stop casting', 'close', () => { api().control('stop', 0); stopBar(); }),
    ),
  );
}

// If the app reopens while still casting, show the bar again.
if (castAvailable()) setTimeout(() => { if (status().connected) startPolling(); }, 1500);
