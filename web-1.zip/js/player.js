// Playback engine: picks hls.js, mpegts.js or the native decoder per stream,
// falls back through the others (and through the relay) until one plays.
import { Emitter } from './util.js';
import { net } from './net.js';

const FILE_RX = /\.(mp4|m4v|mov|webm|mkv|avi|mp3|aac|ogg|wmv|mpg|mpeg)(\?|$)/i;

export function detectKind(url) {
  let p = url;
  try { p = new URL(url, location.href).pathname; } catch {}
  if (/\.m3u8?$/i.test(p) || /\/hls\b|format=m3u8|type=m3u8/i.test(url)) return 'hls';
  if (/\.flv$/i.test(p)) return 'flv';
  if (/\.ts$/i.test(p) || /\/mpegts$/i.test(p)) return 'ts';
  if (FILE_RX.test(p)) return 'file';
  return 'unknown';
}

const hasHls = () => window.Hls && window.Hls.isSupported();
const hasMts = () => window.mpegts && window.mpegts.getFeatureList().mseLivePlayback;
const nativeHls = (v) => !!v.canPlayType('application/vnd.apple.mpegurl');

export class Engine extends Emitter {
  constructor(video, opts = {}) {
    super();
    this.v = video;
    this.opts = opts; // { lowLatency, prefer }
    this.hls = null;
    this.mts = null;
    this.name = '';
    this.token = 0;
  }

  plan(src) {
    const { url } = src;
    const kind = detectKind(url);
    const v = this.v;
    let engines;
    switch (kind) {
      case 'hls': engines = hasHls() ? ['hls', 'native'] : ['native']; break;
      case 'ts': engines = ['mpegts', 'hls-alt', 'native']; break;
      case 'flv': engines = ['flv']; break;
      case 'file': engines = ['native']; break;
      // Extension-less live links are usually HLS behind a redirect; Xtream raw TS falls through to mpegts.
      default: engines = src.live ? ['hls', 'mpegts', 'native'] : ['native', 'hls'];
    }
    const pref = this.opts.prefer;
    if (pref && pref !== 'auto') engines = [pref, ...engines.filter((e) => e !== pref)];
    if (!hasMts()) engines = engines.filter((e) => e !== 'mpegts' && e !== 'flv');
    if (!hasHls()) engines = engines.filter((e) => e !== 'hls' && e !== 'hls-alt');
    if (kind === 'hls' && nativeHls(v) && !hasHls()) engines = ['native'];
    if (!engines.length) engines = ['native'];

    const relayFirst = net.relayFirst(url, src);
    const canRelay = net.relay && net.mode !== 'never';
    const out = [];
    for (const e of engines) {
      let u = url;
      if (e === 'hls-alt') u = url.replace(/\.ts(\?|$)/i, '.m3u8$1');
      const eng = e === 'hls-alt' ? 'hls' : e;
      if (relayFirst) out.push({ eng, url: net.wrap(u, src.ua, src.ref), relay: true });
      else {
        out.push({ eng, url: u, relay: false });
        if (canRelay) out.push({ eng, url: net.wrap(u, src.ua, src.ref), relay: true });
      }
    }
    return out;
  }

  async load(src, startAt = 0) {
    this.teardown();
    const tok = ++this.token;
    this.src = src;
    const attempts = this.plan(src);
    let lastErr = 'This stream could not be played.';
    for (const a of attempts) {
      if (tok !== this.token) return false;
      this.emit('attempt', a);
      try {
        await this.tryOne(a, src, startAt, tok);
        if (tok !== this.token) return false;
        this.current = a;
        if (a.relay) net.rememberRelay(src.url);
        this.emit('ready', a);
        return true;
      } catch (e) {
        const m = e && e.message ? e.message : String(e);
        // Keep the most telling reason: an HTTP status beats a later fallback's generic decode error.
        if (!/\(\d{3}\)/.test(lastErr) || /\(\d{3}\)/.test(m)) lastErr = m;
        this.teardown();
      }
    }
    if (tok === this.token) this.emit('fatal', lastErr);
    return false;
  }

  tryOne(a, src, startAt, tok) {
    const v = this.v;
    return new Promise((resolve, reject) => {
      let done = false;
      const ok = () => { if (done) return; done = true; cleanup(); resolve(); };
      const fail = (msg) => { if (done) return; done = true; cleanup(); reject(new Error(msg)); };
      const timer = setTimeout(() => fail('The stream took too long to start.'), src.live ? 20000 : 30000);
      const onPlay = () => ok();
      const onErr = () => fail(mediaError(v.error));
      const cleanup = () => { clearTimeout(timer); v.removeEventListener('loadeddata', onPlay); v.removeEventListener('error', onErr); };
      v.addEventListener('loadeddata', onPlay);
      v.addEventListener('error', onErr);
      this.name = a.eng;

      if (a.eng === 'hls') {
        const Hls = window.Hls;
        const ll = this.opts.lowLatency;
        const hls = new Hls({
          enableWorker: true,
          lowLatencyMode: ll,
          backBufferLength: src.live ? 30 : 90,
          maxBufferLength: ll ? 10 : 30,
          liveSyncDurationCount: ll ? 2 : 3,
          manifestLoadingMaxRetry: 2,
          levelLoadingMaxRetry: 3,
          fragLoadingMaxRetry: 4,
          startPosition: startAt || -1,
          capLevelToPlayerSize: !!this.opts.capLevel,
        });
        this.hls = hls;
        hls.on(Hls.Events.ERROR, (_, d) => {
          if (!d.fatal) return;
          if (!done) {
            const code = d.response && d.response.code;
            return fail(code ? httpMessage(code) : d.details === 'manifestLoadError' ? 'The stream address could not be reached.' : d.details || 'Stream error');
          }
          if (d.type === Hls.ErrorTypes.MEDIA_ERROR) { hls.recoverMediaError(); return; }
          this.emit('fatal-runtime', d.details);
        });
        hls.on(Hls.Events.MANIFEST_PARSED, () => { this.emit('tracks'); v.play().catch((e) => { if (e && e.name === 'NotAllowedError') this.emit('blocked'); }); });
        hls.on(Hls.Events.AUDIO_TRACKS_UPDATED, () => this.emit('tracks'));
        hls.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, () => this.emit('tracks'));
        hls.on(Hls.Events.LEVEL_SWITCHED, () => this.emit('level'));
        hls.loadSource(a.url);
        hls.attachMedia(v);
        return;
      }

      if (a.eng === 'mpegts' || a.eng === 'flv') {
        const m = window.mpegts;
        const ll = this.opts.lowLatency;
        const p = m.createPlayer(
          { type: a.eng === 'flv' ? 'flv' : 'mpegts', isLive: !!src.live, url: new URL(a.url, location.href).href },
          { enableWorker: true, lazyLoad: !src.live, enableStashBuffer: !ll, stashInitialSize: ll ? 128 * 1024 : 384 * 1024, liveBufferLatencyChasing: ll, autoCleanupSourceBuffer: true },
        );
        this.mts = p;
        p.on(m.Events.ERROR, (type, detail) => {
          if (!done) return fail(`${type}: ${detail}`);
          this.emit('fatal-runtime', detail);
        });
        p.on(m.Events.MEDIA_INFO, () => this.emit('tracks'));
        p.attachMediaElement(v);
        p.load();
        Promise.resolve(p.play()).catch((e) => { if (e && e.name === 'NotAllowedError') this.emit('blocked'); });
        return;
      }

      v.src = a.url;
      if (startAt) v.addEventListener('loadedmetadata', () => { try { v.currentTime = startAt; } catch {} }, { once: true });
      v.play().catch((e) => { if (e && e.name === 'NotAllowedError') this.emit('blocked'); });
    });
  }

  teardown() {
    if (this.hls) { try { this.hls.destroy(); } catch {} this.hls = null; }
    if (this.mts) { try { this.mts.pause(); this.mts.unload(); this.mts.detachMediaElement(); this.mts.destroy(); } catch {} this.mts = null; }
    const v = this.v;
    for (const t of Array.from(v.querySelectorAll('track'))) t.remove();
    v.removeAttribute('src');
    try { v.load(); } catch {}
  }

  stop() { this.token++; this.teardown(); this.src = null; this.current = null; }

  // ---- tracks ----
  audioTracks() {
    if (this.hls) return this.hls.audioTracks.map((t, i) => ({ id: i, label: t.name || t.lang || `Track ${i + 1}`, lang: t.lang, on: i === this.hls.audioTrack }));
    const at = this.v.audioTracks;
    if (at && at.length) return Array.from(at).map((t, i) => ({ id: i, label: t.label || t.language || `Track ${i + 1}`, lang: t.language, on: t.enabled }));
    return [];
  }
  setAudio(id) {
    if (this.hls) { this.hls.audioTrack = id; return; }
    const at = this.v.audioTracks;
    if (at) Array.from(at).forEach((t, i) => { t.enabled = i === id; });
  }
  subTracks() {
    if (this.hls && this.hls.subtitleTracks.length) {
      return this.hls.subtitleTracks.map((t, i) => ({ id: i, label: t.name || t.lang || `Subtitles ${i + 1}`, lang: t.lang, on: i === this.hls.subtitleTrack }));
    }
    return Array.from(this.v.textTracks || []).filter((t) => t.kind !== 'metadata').map((t, i) => ({ id: i, label: t.label || t.language || `Subtitles ${i + 1}`, lang: t.language, on: t.mode === 'showing', native: true }));
  }
  setSub(id) {
    if (this.hls && this.hls.subtitleTracks.length) { this.hls.subtitleTrack = id; this.hls.subtitleDisplay = id >= 0; return; }
    Array.from(this.v.textTracks || []).filter((t) => t.kind !== 'metadata').forEach((t, i) => { t.mode = i === id ? 'showing' : 'disabled'; });
  }
  addSubFile(vttText, label) {
    const url = URL.createObjectURL(new Blob([vttText], { type: 'text/vtt' }));
    const tr = document.createElement('track');
    tr.kind = 'subtitles'; tr.label = label; tr.src = url; tr.default = true;
    this.v.append(tr);
    setTimeout(() => {
      const list = Array.from(this.v.textTracks);
      list.forEach((t) => { t.mode = t.label === label ? 'showing' : 'disabled'; });
    }, 50);
  }
  levels() {
    if (!this.hls || !this.hls.levels || this.hls.levels.length < 2) return [];
    return this.hls.levels.map((l, i) => ({ id: i, label: l.height ? `${l.height}p` : `${Math.round(l.bitrate / 1000)} kbps`, bitrate: l.bitrate, height: l.height }));
  }
  get autoLevel() { return this.hls ? this.hls.autoLevelEnabled : true; }
  get level() { return this.hls ? this.hls.currentLevel : -1; }
  setLevel(id) { if (this.hls) this.hls.currentLevel = id; }

  stats() {
    const v = this.v;
    const q = v.getVideoPlaybackQuality ? v.getVideoPlaybackQuality() : null;
    let buf = 0;
    for (let i = 0; i < v.buffered.length; i++) {
      if (v.buffered.start(i) <= v.currentTime + 0.5 && v.buffered.end(i) >= v.currentTime) buf = v.buffered.end(i) - v.currentTime;
    }
    const s = {
      engine: this.name ? ({ hls: 'HLS (hls.js)', mpegts: 'MPEG-TS (mpegts.js)', flv: 'FLV (mpegts.js)', native: 'Native decoder' })[this.name] : '—',
      relay: this.current && this.current.relay ? 'On' : 'Off',
      res: v.videoWidth ? `${v.videoWidth} × ${v.videoHeight}` : '—',
      buffer: buf.toFixed(1) + ' s',
      dropped: q ? `${q.droppedVideoFrames} / ${q.totalVideoFrames}` : '—',
    };
    if (this.hls) {
      const l = this.hls.levels[this.hls.currentLevel];
      if (l) { s.bitrate = Math.round(l.bitrate / 1000) + ' kbps'; s.codec = [l.videoCodec, l.audioCodec].filter(Boolean).join(', '); }
      s.bandwidth = Math.round(this.hls.bandwidthEstimate / 1000) + ' kbps';
      if (this.hls.latency) s.latency = this.hls.latency.toFixed(1) + ' s';
    }
    if (this.mts) {
      const st = this.mts.statisticsInfo || {};
      const mi = this.mts.mediaInfo || {};
      if (st.speed) s.bandwidth = Math.round(st.speed * 8) + ' kbps';
      if (mi.videoCodec || mi.audioCodec) s.codec = [mi.videoCodec, mi.audioCodec].filter(Boolean).join(', ');
      if (mi.fps) s.fps = Math.round(mi.fps) + ' fps';
    }
    return s;
  }
}

function httpMessage(code) {
  if (code === 401 || code === 403) return `The provider refused this stream (${code}). It may not be available in your region.`;
  if (code === 451) return `This stream isn't available in your region (451).`;
  if (code === 404 || code === 410) return `This channel is offline (${code}).`;
  if (code === 429) return 'The channel is busy right now (too many requests). Try again in a minute.';
  if (code >= 500) return `The channel's server had a problem (${code}).`;
  return `The stream answered with an error (${code}).`;
}

function mediaError(err) {
  if (!err) return 'Playback failed.';
  return ({
    1: 'Playback was stopped.',
    2: 'The network dropped while loading the stream.',
    3: 'The stream uses a format this device cannot decode.',
    4: 'The stream format is not supported, or the address is unreachable.',
  })[err.code] || 'Playback failed.';
}
