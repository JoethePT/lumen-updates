// Remote-control navigation: spatial focus movement, layers and TV key mapping.
const FOCUSABLE = '.f, button:not([disabled]), input:not([disabled]), select, textarea, [tabindex="0"]';

const KEYMAP = {
  ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right',
  Up: 'up', Down: 'down', Left: 'left', Right: 'right',
  Enter: 'enter', ' ': 'space',
  Escape: 'back', BrowserBack: 'back', GoBack: 'back', XF86Back: 'back',
  MediaPlayPause: 'playpause', MediaPlay: 'play', MediaPause: 'pause', MediaStop: 'stop',
  MediaFastForward: 'ff', MediaRewind: 'rw', MediaTrackNext: 'chup', MediaTrackPrevious: 'chdown',
  ChannelUp: 'chup', ChannelDown: 'chdown', PageUp: 'chup', PageDown: 'chdown',
  ColorF0Red: 'red', ColorF1Green: 'green', ColorF2Yellow: 'yellow', ColorF3Blue: 'blue',
  Info: 'info', Guide: 'guide', ContextMenu: 'menu',
};
const KEYCODES = { 10009: 'back', 461: 'back', 8: 'back', 427: 'chup', 428: 'chdown', 33: 'chup', 34: 'chdown', 403: 'red', 404: 'green', 405: 'yellow', 406: 'blue', 415: 'play', 19: 'pause', 10252: 'playpause', 413: 'stop', 417: 'ff', 412: 'rw', 457: 'info', 458: 'guide' };

const layers = [];
const handlers = [];
const custom = new WeakMap();
const memory = new WeakMap();
let reduced = false;

export const nav = {
  setMotion(on) { reduced = !on; },

  scope() {
    for (let i = layers.length - 1; i >= 0; i--) if (layers[i].el.isConnected) return layers[i].el;
    return document.getElementById('app');
  },

  push(el, onBack) {
    layers.push({ el, onBack, prev: document.activeElement });
  },
  pop(el, restore = true) {
    const i = layers.findIndex((l) => l.el === el);
    if (i < 0) return;
    const [l] = layers.splice(i, 1);
    if (restore && l.prev && l.prev.isConnected) nav.focus(l.prev);
    else if (restore) nav.focusFirst(nav.scope());
  },
  top() { return layers[layers.length - 1]; },

  // Global key handlers (player, guide). Return true to consume.
  onKey(fn) { handlers.push(fn); return () => { const i = handlers.indexOf(fn); if (i >= 0) handlers.splice(i, 1); }; },
  custom(el, fn) { custom.set(el, fn); el.dataset.nav = '1'; },

  focus(el, opts = {}) {
    if (!el) return;
    el.focus({ preventScroll: true });
    const rem = el.parentElement && el.parentElement.closest('[data-remember]');
    if (rem) memory.set(rem, el);
    // Scroll instantly: a smooth scroll still running when the next key arrives makes the
    // next move measure positions mid-animation and land in the wrong place.
    if (opts.scroll !== false) el.scrollIntoView({ block: opts.block || 'nearest', inline: opts.inline || 'nearest', behavior: 'auto' });
  },

  focusFirst(root) {
    if (!root) return;
    const pref = root.querySelector('[data-autofocus]');
    const el = pref && visible(pref) ? pref : candidates(root)[0];
    if (el) nav.focus(el);
  },

  move(dir) {
    const scope = nav.scope();
    const cur = document.activeElement;
    if (!cur || cur === document.body || !scope.contains(cur)) { nav.focusFirst(scope); return true; }
    let list = candidates(scope);
    // Right from the rail goes back into the page: to where you were, or the item nearest in
    // height. The rail widens over the page when focused, so plain geometry finds nothing.
    if (dir === 'right' && cur.closest('#rail')) {
      const page = list.filter((el) => !el.closest('#rail') && onScreen(el.getBoundingClientRect()));
      if (lastPage && lastPage.isConnected && page.includes(lastPage)) { nav.focus(lastPage); return true; }
      const r = cur.getBoundingClientRect(), cy = r.top + r.height / 2;
      const dist = (el) => { const c = el.getBoundingClientRect(); return Math.abs(c.top + c.height / 2 - cy) + c.left * 0.3; };
      const pick = page.sort((a, b) => dist(a) - dist(b))[0];
      if (pick) nav.focus(pick);
      return true;
    }
    if (dir === 'up' || dir === 'down') {
      // In a side menu (the rail, Live TV groups, Settings sections) up and down stay in that
      // menu. The rail widens over the tiles when focused, so a tile underneath could
      // otherwise look closer than the next menu item.
      const col = cur.closest(COLUMN);
      if (col) {
        const inCol = nearest(cur, dir, list.filter((el) => col.contains(el)));
        if (inCol) { nav.focus(remembered(cur, inCol) || inCol); return true; }
        if (col.id === 'rail') return true;
      }
      // And from the page, up and down never land in the rail.
      list = list.filter((el) => !el.closest('#rail'));
    }
    const best = nearest(cur, dir, list);
    if (!best) return false;
    nav.focus(remembered(cur, best) || best);
    return true;
  },

  key(e) { return mapKey(e); },
};

function visible(el) {
  if (el.offsetParent === null && getComputedStyle(el).position !== 'fixed') return false;
  const r = el.getBoundingClientRect();
  return r.width > 0 && r.height > 0;
}

function candidates(scope) {
  return Array.from(scope.querySelectorAll(FOCUSABLE)).filter((el) => !el.closest('[inert], [data-nofocus]') && visible(el));
}

// The scrolling strip or list an element lives in (a row of tiles, a channel list…).
const STRIP = '.scroller, .vl, .chips, .groups, .set-nav, .ep-list, .menu, .side';
const COLUMN = '#rail, .groups, .set-nav, .side, .menu';
function strip(el) { return el.closest(STRIP); }

function onScreen(r) {
  return r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
}

// Scrolled out of its own strip (off the side of a row, or out of a list's window).
function clipped(el, c) {
  const s = strip(el);
  if (!s) return false;
  const b = s.getBoundingClientRect();
  return c.right <= b.left + 1 || c.left >= b.right - 1 || c.bottom <= b.top + 1 || c.top >= b.bottom - 1;
}

function nearest(cur, dir, list) {
  const r = cur.getBoundingClientRect();
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  const home = strip(cur);
  let best = null, bestScore = Infinity;
  for (const el of list) {
    if (el === cur || el.contains(cur)) continue;
    const c = el.getBoundingClientRect();
    // Items scrolled out of sight are only reachable along the strip you're already in.
    if (strip(el) !== home && clipped(el, c)) continue;
    const ccx = c.left + c.width / 2, ccy = c.top + c.height / 2;
    let primary, secondary;
    if (dir === 'right') {
      if (ccx <= cx + 1 || c.left < r.left + r.width * 0.5) continue;
      primary = Math.max(0, c.left - r.right);
      secondary = rangeGap(r.top, r.bottom, c.top, c.bottom);
    } else if (dir === 'left') {
      if (ccx >= cx - 1 || c.right > r.right - r.width * 0.5) continue;
      primary = Math.max(0, r.left - c.right);
      secondary = rangeGap(r.top, r.bottom, c.top, c.bottom);
    } else if (dir === 'down') {
      if (ccy <= cy + 1 || c.top < r.top + r.height * 0.5) continue;
      primary = Math.max(0, c.top - r.bottom);
      secondary = rangeGap(r.left, r.right, c.left, c.right);
    } else {
      if (ccy >= cy - 1 || c.bottom > r.bottom - r.height * 0.5) continue;
      primary = Math.max(0, r.top - c.bottom);
      secondary = rangeGap(r.left, r.right, c.left, c.right);
    }
    const align = dir === 'left' || dir === 'right' ? Math.abs(ccy - cy) : Math.abs(ccx - cx);
    const score = primary + secondary * 4 + align * 0.05;
    if (score < bestScore) { bestScore = score; best = el; }
  }
  return best;
}

function rangeGap(a1, a2, b1, b2) {
  if (b2 < a1) return a1 - b2;
  if (b1 > a2) return b1 - a2;
  return 0;
}

function remembered(cur, best) {
  const target = best.closest('[data-remember]');
  if (!target || target.contains(cur)) return null;
  const m = memory.get(target);
  // Only return to the last spot in a row if it's still on screen; otherwise take the nearest.
  return m && m.isConnected && visible(m) && onScreen(m.getBoundingClientRect()) ? m : null;
}

function mapKey(e) {
  return KEYMAP[e.key] || KEYCODES[e.keyCode] || (/^[0-9]$/.test(e.key) ? 'digit' : null);
}

document.addEventListener('keydown', (e) => {
  let k = mapKey(e);
  const t = e.target;
  const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA') && !['checkbox', 'range', 'radio', 'file'].includes(t.type);
  if (typing) {
    if (k === 'left' || k === 'right' || k === 'space' || k === 'digit' || k === 'chup' || k === 'chdown') return;
    if (e.key === 'Backspace') return;
    if (k === 'enter') { t.blur(); t.dispatchEvent(new Event('commit')); e.preventDefault(); return; }
  }
  if (e.key === 'Backspace' && !typing) k = 'back';
  if (!k && !e.key) return;

  for (let i = handlers.length - 1; i >= 0; i--) {
    if (handlers[i](k, e)) { e.preventDefault(); return; }
  }
  if (!k) return;

  if (['up', 'down', 'left', 'right'].includes(k)) {
    const host = t && t.closest && t.closest('[data-nav]');
    if (host && custom.get(host) && custom.get(host)(k, t, e)) { e.preventDefault(); return; }
    if (t && t.type === 'range' && (k === 'left' || k === 'right')) return;
    // Always handled here: an arrow left to Android moves its own focus, for example into the
    // search box, which then opens the on-screen keyboard.
    nav.move(k);
    e.preventDefault();
    return;
  }
  // Items with options (remove from a row…) open them when OK is held, or with the Menu key.
  const opt = t && t.lumenOptions ? t : null;
  if (opt && k === 'menu') { e.preventDefault(); openOptions(opt); return; }
  if (k === 'enter' && e.repeat) { e.preventDefault(); return; }
  if (k === 'enter' && t && t !== document.body) {
    if (t.tagName !== 'BUTTON' && t.tagName !== 'INPUT' && t.tagName !== 'SELECT' && t.tagName !== 'A') { e.preventDefault(); t.click(); }
    return;
  }
  if (k === 'back') {
    const top = nav.top();
    if (top && top.onBack) { e.preventDefault(); top.onBack(); return; }
    document.dispatchEvent(new CustomEvent('lumen:back', { cancelable: true }));
    e.preventDefault();
  }
});

// Hover effects (the rail opening under the pointer) only with a real mouse. Android TV leaves
// an invisible pointer "hovering" over whatever was selected last, which kept the rail open.
document.addEventListener('mousemove', (e) => { if (e.movementX || e.movementY) document.documentElement.classList.add('mouse'); });
document.addEventListener('keydown', (e) => { if (mapKey(e)) document.documentElement.classList.remove('mouse'); }, true);

// ---------- holding OK ----------
// Holding OK on anything with options opens its menu; a short press selects it as usual.
// Remotes keep sending OK while it's held, and some Android TVs don't mark those as repeats,
// so a press is tracked by time: OK signals less than GAP apart are the same press. Nothing
// from a press that opened the menu (repeats, the release, Android's own long-press) can
// choose an item in it, so "Add to Favourites" is never picked by accident.
const GAP = 300, HOLD = 550;
let press = null;          // { el, start, last, reps, fired, timer }
// The last thing focused on the page (not the rail or a dialog), for Right out of the rail.
let lastPage = null;
document.addEventListener('focusin', (e) => {
  const t = e.target;
  if (t && t.closest && !t.closest('#rail') && !t.closest('#layers')) lastPage = t;
});
let quietUntil = 0;        // OK signals before this belong to a press that has ended
let blockClicks = 0, lastEnter = 0;

function swallow(e) { e.preventDefault(); e.stopImmediatePropagation(); }

document.addEventListener('keydown', (e) => {
  if (mapKey(e) !== 'enter') return;
  const now = Date.now();
  lastEnter = now;
  if (press) { press.last = now; press.reps++; swallow(e); return; }
  if (now < quietUntil) { quietUntil = now + GAP; swallow(e); return; }
  const t = e.target;
  // Ordinary OK (handled below as before), or a screen that wants OK for itself right now.
  if (!t || !t.lumenOptions || document.documentElement.classList.contains('nav-plain-ok')) return;
  swallow(e);
  press = { el: t, start: now, last: now, reps: 0, fired: false, timer: 0 };
  press.timer = setTimeout(watch, 100);
}, true);

// While OK is down: open the menu once it's been held long enough, and notice a release
// even on remotes whose release never arrives (no repeats for GAP after we've seen some).
function watch() {
  if (!press) return;
  const now = Date.now();
  if (press.reps > 0 && now - press.last >= GAP) { release(); return; }
  if (!press.fired && now - press.start >= HOLD + 50) { press.fired = true; openOptions(press.el); }
  press.timer = setTimeout(watch, 80);
}

function release() {
  const p = press;
  press = null;
  clearTimeout(p.timer);
  const long = p.fired || Date.now() - p.start >= HOLD;
  if (long) {
    quietUntil = Date.now() + GAP;
    blockClicks = Date.now() + 400;
    if (!p.fired) openOptions(p.el);
    return;
  }
  if (p.el.isConnected) p.el.click();
}

document.addEventListener('keyup', (e) => {
  if (mapKey(e) !== 'enter') return;
  if (press) { swallow(e); release(); return; }
  // Android presses the focused item when OK comes back up; not after a hold.
  if (Date.now() < quietUntil || Date.now() < blockClicks) swallow(e);
}, true);

// One options menu at a time.
function openOptions(el) {
  if (document.querySelector('.menu')) return;
  el.lumenOptions();
}

// Android turns a held OK button into its own long-press as well, which arrives as a
// right-click; Lumen already opens the menu for the hold, so that one is ignored. A real
// right-click (mouse) still opens it.
document.addEventListener('contextmenu', (e) => {
  if (e.target.closest && e.target.closest('input, textarea')) return;
  e.preventDefault();
  if (press || Date.now() - lastEnter < 2500) return;
  const el = e.target.closest && e.target.closest('.f');
  if (el && el.lumenOptions) { nav.focus(el, { scroll: false }); openOptions(el); }
}, true);
document.addEventListener('click', (e) => {
  if (Date.now() < blockClicks) { e.preventDefault(); e.stopImmediatePropagation(); }
}, true);

// Hooks for the Android TV app, which owns the hardware Back and media keys.
// lumenBack() returns false when there is nowhere left to go back to, so the app can exit.
window.lumenBack = () => {
  const top = nav.top();
  if (top && top.onBack) { top.onBack(); return true; }
  const ev = new CustomEvent('lumen:back', { cancelable: true });
  document.dispatchEvent(ev);
  return ev.defaultPrevented;
};
window.lumenKey = (key) => {
  const target = document.activeElement || document.body;
  target.dispatchEvent(new KeyboardEvent('keydown', { key, bubbles: true, cancelable: true }));
};
