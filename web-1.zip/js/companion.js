// TV side of the phone & laptop companion. The phone page (/remote) queues commands on the
// Lumen server or the Android app; this module picks them up, runs them and reports back.
import { h, debounce, toast } from './util.js';
import { net } from './net.js';
import {
  S, bus, addPlaylist, removePlaylist, renamePlaylist, refreshPlaylist, setMain, setSource,
  setSetting, loadEpg, mainPlaylist, describeCounts,
} from './store.js';
import { providerOf } from './providers.js';

export const companion = {
  get info() { return net.info && net.info.companion ? net.info.companion : null; },
  get link() { const c = this.info; return c ? `${c.url}?pin=${c.pin}` : ''; },
};

function api(path, body) {
  const c = companion.info;
  const sep = path.includes('?') ? '&' : '?';
  return fetch(`${path}${sep}pin=${c.pin}`, body === undefined ? { cache: 'no-store' } : {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
}

function snapshot() {
  const main = mainPlaylist();
  return {
    at: Date.now(),
    playlists: S.playlists.map((p) => {
      const prov = providerOf(p);
      return {
        id: p.id, name: p.name, kind: p.kind, builtin: !!p.builtin, org: prov ? prov.org : '',
        main: main && main.id === p.id, enabled: p.enabled !== false, hideHome: !!p.hideHome,
        channels: S.srcCount.get(p.id) || 0, counts: p.counts || null,
        error: p.error || '', loading: S.syncing.has(p.id), updated: p.updated || 0,
      };
    }),
    epgUrls: S.settings.epgUrls,
    typing: typingState(),
  };
}

// ---------- typing from the phone ----------
// Whenever a text box on the TV is selected (Search, a playlist link, a name…), the phone page
// shows a keyboard for it and what you type appears on the TV as you type.
let target = null;
const isText = (t) => t && ((t.tagName === 'INPUT' && ['text', 'search', 'url', 'email', 'password', 'tel', ''].includes(t.type) && t.id !== 'pin-input') || t.tagName === 'TEXTAREA');
function labelOf(t) {
  const modal = t.closest('.modal');
  const lab = t.getAttribute('aria-label') || (t.closest('label') && t.closest('label').firstChild && t.closest('label').firstChild.textContent)
    || (modal && modal.querySelector('h2') && modal.querySelector('h2').textContent) || t.placeholder || 'Text';
  return String(lab).trim().slice(0, 60);
}
function typingState() {
  if (!target || !target.isConnected) return null;
  const secret = target.type === 'password';
  return { label: labelOf(target), value: secret ? '' : target.value, secret, at: Date.now() };
}
function typeText(value, submit) {
  if (!target || !target.isConnected) return;
  if (target.readOnly) target.readOnly = false;
  target.value = value;
  target.dispatchEvent(new Event('input', { bubbles: true }));
  if (submit) {
    target.dispatchEvent(new Event('commit'));
    target.dispatchEvent(new Event('change', { bubbles: true }));
    // Forms (add a playlist, a guide link) submit as if you pressed Enter.
    const form = target.form;
    if (form && form.requestSubmit) form.requestSubmit();
  }
}

// A small card in the corner of the TV while a text box is selected: scan it to type on your phone.
let card = null;
function showCard(on) {
  const c = companion.info;
  // Only on a TV: with a mouse and keyboard you'd type right here.
  const tv = /LumenTV/.test(navigator.userAgent) || (!matchMedia('(pointer: fine)').matches && !matchMedia('(pointer: coarse)').matches);
  if (!on || !c || !tv) { if (card) { card.remove(); card = null; } return; }
  if (card) return;
  const qr = window.qrcode ? window.qrcode(0, 'M') : null;
  let svg = '';
  if (qr) { qr.addData(companion.link + '#type'); qr.make(); svg = qr.createSvgTag({ scalable: true, margin: 2 }); }
  card = h('div.type-card.glass-strong', h('div.pair-qr', { html: svg }),
    h('div', h('div.t', 'Type on your phone'), h('div.d', 'Scan, or open Lumen Remote if your phone is already connected.')));
  document.body.append(card);
}
document.addEventListener('focusin', (e) => {
  if (!companion.info) return;
  if (isText(e.target)) {
    if (target !== e.target) { target = e.target; pushState(); }
    showCard(true);
  } else showCard(false);
});
document.addEventListener('input', (e) => { if (e.target === target && e.isTrusted) pushState(); });

const pushState = debounce(() => { api('/api/tv/state', snapshot()).catch(() => {}); }, 400);

async function run(cmd, progress) {
  switch (cmd.type) {
    case 'add': {
      const def = { ...cmd.def };
      if (def.kind === 'm3u-text') def.kind = 'm3u-file';
      const pl = await addPlaylist(def, (step) => progress(step + '…'));
      const n = S.srcCount.get(pl.id) || pl.counts.live;
      toast(`Added from your phone: ${pl.name} · ${n.toLocaleString()} channels`);
      const plural = (k, one, many) => `${k.toLocaleString()} ${k === 1 ? one : many}`;
      return `Added ${pl.name}: ${describeCounts(pl.counts)}.`;
    }
    case 'remove': await removePlaylist(cmd.plId); return 'Removed.';
    case 'rename': renamePlaylist(cmd.plId, cmd.name); return 'Renamed.';
    case 'main': setMain(cmd.plId); return 'This is now the main playlist.';
    case 'refresh': await refreshPlaylist(cmd.plId, (step) => progress(step + '…')); return 'Refreshed.';
    case 'source': await setSource(cmd.plId, cmd.patch); return 'Updated.';
    case 'epg-add':
      if (!/^https?:\/\//i.test(cmd.url || '')) throw new Error('Enter a guide link that starts with http:// or https://');
      setSetting('epgUrls', [...new Set([...S.settings.epgUrls, cmd.url])]);
      loadEpg(true).catch(() => {});
      return 'Guide added. It downloads in the background.';
    case 'epg-remove': setSetting('epgUrls', S.settings.epgUrls.filter((u) => u !== cmd.url)); return 'Guide removed.';
    default: throw new Error('Lumen on the TV does not understand this request. Update the app.');
  }
}

let started = false;
export function startCompanion() {
  if (started || !companion.info) return;
  started = true;
  for (const ev of ['library', 'sources', 'settings']) bus.on(ev, pushState);
  pushState();
  // Checking in and running requests are separate, so the phone keeps seeing the TV as
  // connected while a large playlist downloads.
  const queue = [];
  let working = false;
  async function work() {
    if (working) return;
    working = true;
    while (queue.length) {
      const cmd = queue.shift();
      let chain = Promise.resolve();
      let last = 0;
      const progress = (message, force) => {
        if (!force && Date.now() - last < 700) return chain;
        last = Date.now();
        chain = chain.then(() => api('/api/tv/result', { id: cmd.id, pending: true, message })).catch(() => {});
        return chain;
      };
      await progress('Working on it…', true);
      let result;
      try { result = { id: cmd.id, ok: true, message: await run(cmd, progress) }; } catch (e) { result = { id: cmd.id, ok: false, message: e.message || String(e) }; toast(`From your phone: ${result.message}`); }
      await chain;
      await api('/api/tv/result', result).catch(() => {});
      pushState();
    }
    working = false;
  }
  // Check in every 2 seconds, or about three times a second while a text box can be typed into
  // from the phone, so letters keep up with your typing.
  async function poll() {
    if (target && !target.isConnected) { target = null; showCard(false); pushState(); }
    try {
      const r = await api('/api/tv/commands');
      const { commands } = await r.json();
      if (commands && commands.length) {
        // Typing is applied at once, newest last; everything else goes through the queue.
        for (const c of commands) if (c.type === 'text') typeText(c.value || '', c.submit);
        const rest = commands.filter((c) => c.type !== 'text');
        if (rest.length) { queue.push(...rest); work(); }
      }
    } catch {}
    setTimeout(poll, target ? 350 : 2000);
  }
  poll();
}

export async function newPin() {
  const r = await api('/api/tv/new-pin', {});
  const j = await r.json();
  if (net.info && net.info.companion) net.info.companion.pin = j.pin;
  return j.pin;
}

// QR code + address + PIN, for the add-playlist dialog, welcome screen and settings.
export function pairPanel(opts = {}) {
  const c = companion.info;
  if (!c) return null;
  const qr = window.qrcode ? window.qrcode(0, 'M') : null;
  let svg = '';
  if (qr) { qr.addData(companion.link); qr.make(); svg = qr.createSvgTag({ scalable: true, margin: 2 }); }
  return h('div.pair' + (opts.large ? '.pair-lg' : ''),
    h('div.pair-qr', { html: svg }),
    h('div.pair-txt',
      h('div.eyebrow', 'Use your phone or laptop'),
      h('div.pair-title', opts.title || 'Scan to add playlists without the remote'),
      h('div.pair-step', 'Or open this on any device on the same Wi-Fi:'),
      h('div.pair-url', c.url.replace(/^http:\/\//, '')),
      h('div.pair-pin', h('span', 'PIN'), h('b.tnum', c.pin.replace(/(\d{3})(\d{3})/, '$1 $2'))),
    ),
  );
}
