// Network layer: knows whether the Lumen relay is reachable and routes requests
// through it when a provider blocks cross-origin access.
export const net = {
  relay: false,
  mode: 'auto', // auto | always | never

  async detect() {
    try {
      const r = await fetch('/api/ping', { cache: 'no-store' });
      const j = await r.json();
      this.relay = !!(j && j.proxy);
      this.info = j;
    } catch { this.relay = false; this.info = null; }
    return this.relay;
  },

  wrap(url, ua, ref) {
    if (!this.relay || !/^https?:/i.test(url)) return url;
    let u = '/proxy?url=' + encodeURIComponent(url);
    if (ua) u += '&ua=' + encodeURIComponent(ua);
    if (ref) u += '&ref=' + encodeURIComponent(ref);
    return u;
  },

  // Should the first attempt for this stream already go through the relay?
  relayFirst(url, item = {}) {
    if (!this.relay || this.mode === 'never') return false;
    if (this.mode === 'always') return true;
    if (item.ua || item.ref) return true;
    if (this.needsRelay(url)) return true;
    return location.protocol === 'https:' && /^http:/i.test(url);
  },

  // Hosts whose streams only play through the relay (no CORS headers). jmp2.uk fronts
  // Pluto, Samsung TV Plus and Roku; others are learned as channels are watched.
  needsRelay(url) {
    const host = hostOf(url);
    return !!host && (KNOWN_RELAY.includes(host) || learned().includes(host));
  },
  rememberRelay(url) {
    const host = hostOf(url);
    if (!host || this.needsRelay(url)) return;
    const list = learned();
    list.unshift(host);
    try { localStorage.setItem('lumen.relayHosts', JSON.stringify(list.slice(0, 200))); } catch {}
  },

  async fetch(url, opts = {}) {
    const direct = !this.relay || this.mode === 'never' || (this.mode === 'auto' && !(location.protocol === 'https:' && /^http:/i.test(url)));
    if (direct) {
      try {
        const r = await fetch(url, opts);
        if (r.ok || !this.relay) return r;
      } catch (e) {
        if (!this.relay || this.mode === 'never') throw new Error(corsHint(url));
      }
    }
    return fetch(this.wrap(url), opts);
  },

  // Downloads text with progress, and gives up if the server goes quiet instead of waiting forever.
  async text(url, { onProgress, idleMs = 45000 } = {}) {
    const directOk = !this.relay || this.mode === 'never' || (this.mode === 'auto' && !this.needsRelay(url) && !(location.protocol === 'https:' && /^http:/i.test(url)));
    const tries = [];
    if (directOk) tries.push(url);
    if (this.relay && this.mode !== 'never') tries.push(this.wrap(url));
    let lastErr;
    for (const u of tries) {
      const ctrl = new AbortController();
      let timer;
      const arm = () => { clearTimeout(timer); timer = setTimeout(() => ctrl.abort(), idleMs); };
      try {
        arm();
        const r = await fetch(u, { signal: ctrl.signal });
        if (!r.ok) {
          clearTimeout(timer);
          lastErr = new Error(r.status === 502 || r.status === 504
            ? 'The provider didn\u2019t respond. Try again later, or check the link.'
            : `The provider answered ${r.status}${r.status === 401 || r.status === 403 ? '. Check the link, or whether your subscription is active' : ''}.`);
          if (r.status >= 400 && r.status < 500 && r.status !== 403) throw lastErr;
          continue;
        }
        const total = Number(r.headers.get('content-length')) || 0;
        const reader = r.body.getReader();
        const chunks = [];
        let got = 0, lastTick = 0;
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          arm();
          chunks.push(value);
          got += value.length;
          if (onProgress && Date.now() - lastTick > 1000) { lastTick = Date.now(); onProgress(got, total); }
        }
        clearTimeout(timer);
        const buf = new Uint8Array(got);
        let off = 0;
        for (const c of chunks) { buf.set(c, off); off += c.length; }
        return decodeBody(new Response(buf));
      } catch (e) {
        clearTimeout(timer);
        if (e === lastErr) throw e;
        lastErr = ctrl.signal.aborted ? new Error('The provider stopped responding. Try again later, or check the link.') : new Error(corsHint(url));
      }
    }
    throw lastErr || new Error(corsHint(url));
  },
};

const KNOWN_RELAY = ['jmp2.uk', 'epg.provider.plex.tv'];
function hostOf(url) { try { return new URL(url, location.href).host; } catch { return ''; } }
function learned() { try { return JSON.parse(localStorage.getItem('lumen.relayHosts')) || []; } catch { return []; } }

function corsHint(url) {
  return `Couldn't reach ${new URL(url, location.href).host}. The provider blocks browser access; run Lumen with its server (node server.js) so it can relay the request.`;
}

export async function decodeBody(res) {
  const buf = new Uint8Array(await res.arrayBuffer());
  if (buf[0] === 0x1f && buf[1] === 0x8b && 'DecompressionStream' in window) {
    const ds = new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'));
    return new Response(ds).text();
  }
  return new TextDecoder('utf-8').decode(buf);
}

export async function fileText(file) {
  if (/\.gz$/i.test(file.name) && 'DecompressionStream' in window) {
    return new Response(file.stream().pipeThrough(new DecompressionStream('gzip'))).text();
  }
  return file.text();
}
