// Android TV: playback through the app's native player (Media3 ExoPlayer) instead of the
// WebView's <video>. NativeVideo mimics the parts of HTMLVideoElement the player screen
// uses, and NativeEngine mimics Engine, so the rest of the interface doesn't change.
import { Emitter } from './util.js';

const bridge = window.LumenNative || null;
export const hasNative = () => !!bridge;

// The app delivers player events here.
const listeners = new Set();
window.lumenNativeEvent = (ev) => { for (const fn of listeners) fn(ev); };

export class NativeVideo extends EventTarget {
  constructor() {
    super();
    this.pos = 0; this.dur = NaN; this.buf = 0; this.live = false;
    this._paused = true; this._muted = false; this._rate = 1;
    this.videoWidth = 0; this.videoHeight = 0; this.readyState = 0; this.error = null;
    this.textTracks = [];
    this.at = performance.now();
    listeners.add((ev) => this.onEvent(ev));
  }

  onEvent(ev) {
    switch (ev.type) {
      case 'time':
        this.pos = ev.pos / 1000; this.dur = ev.dur > 0 && !ev.live ? ev.dur / 1000 : NaN; this.buf = ev.buf / 1000; this.live = ev.live;
        this.at = performance.now();
        this.fire('timeupdate');
        break;
      case 'ready': this.readyState = 4; this.fire('loadeddata'); break;
      case 'playing': this._paused = false; this.fire('playing'); break;
      case 'paused': this._paused = true; this.fire('pause'); break;
      case 'waiting': this.fire('waiting'); break;
      case 'ended': this._paused = true; this.fire('ended'); break;
      case 'size': this.videoWidth = ev.w; this.videoHeight = ev.h; break;
      case 'cues': this.dispatchEvent(Object.assign(new Event('cues'), { text: ev.text || '' })); break;
      default: break;
    }
  }

  fire(name) { this.dispatchEvent(new Event(name)); }

  get currentTime() {
    // Interpolate between the app's twice-a-second updates so the seek bar moves smoothly.
    return this._paused ? this.pos : this.pos + ((performance.now() - this.at) / 1000) * this._rate;
  }
  set currentTime(s) { this.pos = s; this.at = performance.now(); bridge.seekTo(Math.round(s * 1000)); }
  get duration() { return this.dur; }
  get paused() { return this._paused; }
  get buffered() { const end = this.buf; return { length: end > 0 ? 1 : 0, start: () => 0, end: () => end }; }
  get muted() { return this._muted; }
  set muted(v) { this._muted = !!v; bridge.setVolume(v ? 0 : 1); }
  get playbackRate() { return this._rate; }
  set playbackRate(r) { this._rate = r; bridge.setSpeed(r); }
  play() { bridge.resume(); return Promise.resolve(); }
  pause() { bridge.pause(); }
  getVideoPlaybackQuality() {
    try { const s = JSON.parse(bridge.stats()); return { droppedVideoFrames: s.dropped || 0, totalVideoFrames: s.rendered || 0 }; } catch { return null; }
  }
  requestPictureInPicture() { return Promise.reject(new Error('unsupported')); }
}

export class NativeEngine extends Emitter {
  constructor(video) {
    super();
    this.v = video;
    this.name = 'native';
    this.tracks = { audio: [], text: [], video: [], auto: true };
    this.token = 0;
    this.current = { relay: false };
    listeners.add((ev) => {
      if (ev.token != null && ev.token !== this.token) return;
      if (ev.type === 'tracks') { this.tracks = ev; this.emit('tracks'); }
      if (ev.type === 'ready' && this.pending) { const p = this.pending; this.pending = null; p.resolve(true); }
      if (ev.type === 'error') {
        this.v.readyState = 0;
        document.dispatchEvent(new CustomEvent('lumen:native-error'));
        if (this.pending) { const p = this.pending; this.pending = null; this.emit('fatal', ev.message); p.resolve(false); }
        else this.emit('fatal-runtime', ev.message);
      }
    });
  }

  load(src, startAt = 0) {
    if (this.pending) this.pending.resolve(false);
    const tok = ++this.token;
    this.src = src;
    this.v.readyState = 0;
    this.tracks = { audio: [], text: [], video: [], auto: true };
    return new Promise((resolve) => {
      this.pending = { resolve };
      bridge.play(JSON.stringify({
        token: tok, url: src.url, ua: src.ua || '', ref: src.ref || '', live: !!src.live,
        startMs: Math.round((startAt || 0) * 1000), lowLatency: !!(this.opts && this.opts.lowLatency),
      }));
    });
  }

  stop() { this.token++; this.v.readyState = 0; if (this.pending) { this.pending.resolve(false); this.pending = null; } this.src = null; bridge.stop(); }

  audioTracks() { return this.tracks.audio.map((t) => ({ id: t.id, label: t.label, lang: t.lang, on: t.on })); }
  setAudio(id) { bridge.selectTrack('audio', String(id)); }
  subTracks() { return this.tracks.text.map((t) => ({ id: t.id, label: t.label, lang: t.lang, on: t.on })); }
  setSub(id) { bridge.selectTrack('text', String(id)); }
  // Subtitle file (already WebVTT): Lumen's own server holds it, the player reads it from there.
  // Resolves with the file's addresses, so a Chromecast on the Wi-Fi can be sent it too.
  async addSubFile(vtt, label, lang = '') {
    const sub = await uploadSub(vtt);
    bridge.addSubtitle(JSON.stringify({ url: sub.local, label, lang }));
    return sub;
  }
  levels() {
    const v = this.tracks.video;
    return v.length > 1 ? v.map((t) => ({ id: t.id, label: t.height ? `${t.height}p` : t.label, bitrate: t.bitrate || 0, height: t.height })) : [];
  }
  get autoLevel() { return this.tracks.auto; }
  get level() { const t = this.tracks.video.find((x) => x.on); return t ? t.id : -1; }
  setLevel(id) { bridge.selectTrack('video', String(id)); }
  stats() {
    let s = {};
    try { s = JSON.parse(bridge.stats()); } catch {}
    return {
      engine: 'Android player (ExoPlayer)', relay: 'Not needed',
      res: s.w ? `${s.w} × ${s.h}` : '—', buffer: s.buffer != null ? (s.buffer / 1000).toFixed(1) + ' s' : '—',
      bitrate: s.bitrate ? Math.round(s.bitrate / 1000) + ' kbps' : undefined,
      bandwidth: s.bandwidth ? Math.round(s.bandwidth / 1000) + ' kbps' : undefined,
      codec: [s.vcodec, s.acodec].filter(Boolean).join(', ') || undefined,
      fps: s.fps ? Math.round(s.fps) + ' fps' : undefined,
      dropped: s.rendered != null ? `${s.dropped} / ${s.rendered}` : '—',
      decoder: s.decoder || undefined,
    };
  }
}

// Where the native picture goes: hidden, a window over an element, or the whole screen.
export async function uploadSub(vtt) {
  const r = await fetch('/api/subs', { method: 'POST', headers: { 'Content-Type': 'text/vtt' }, body: vtt });
  if (!r.ok) throw new Error('Couldn’t load the subtitle file.');
  return r.json();
}

export function nativeLayout(mode, el, aspect, radius = 0) {
  if (!bridge) return;
  const r = el ? el.getBoundingClientRect() : { left: 0, top: 0, width: 0, height: 0 };
  bridge.setLayout(JSON.stringify({ mode, x: r.left, y: r.top, w: r.width, h: r.height, iw: window.innerWidth, aspect: aspect || 'fit', radius }));
  document.documentElement.classList.toggle('native-full', mode === 'full');
}

export function nativePrefs(audioLang, subLang) {
  if (bridge && bridge.setPreferences) bridge.setPreferences(audioLang || '', subLang || '');
}
