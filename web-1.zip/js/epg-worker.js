// XMLTV parser that streams the file, so 100 MB+ guides don't freeze the TV.
/* eslint-env worker */

function parseTime(s, shiftMin) {
  // 20261020143000 +0100
  const m = /^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)?\s*([+-]\d{4})?/.exec(s || '');
  if (!m) return 0;
  let t = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  if (m[7]) {
    const sign = m[7][0] === '-' ? -1 : 1;
    t -= sign * (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000;
  }
  return t + (shiftMin || 0) * 60000;
}

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
function unesc(s) {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&(#x?[0-9a-f]+|\w+);/gi, (m, e) => {
      if (e[0] === '#') return String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1));
      return ENT[e] ?? m;
    }).trim();
}

function attr(tag, name) {
  const m = new RegExp(name + '\\s*=\\s*"([^"]*)"|' + name + "\\s*=\\s*'([^']*)'").exec(tag);
  return m ? unesc(m[1] ?? m[2]) : '';
}

function inner(block, tag) {
  const m = new RegExp('<' + tag + '\\b[^>]*>([\\s\\S]*?)</' + tag + '>').exec(block);
  return m ? unesc(m[1]) : '';
}

self.onmessage = async (ev) => {
  const { url, text, from, to, shift, want, lite, maxProgs = Infinity } = ev.data;
  const wantIds = want ? new Set(want.ids) : null;
  const wantNames = want ? new Set(want.names) : null;
  const keep = new Set();
  const norm = (s) => String(s || '').toLowerCase().replace(/\[[^\]]*\]|\([^)]*\)/g, '').replace(/\b(hd|fhd|uhd|sd|4k|hevc|h265|backup|\+1)\b/g, '').replace(/[^a-z0-9]/g, '');
  const channels = {};
  const progs = {};
  let count = 0;

  function handle(block) {
    if (block.startsWith('<channel')) {
      const id = attr(block.slice(0, block.indexOf('>') + 1), 'id');
      if (!id) return;
      const names = [];
      const rx = /<display-name\b[^>]*>([\s\S]*?)<\/display-name>/g;
      let m;
      while ((m = rx.exec(block))) names.push(unesc(m[1]));
      const icon = /<icon\b[^>]*src\s*=\s*"([^"]*)"/.exec(block);
      if (wantIds && !wantIds.has(id.toLowerCase()) && !names.some((n) => wantNames.has(norm(n)))) return;
      keep.add(id);
      channels[id] = { names, icon: icon ? unesc(icon[1]) : '' };
      return;
    }
    const open = block.slice(0, block.indexOf('>') + 1);
    const start = parseTime(attr(open, 'start'), shift);
    const stop = parseTime(attr(open, 'stop'), shift) || start + 3600000;
    if (stop < from || start > to) return;
    const ch = attr(open, 'channel');
    if (!ch || count >= maxProgs) return;
    if (wantIds && !keep.has(ch) && !wantIds.has(ch.toLowerCase())) return;
    const icon = /<icon\b[^>]*src\s*=\s*"([^"]*)"/.exec(block);
    let ep = inner(block, 'episode-num');
    const ns = /system\s*=\s*"xmltv_ns"[^>]*>([^<]*)</.exec(block);
    if (ns) {
      const [s, e] = ns[1].split('.');
      const sn = parseInt(s, 10), en = parseInt(e, 10);
      if (!isNaN(sn) && !isNaN(en)) ep = `S${sn + 1} E${en + 1}`;
    }
    (progs[ch] ||= []).push(lite
      ? [start, stop, inner(block, 'title'), '', inner(block, 'category'), ep, '', '', 0]
      : [
        start, stop, inner(block, 'title'), inner(block, 'desc'),
        inner(block, 'category'), ep, icon ? unesc(icon[1]) : '',
        inner(block, 'sub-title'), /<new\s*\/>/.test(block) ? 1 : 0,
      ]);
    count++;
  }

  let buf = '';
  function drain(final) {
    let pos = 0;
    for (;;) {
      const c = buf.indexOf('<channel', pos);
      const p = buf.indexOf('<programme', pos);
      let s, endTag;
      if (c === -1 && p === -1) break;
      if (p === -1 || (c !== -1 && c < p)) { s = c; endTag = '</channel>'; } else { s = p; endTag = '</programme>'; }
      // Self-closing programme with no children
      const gt = buf.indexOf('>', s);
      if (gt !== -1 && buf[gt - 1] === '/') { handle(buf.slice(s, gt + 1)); pos = gt + 1; continue; }
      const e = buf.indexOf(endTag, s);
      if (e === -1) { pos = s; break; }
      handle(buf.slice(s, e + endTag.length));
      pos = e + endTag.length;
    }
    buf = final ? '' : buf.slice(pos);
  }

  try {
    if (text) {
      buf = text; drain(true);
    } else {
      const res = await fetch(url);
      if (!res.ok) throw new Error('Guide download failed (' + res.status + ')');
      let stream = res.body;
      const reader0 = stream.getReader();
      const first = await reader0.read();
      reader0.releaseLock();
      // Re-assemble the stream with the first chunk, and gunzip if needed.
      const head = first.value || new Uint8Array();
      const rest = stream;
      const joined = new ReadableStream({
        async start(ctrl) {
          if (head.length) ctrl.enqueue(head);
          const r = rest.getReader();
          for (;;) { const { done, value } = await r.read(); if (done) break; ctrl.enqueue(value); }
          ctrl.close();
        },
      });
      stream = head[0] === 0x1f && head[1] === 0x8b ? joined.pipeThrough(new DecompressionStream('gzip')) : joined;
      const reader = stream.pipeThrough(new TextDecoderStream()).getReader();
      let bytes = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += value; bytes += value.length;
        if (buf.length > 1 << 20) drain(false);
        if (bytes > 4 << 20) { self.postMessage({ progress: count }); bytes = 0; }
      }
      drain(true);
    }
    for (const k in progs) progs[k].sort((a, b) => a[0] - b[0]);
    self.postMessage({ done: true, channels, progs, count });
  } catch (err) {
    self.postMessage({ error: String(err && err.message || err) });
  }
};
