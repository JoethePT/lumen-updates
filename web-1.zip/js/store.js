// Central state: playlists, indexes, favourites, history, reminders, EPG.
import { db } from './db.js';
import { ls, hash, normName, Emitter } from './util.js';
import { parseM3U } from './m3u.js';
import { net, fileText } from './net.js';
import { PROVIDERS } from './providers.js';
import { countryOf, groupRank, stripCountry, BUCKETS } from './countries.js';
import { xtreamCategory } from './xtream.js';
import { xtreamLoad, xtreamSeriesInfo, xtreamVodInfo, xtreamCatchupUrl } from './xtream.js';

export const bus = new Emitter();

const DEFAULTS = {
  theme: 'dark', accent: '#0A84FF', clock24: true, glass: true, motion: true,
  relay: 'auto', engine: 'auto', lowLatency: false, reconnect: true, aspect: 'fit',
  audioLang: '', subLang: '', subSize: 100, subBg: true, autoNext: true, resume: true,
  pin: '', lockedGroups: [], hiddenGroups: [], hideAdult: true,
  epgShift: 0, epgUrls: [], epgAuto: true, showNumbers: true, previewPlay: true,
  refreshOnStart: false, xcLiveFormat: 'm3u8', hideGeo: false, freeOnHome: 'auto', countries: [], countryHint: true, quality: 'all', favGroups: [], homeOrder: [], homeHidden: [], svcOrder: [], svcHidden: [], myList: [], autoBackup: true, vodLangs: [], uiScale: 'auto',
};

const ADULT = /\b(xxx|adult|18\+|porn|for adults)\b/i;

export const S = {
  settings: { ...DEFAULTS, ...ls.get('settings', {}) },
  playlists: ls.get('playlists', []),
  items: [], live: [], movies: [], shows: [], episodes: [],
  byId: new Map(), showById: new Map(),
  groups: { live: [], movie: [], series: [] },
  favs: new Set(ls.get('favs', [])),
  history: ls.get('history', []),
  reminders: ls.get('reminders', []),
  epg: { map: new Map(), count: 0, updated: 0, loading: false },
  srcCount: new Map(), syncing: new Set(),
  lazyCats: [], lazyLoaded: new Map(), snaps: new Map(Object.entries(ls.get('snaps', {}))),
  unlocked: false,
  meta: new Map(),
};

export function saveSettings() { ls.set('settings', S.settings); bus.emit('settings', S.settings); }
export function setSetting(k, v) { S.settings[k] = v; saveSettings(); }
function savePlaylists() { ls.set('playlists', S.playlists); }

// ---------- playlists ----------

// Your own playlists come first (main playlist on top), then the built-in sources in catalogue order.
export function orderedPlaylists() {
  const rank = (p) => (p.builtin ? 100 + PROVIDERS.findIndex((x) => x.key === p.builtin) : p.main ? 0 : 1);
  return S.playlists.slice().sort((a, b) => rank(a) - rank(b));
}

export async function loadLibrary() {
  const all = [];
  const shows = [];
  const seen = new Map();
  S.srcCount = new Map();
  S.lazyCats = [];
  for (const pl of orderedPlaylists()) {
    if (pl.enabled === false) continue;
    const data = await db.get('pl:' + pl.id);
    if (!data) continue;
    let n = 0;
    for (const it of data.items) {
      // The same stream often appears in several lists: keep one copy and remember
      // every source (and that source's group) it belongs to.
      const key = it.url.trim();
      const prev = seen.get(key);
      if (prev) {
        if (!prev.srcs.includes(pl.id)) { prev.srcs.push(pl.id); prev.sg[pl.id] = it.group; n++; }
        continue;
      }
      it.srcs = [pl.id];
      it.sg = { [pl.id]: it.group };
      seen.set(key, it);
      all.push(it);
      n++;
    }
    S.srcCount.set(pl.id, n);
    shows.push(...(data.shows || []));
    for (const type of ['movie', 'series']) for (const c of (data.cats && data.cats[type]) || []) S.lazyCats.push({ pl: pl.id, type, id: c.id, name: c.name });
  }
  buildIndex(all, shows);
}

export function sourceItems(plId, type = 'live') {
  const list = type === 'live' ? S.live : type === 'movie' ? S.movies : S.episodes;
  return list.filter((i) => i.srcs && i.srcs.includes(plId));
}

export function sourceGroups(plId) {
  const m = new Map(), cc = new Map();
  for (const i of visible('live', sourceItems(plId))) {
    const g = i.sg[plId] || i.group;
    m.set(g, (m.get(g) || 0) + 1);
    if (!cc.has(g)) cc.set(g, i.cc);
  }
  const pick = S.settings.countries;
  const out = [...m].map(([name, count]) => ({ name, count, rank: pick.length ? pick.indexOf(cc.get(name)) * 100 + groupRank(name) : 0 }));
  return pick.length ? out.sort((a, b) => a.rank - b.rank || a.name.localeCompare(b.name)) : out;
}

function buildIndex(items, xtShows) {
  S.items = items;
  S.byId = new Map(items.map((i) => [i.id, i]));
  S.live = items.filter((i) => i.type === 'live');
  for (const ch of S.live) {
    ch.cc = countryOf(ch);
    ch.qv = qualityOf(ch);
    ch.bk = BACKUP.test(ch.name);
    ch.base = ch.cc + '|' + baseName(ch.name);
    // Providers pad their lists with heading entries such as "✦●✦ GENERAL ✦●✦" or "##### UK #####".
    if (/^\s*[^\p{L}\p{N}\s[(]{2,}.*[^\p{L}\p{N}\s\])]{2,}\s*$|^\s*#{3,}/u.test(ch.name)) ch.divider = true;
    const short = stripCountry(ch.name);
    if (short !== ch.name) { if (!ch.tvgName) ch.tvgName = ch.name; ch.name = short; }
  }
  // Every copy of a channel, for switching to a backup when one fails.
  S.byBase = new Map();
  for (const ch of S.live) {
    if (ch.divider || !ch.base) continue;
    const list = S.byBase.get(ch.base);
    if (list) list.push(ch); else S.byBase.set(ch.base, [ch]);
  }
  S.movies = items.filter((i) => i.type === 'movie');
  S.episodes = items.filter((i) => i.type === 'series');

  // Number channels the way a set-top box would when the playlist doesn't.
  let n = 0;
  for (const ch of S.live) { n = ch.chno && ch.chno > n ? ch.chno : n + 1; ch.num = ch.chno || n; }

  // Fold M3U episodes into shows.
  const showMap = new Map();
  for (const ep of S.episodes) {
    const key = ep.pl + '|' + normName(ep.ep.show);
    let sh = showMap.get(key);
    if (!sh) {
      sh = { id: hash('show|' + key), pl: ep.pl, name: ep.ep.show, logo: ep.logo, group: ep.group, episodes: [], year: ep.year || 0 };
      showMap.set(key, sh);
    }
    ep.showId = sh.id;
    sh.episodes.push(ep);
  }
  for (const sh of showMap.values()) sh.episodes.sort((a, b) => a.ep.s - b.ep.s || a.ep.e - b.ep.e);
  S.shows = [...showMap.values(), ...(xtShows || [])];
  S.showById = new Map(S.shows.map((s) => [s.id, s]));

  // Groups from your own playlists keep their order; groups that only come from free sources follow A–Z.
  const builtin = new Set(S.playlists.filter((p) => p.builtin).map((p) => p.id));
  const groupsOf = (list) => {
    const m = new Map();
    for (const i of list) {
      const g = m.get(i.group);
      if (g) g.count++; else m.set(i.group, { name: i.group, count: 1, free: builtin.has(i.pl) });
    }
    const all = [...m.values()];
    const own = all.filter((g) => !g.free), free = all.filter((g) => g.free).sort((a, b) => a.name.localeCompare(b.name));
    return [...own, ...free].map(({ name, count }) => ({ name, count }));
  };
  S.groups.live = groupsOf(S.live);
  // Categories that load on demand join the list with an unknown count.
  const withLazy = (type, groups) => {
    const have = new Set(groups.map((g) => g.name));
    for (const c of S.lazyCats) if (c.type === type && !have.has(c.name)) { have.add(c.name); groups.push({ name: c.name, count: null, lazy: true }); }
    return groups;
  };
  S.groups.movie = withLazy('movie', groupsOf(S.movies));
  S.groups.series = withLazy('series', groupsOf(S.shows));
  matchEpg();
  bus.emit('library');
}

export function groupKey(type, g) { return type + ':' + g; }
export function isHidden(type, g) {
  return S.settings.hiddenGroups.includes(groupKey(type, g)) || (S.settings.hideAdult && ADULT.test(g) && !S.unlocked);
}
export function isLocked(type, g) {
  return !!S.settings.pin && !S.unlocked && (S.settings.lockedGroups.includes(groupKey(type, g)) || ADULT.test(g));
}
export function visibleGroups(type) {
  const groups = S.groups[type].filter((g) => !isHidden(type, g.name) && (type === 'live' || catAllowed(g.name)));
  const pick = S.settings.countries;
  if (type !== 'live' || !pick.length) return groups;
  // With countries chosen: only groups that still have channels, your countries' groups in the
  // order you picked them, and within a country the main channels first and events last.
  const counts = new Map(), cc = new Map();
  for (const ch of visible('live', S.live)) {
    counts.set(ch.group, (counts.get(ch.group) || 0) + 1);
    if (!cc.has(ch.group)) cc.set(ch.group, ch.cc);
  }
  return groups.filter((g) => counts.get(g.name))
    .map((g) => ({ ...g, count: counts.get(g.name), rank: pick.indexOf(cc.get(g.name)) * 100 + groupRank(g.name) }))
    .sort((a, b) => a.rank - b.rank || a.name.localeCompare(b.name));
}

// Channels per country (or bucket), for the country picker. Ignores the current choice.
export function countryCounts() {
  const geo = S.settings.hideGeo;
  const m = new Map();
  for (const ch of S.live) {
    if (isHidden('live', ch.group) || (geo && ch.tags && ch.tags.includes('Geo-blocked'))) continue;
    m.set(ch.cc, (m.get(ch.cc) || 0) + 1);
  }
  return [...m].map(([cc, n]) => ({ cc, n })).sort((a, b) => (BUCKETS.includes(a.cc) - BUCKETS.includes(b.cc)) || b.n - a.n);
}
// ---------- channel quality ----------
// Providers list the same channel several times: "BBC 1 HD", "BBC 1 FHD", "BBC 1 SD", "BBC 1 [BK]".
const BACKUP = /\[\s*BK\d*\s*\]|\(\s*BACKUP\s*\)|\bBACKUP\b/i;
const QTOKENS = /\b(SD|HD|FHD|UHD|4K|8K|HEVC|H\.?265|\d{3,4}P|50 ?FPS|60 ?FPS|RAW)\b|\[\s*BK\d*\s*\]|\(\s*BACKUP\s*\)|\bBACKUP\b/gi;
export const QUALITIES = [['all', 'All versions'], ['SD', 'SD'], ['HD', 'HD'], ['FHD', 'Full HD'], ['4K', '4K'], ['HEVC', 'HEVC']];
function qualityOf(ch) {
  const n = (ch.name + ' ' + (ch.q || '')).toUpperCase();
  if (/\b(4K|UHD|8K|2160P)\b/.test(n)) return '4K';
  if (/\b(HEVC|H\.?265)\b/.test(n)) return 'HEVC';
  if (/\b(FHD|1080P)\b/.test(n)) return 'FHD';
  if (/\b(HD|720P)\b/.test(n)) return 'HD';
  if (/\b(SD|576P|480P|360P)\b/.test(n)) return 'SD';
  return '';
}
function baseName(name) {
  return name.replace(QTOKENS, ' ').toUpperCase().replace(/[^\p{L}\p{N}+]+/gu, '');
}
// When you pick a quality, each channel appears once: in that quality where the provider has
// it, otherwise the nearest one. Backups only appear when they're the only version.
const PREFER = {
  SD: ['SD', '', 'HD', 'FHD', 'HEVC', '4K'],
  HD: ['HD', '', 'FHD', 'SD', 'HEVC', '4K'],
  FHD: ['FHD', 'HD', '', '4K', 'HEVC', 'SD'],
  '4K': ['4K', 'FHD', 'HEVC', 'HD', '', 'SD'],
  HEVC: ['HEVC', 'FHD', 'HD', '4K', '', 'SD'],
};
function bestVersions(list) {
  const order = PREFER[S.settings.quality];
  if (!order) return list;
  const score = (ch) => order.indexOf(ch.qv || '') + (ch.bk ? 10 : 0);
  const best = new Map();
  for (const ch of list) {
    if (!ch.base) continue;
    const b = best.get(ch.base);
    if (!b || score(ch) < score(b)) best.set(ch.base, ch);
  }
  // Keep the list's order, with the chosen version standing where its channel first appears.
  const out = [], placed = new Set();
  for (const ch of list) {
    if (!ch.base) { out.push(ch); continue; }
    if (S.favs.has(ch.id) && best.get(ch.base) !== ch) { out.push(ch); continue; }
    if (placed.has(ch.base)) continue;
    placed.add(ch.base);
    out.push(best.get(ch.base));
  }
  return out;
}

// The other copies of a channel, best first: a backup of the same quality, then the qualities
// you prefer, with channels that failed here recently last.
export function alternatesOf(ch) {
  const all = (S.byBase && ch && ch.base && S.byBase.get(ch.base)) || [];
  if (all.length < 2) return [];
  const order = PREFER[S.settings.quality] || PREFER[ch.qv] || PREFER.HD;
  let bad = {};
  try { bad = JSON.parse(localStorage.getItem('lumen.unavailable') || '{}'); } catch {}
  const failed = (c) => bad[c.id] && Date.now() - bad[c.id] < 3 * 86400000;
  // An untagged backup ("BBC 1 [BK]") counts as the same quality as the channel it backs up.
  const same = (c) => c.qv === ch.qv || (c.bk && !c.qv);
  const score = (c) => (failed(c) ? 1000 : 0) + (same(c) ? 0 : 10 + order.indexOf(c.qv || '')) + (c.bk ? 1 : 0);
  return all.filter((c) => c.id !== ch.id && !isHidden('live', c.group)).sort((a, b) => score(a) - score(b));
}

// ---------- film and series languages ----------
// Providers tag on-demand categories with a language: "[EN] NETFLIX", "[FR] SERIES VF".
export const LANG_NAMES = {
  EN: 'English', UK: 'English (UK)', US: 'English (US)', AR: 'Arabic', IT: 'Italian', FR: 'French', ES: 'Spanish',
  EXYU: 'Balkan (Ex-Yu)', MULTI: 'Multi-language', TR: 'Turkish', IN: 'Indian', HI: 'Hindi', PT: 'Portuguese',
  'PT-BR': 'Portuguese (Brazil)', BR: 'Brazilian', GR: 'Greek', KU: 'Kurdish', NL: 'Dutch', DE: 'German', GE: 'German',
  SW: 'Swedish', SE: 'Swedish', PL: 'Polish', ALB: 'Albanian', RO: 'Romanian', IR: 'Persian', MY: 'Malay',
  AF: 'Afghan', SC: 'Scandinavian', MT: 'Maltese', PK: 'Pakistani', CH: 'Chinese', JP: 'Japanese', KO: 'Korean',
  KR: 'Korean', TH: 'Thai', ID: 'Indonesian', PH: 'Filipino', HU: 'Hungarian', BG: 'Bulgarian', DK: 'Danish',
  RU: 'Russian', LT: 'Lithuanian', IL: 'Hebrew', CA: 'Québécois', NO: 'Norwegian', FI: 'Finnish',
};
const MULTI_TAG = /^(MULTI|MULTI-?LANG|MULTI-?SUB|VOD|ALL)$/;
export function catTag(name) {
  const m = /^\s*[\[(]([^\])]{1,12})[\])]/.exec(name || '');
  if (!m) return '';
  const t = m[1].trim().toUpperCase();
  return MULTI_TAG.test(t) ? 'MULTI' : t;
}
// Languages for the countries you chose, used until you pick languages yourself.
const COUNTRY_LANGS = {
  GB: ['EN', 'UK'], US: ['EN', 'US'], IE: ['EN'], CA: ['EN', 'CA'], AU: ['EN'], NZ: ['EN'], ZA: ['EN'],
  FR: ['FR'], BE: ['FR', 'NL'], CH: ['DE', 'FR', 'IT'], DE: ['DE', 'GE'], AT: ['DE', 'GE'], ES: ['ES'], IT: ['IT'],
  PT: ['PT'], BR: ['PT', 'BR', 'PT-BR'], NL: ['NL'], TR: ['TR'], ARAB: ['AR'], AE: ['AR'], EXYU: ['EXYU'],
  SE: ['SE', 'SW'], NO: ['NO'], DK: ['DK'], FI: ['FI'], PL: ['PL'], PK: ['PK'], IN: ['IN', 'HI'], GR: ['GR'],
  AL: ['ALB'], RO: ['RO'], IR: ['IR'], RU: ['RU'], HU: ['HU'], BG: ['BG'],
};
// The languages to show, or null to show everything.
let langMemo = { key: null, set: null };
export function vodLangs() {
  const own = S.settings.vodLangs || [];
  const key = own.join() + '|' + S.settings.countries.join();
  if (langMemo.key === key) return langMemo.set;
  let set = null;
  if (own.length) set = new Set(own);
  else if (S.settings.countries.length) {
    const out = new Set(['MULTI']);
    for (const cc of S.settings.countries) for (const l of COUNTRY_LANGS[cc] || []) out.add(l);
    if (out.size > 1) set = out;
  }
  langMemo = { key, set };
  return set;
}
const allowCache = new Map();
let allowKey = '';
export function catAllowed(name) {
  const set = vodLangs();
  if (!set) return true;
  if (langMemo.key !== allowKey) { allowCache.clear(); allowKey = langMemo.key; }
  let ok = allowCache.get(name);
  if (ok === undefined) { const t = catTag(name); ok = !t || set.has(t); allowCache.set(name, ok); }
  return ok;
}
// "[EN] SCI-FI/FANTASY" → "Sci-Fi/Fantasy". The language stays when you show several.
const KEEP = new Set(['HBO', 'UK', 'US', 'USA', '4K', '3D', 'TV', 'BBC', 'ITV', 'DC', 'HD', 'VIP', 'NBA', 'NFL', 'UFC', 'WWE', 'F1', 'MMA', 'AMC', 'FX', 'TVB', 'VF', 'VOSTFR', 'II', 'III']);
export function catLabel(name) {
  const tag = catTag(name);
  let bare = String(name || '').replace(/^\s*[\[(][^\])]{1,12}[\])]\s*/, '').trim() || name || '';
  if (bare === bare.toUpperCase()) bare = bare.toLowerCase().replace(/[\p{L}\p{N}+']+/gu, (w) => (KEEP.has(w.toUpperCase()) ? w.toUpperCase() : w[0].toUpperCase() + w.slice(1)));
  bare = bare.replace(/\s+/g, ' ');
  // Name the language only when it tells two categories on show apart ("Netflix · EN" and
  // "Netflix · Multi"), or when you show several languages.
  const { langs, dup } = shownLangs();
  if (tag === 'MULTI') return dup.has(bare.toUpperCase()) ? bare + ' · Multi' : bare;
  const several = langs.size > 1 || dup.has(bare.toUpperCase());
  return tag && several ? `${bare} · ${tag}` : bare;
}
let shownMemo = { key: null, set: null };
function shownLangs() {
  const key = langMemo.key + '|' + (S.groups.movie || []).length + '|' + (S.groups.series || []).length;
  if (shownMemo.key === key) return shownMemo.set;
  const set = vodLangs();
  const langs = new Set(), seen = new Map();
  for (const type of ['movie', 'series']) for (const g of S.groups[type] || []) {
    const t = catTag(g.name);
    if (t && set && !set.has(t)) continue;
    if (t && t !== 'MULTI') langs.add(t);
    const bare = String(g.name).replace(/^\s*[\[(][^\])]{1,12}[\])]\s*/, '').replace(/\s+/g, ' ').trim().toUpperCase();
    const k = type + '|' + bare;
    seen.set(k, (seen.get(k) || 0) + 1);
  }
  const dup = new Set([...seen].filter(([, n]) => n > 1).map(([k]) => k.split('|')[1]));
  shownMemo = { key, set: { langs, dup } };
  return shownMemo.set;
}

// Languages found in your film and series categories, most categories first.
export function vodLanguages() {
  const m = new Map();
  for (const type of ['movie', 'series']) for (const g of S.groups[type] || []) {
    if (isHidden(type, g.name)) continue;
    const t = catTag(g.name);
    if (t) m.set(t, (m.get(t) || 0) + 1);
  }
  return [...m].map(([tag, n]) => ({ tag, n, name: LANG_NAMES[tag] || tag })).sort((a, b) => b.n - a.n);
}

// With countries chosen, channels follow your country order, then each country's main
// categories before events, then the provider's own order. Otherwise the list is unchanged.
export function countryOrder(list, plId) {
  const pick = S.settings.countries;
  if (!pick.length) return list;
  const pos = new Map(pick.map((c, i) => [c, i]));
  const key = (ch) => (pos.has(ch.cc) ? pos.get(ch.cc) : 99) * 100 + groupRank((plId && ch.sg && ch.sg[plId]) || ch.group || '');
  return list.map((ch, i) => [key(ch), i, ch]).sort((a, b) => a[0] - b[0] || a[1] - b[1]).map((x) => x[2]);
}

export function visible(type, list) {
  const geo = type === 'live' && S.settings.hideGeo;
  const pick = type === 'live' && S.settings.countries.length ? new Set(S.settings.countries) : null;
  const out = list.filter((i) => !i.divider && !isHidden(type, i.group) && !(geo && i.tags && i.tags.includes('Geo-blocked')) && !(pick && !pick.has(i.cc)));
  return type === 'live' ? bestVersions(out) : vodLangs() ? out.filter((i) => catAllowed(i.group)) : out;
}

export function getAccount(plId) {
  const pl = S.playlists.find((p) => p.id === plId);
  return pl && pl.kind === 'xtream' ? pl.acc : null;
}

async function fetchPlaylist(pl, onStep) {
  if (pl.kind === 'xtream') {
    const acc = { ...pl.acc, liveFormat: S.settings.xcLiveFormat };
    try {
      const r = await xtreamLoad(acc, pl.id, onStep);
      pl.epg = r.epg; pl.info = r.info;
      return { items: r.items, shows: r.shows, cats: r.cats };
    } catch (e) {
      // A get.php link we upgraded to Xtream: if the API is switched off, use the M3U after all.
      if (!pl.url) throw e;
      pl.kind = 'm3u-url';
      delete pl.acc;
      onStep('Using the M3U link instead');
    }
  }
  let text;
  if (pl.kind === 'builtin') {
    onStep('Downloading ' + pl.name);
    // The hosted preview can't reach GitHub, so it ships copies of the lists beside the page.
    text = await net.text(window.LUMEN_PREVIEW ? `lists/${pl.builtin}.txt` : pl.url);
    const { header, items } = parseM3U(text, pl.id, { forceType: 'live' });
    pl.epg = header.epg;
    return { items, shows: [] };
  }
  if (pl.kind === 'm3u-url' || pl.kind === 'demo') {
    onStep('Downloading playlist');
    text = await net.text(pl.url, {
      onProgress: (got, total) => onStep(`Downloading playlist · ${(got / 1048576).toFixed(1)} MB${total ? ` of ${(total / 1048576).toFixed(1)} MB` : ''}`),
    });
  } else {
    text = pl._text;
  }
  onStep('Reading channels');
  if (!/#EXTINF|#EXTM3U/i.test(text)) throw new Error("This file doesn't look like an M3U playlist.");
  const { header, items } = parseM3U(text, pl.id);
  pl.epg = header.epg;
  return { items, shows: [] };
}

export function xtreamFromLink(url) {
  try {
    const u = new URL(url);
    const user = u.searchParams.get('username'), pass = u.searchParams.get('password');
    if (!/\/get\.php$/i.test(u.pathname) || !user || pass == null) return null;
    return { server: u.origin + u.pathname.replace(/\/get\.php$/i, ''), user, pass };
  } catch { return null; }
}

export async function addPlaylist(def, onStep = () => {}) {
  const pl = { id: hash(Date.now() + Math.random() + ''), name: def.name, kind: def.kind, url: def.url, acc: def.acc, updated: Date.now() };
  if (def.main || !mainPlaylist()) pl.main = true;
  // Provider links like http://host/get.php?username=…&password=… are Xtream accounts. Their API is
  // much faster than the full M3U download and adds posters and series details.
  const xc = pl.kind === 'm3u-url' && xtreamFromLink(pl.url);
  if (xc) { pl.kind = 'xtream'; pl.acc = xc; onStep('Found Xtream login details in the link'); }
  if (def.file) pl._text = await fileText(def.file);
  if (def.text) pl._text = def.text;
  const data = await fetchPlaylist(pl, onStep);
  delete pl._text;
  pl.counts = countOf(data);
  await db.set('pl:' + pl.id, data);
  if (pl.main) for (const p of S.playlists) p.main = false;
  S.playlists.push(pl);
  savePlaylists();
  ls.set('onboarded', true);
  await loadLibrary();
  loadEpg(true).catch(() => {});
  return pl;
}

function countOf(data) {
  const c = { live: 0, movie: 0, series: 0 };
  for (const i of data.items) c[i.type]++;
  c.series = data.shows.length || new Set(data.items.filter((i) => i.type === 'series').map((i) => i.ep.show)).size;
  if (data.cats) { c.movieCats = data.cats.movie.length; c.seriesCats = data.cats.series.length; }
  return c;
}

// "28,611 channels · 180 movie categories · 116 series categories"
export function describeCounts(c) {
  const n = (k, one, many) => `${(k || 0).toLocaleString()} ${k === 1 ? one : many}`;
  return [
    n(c.live, 'channel', 'channels'),
    c.movieCats != null && !c.movie ? n(c.movieCats, 'movie category', 'movie categories') : n(c.movie, 'movie', 'movies'),
    c.seriesCats != null && !c.series ? n(c.seriesCats, 'series category', 'series categories') : n(c.series, 'series', 'series'),
  ].join(' · ');
}

// ---------- on-demand categories (large Xtream providers) ----------

export function hasLazy(type) { return S.lazyCats.some((c) => c.type === type); }
export function isLazyGroup(type, name) { return S.lazyCats.some((c) => c.type === type && c.name === name); }

// Fetch every on-demand category with this name (once per session) and return its titles.
export async function loadLazyGroup(type, name) {
  const cats = S.lazyCats.filter((c) => c.type === type && c.name === name);
  const out = [];
  for (const c of cats) {
    const key = `${c.pl}|${type}|${c.id}`;
    let list = S.lazyLoaded.get(key);
    if (!list) {
      const acc = getAccount(c.pl);
      if (!acc) continue;
      list = await xtreamCategory(acc, c.pl, type, c);
      S.lazyLoaded.set(key, list);
      for (const it of list) { S.meta.set(it.id, it); if (type === 'series') S.showById.set(it.id, it); }
    }
    out.push(...list);
  }
  return out;
}

// ---------- searching big providers ----------
// Providers that send films and series one category at a time can't be searched from memory.
// The first search downloads every category in your languages, keeps a slim copy of each
// title (no plots or cast, which are most of the size) and saves it on the device for a day.
let catalog = { key: '', items: [], done: false, job: null };
const CATALOG_TTL = 24 * 3600000;
function catalogCats() {
  return S.lazyCats.filter((c) => !isHidden(c.type, c.name) && catAllowed(c.name) && S.playlists.some((p) => p.id === c.pl && p.enabled !== false));
}
function catalogKey(cats) { return cats.map((c) => c.pl + ':' + c.type + ':' + c.id).join(',').length + '|' + cats.length + '|' + (vodLangs() ? [...vodLangs()].join() : '*'); }
const slimTitle = (it, type) => ({
  id: it.id, pl: it.pl, type: type === 'movie' ? 'movie' : 'series', name: it.name, logo: it.logo, year: it.year,
  rating: it.rating, group: it.group, added: it.added, url: it.url, xc: it.xc, lazy: true,
});
export function catalogTitles(type) { return catalog.items.filter((x) => (type === 'movie' ? x.type === 'movie' : x.type !== 'movie')); }
export function catalogStatus() { return { done: catalog.done, count: catalog.items.length, busy: !!catalog.job }; }
// onProgress(doneCategories, totalCategories) fires as titles arrive.
export function ensureCatalog(onProgress) {
  const cats = catalogCats();
  if (!cats.length) { catalog = { key: '', items: [], done: true, job: null }; return Promise.resolve(); }
  const key = catalogKey(cats);
  if (catalog.key === key && (catalog.done || catalog.job)) {
    if (catalog.job && onProgress) catalog.listeners.add(onProgress);
    return catalog.job || Promise.resolve();
  }
  const listeners = new Set(onProgress ? [onProgress] : []);
  catalog = { key, items: [], done: false, job: null, listeners };
  const mine = catalog;
  mine.job = (async () => {
    const saved = await db.get('catalog').catch(() => null);
    if (saved && saved.key === key && Date.now() - saved.at < CATALOG_TTL) {
      mine.items = saved.items; mine.done = true; mine.job = null;
      for (const f of mine.listeners) f(cats.length, cats.length);
      return;
    }
    let next = 0, done = 0;
    const worker = async () => {
      while (next < cats.length && catalog === mine) {
        const c = cats[next++];
        const acc = getAccount(c.pl);
        try {
          // Reuse a category already opened this session.
          const k = `${c.pl}|${c.type}|${c.id}`;
          const list = S.lazyLoaded.get(k) || (acc ? await xtreamCategory(acc, c.pl, c.type, c) : []);
          for (const it of list) mine.items.push(slimTitle(it, c.type));
        } catch {}
        done++;
        for (const f of mine.listeners) f(done, cats.length);
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    if (catalog !== mine) return;
    mine.done = true; mine.job = null;
    db.set('catalog', { key, at: Date.now(), items: mine.items }).catch(() => {});
  })();
  return mine.job;
}

export function loadedLazy(type) {
  const out = [];
  for (const [key, list] of S.lazyLoaded) if (key.includes(`|${type}|`)) out.push(...list);
  return out;
}

// Small saved copies of on-demand titles you favourite or watch, so they survive a restart.
function snap(it) {
  if (!it || !it.lazy) return;
  const { id, pl, type, name, url, logo, group, rating, year, added, xc, ep, showId, plot } = it;
  S.snaps.set(id, { id, pl, type, name, url, logo, group, rating, year, added, xc, ep, showId, plot: plot ? String(plot).slice(0, 400) : undefined, lazy: true });
  if (S.snaps.size > 400) S.snaps.delete(S.snaps.keys().next().value);
  ls.set('snaps', Object.fromEntries(S.snaps));
}
export function snapItems(type) {
  return [...S.snaps.values()].filter((x) => (type === 'series' ? !x.type && x.xc && x.xc.series : x.type === type));
}

export async function refreshPlaylist(id, onStep = () => {}) {
  const pl = S.playlists.find((p) => p.id === id);
  if (!pl) return;
  if (pl.kind === 'm3u-file') throw new Error('A playlist added from a file can only be refreshed by adding the file again.');
  const data = await fetchPlaylist(pl, onStep);
  pl.counts = countOf(data);
  pl.updated = Date.now();
  await db.set('pl:' + pl.id, data);
  savePlaylists();
  await loadLibrary();
}

export async function removePlaylist(id) {
  const pl = S.playlists.find((p) => p.id === id);
  if (pl && pl.builtin) return setSource(id, { enabled: false });
  S.playlists = S.playlists.filter((p) => p.id !== id);
  if (pl && pl.main) { const next = S.playlists.find((p) => !p.builtin); if (next) next.main = true; }
  savePlaylists();
  await db.del('pl:' + id);
  await loadLibrary();
}

export function renamePlaylist(id, name) {
  const pl = S.playlists.find((p) => p.id === id);
  if (pl) { pl.name = name; savePlaylists(); bus.emit('library'); }
}

// ---------- main playlist & built-in sources ----------

export function mainPlaylist() {
  const own = S.playlists.filter((p) => !p.builtin);
  return own.find((p) => p.main) || own[0] || null;
}

export function setMain(id) {
  for (const p of S.playlists) p.main = p.id === id;
  savePlaylists();
  loadLibrary();
}

export function builtinSources() {
  return orderedPlaylists().filter((p) => p.builtin);
}

// Make sure every catalogue entry exists as a (possibly not yet downloaded) playlist.
export function ensureBuiltins() {
  let changed = false;
  for (const p of PROVIDERS) {
    const id = 'b-' + p.key;
    const ex = S.playlists.find((x) => x.id === id);
    if (ex) { if (ex.url !== p.url) { ex.url = p.url; changed = true; } continue; }
    S.playlists.push({ id, name: p.name, kind: 'builtin', builtin: p.key, url: p.url, enabled: true, hideHome: false, updated: 0 });
    changed = true;
  }
  if (changed) savePlaylists();
}

// Download built-in sources that are new or older than a day. One library rebuild at the end.
export async function syncBuiltins({ force = false, only = null } = {}) {
  const due = builtinSources().filter((p) => p.enabled !== false && (!only || p.id === only) && (force || !p.updated || Date.now() - p.updated > 24 * 3600000));
  if (!due.length) return 0;
  for (const p of due) S.syncing.add(p.id);
  bus.emit('sources');
  let done = 0;
  const queue = due.slice();
  const worker = async () => {
    for (let pl = queue.shift(); pl; pl = queue.shift()) {
      try {
        const data = await fetchPlaylist(pl, () => {});
        await db.set('pl:' + pl.id, data);
        pl.counts = countOf(data);
        pl.updated = Date.now();
        delete pl.error;
        done++;
      } catch (e) {
        pl.error = e.message || String(e);
      }
      S.syncing.delete(pl.id);
      savePlaylists();
      bus.emit('sources');
    }
  };
  await Promise.all([worker(), worker(), worker()]);
  if (done) { S.bgRefresh = true; try { await loadLibrary(); } finally { S.bgRefresh = false; } }
  return done;
}

export async function setSource(id, patchObj) {
  const pl = S.playlists.find((p) => p.id === id);
  if (!pl) return;
  const wasOn = pl.enabled !== false;
  Object.assign(pl, patchObj);
  savePlaylists();
  const isOn = pl.enabled !== false;
  if (wasOn !== isOn) {
    if (isOn && pl.builtin && !(await db.get('pl:' + pl.id))) { await syncBuiltins({ force: true, only: pl.id }); return; }
    await loadLibrary();
  } else bus.emit('sources');
}

// Try a few streams from a source to see whether they answer from this network.
export async function probeSource(id, n = 4) {
  const list = sourceItems(id);
  if (!list.length) return null;
  const pick = [];
  for (let i = 0; i < n && i < list.length; i++) pick.push(list[Math.floor((i + 0.5) * list.length / n)]);
  let ok = 0, unknown = 0;
  await Promise.all(pick.map(async (ch) => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    try {
      const url = net.relay && net.mode !== 'never' ? net.wrap(ch.url, ch.ua, ch.ref) : ch.url;
      const r = await fetch(url, { signal: ctrl.signal, headers: { Range: 'bytes=0-2047' } });
      if (r.ok || r.status === 206) ok++;
    } catch { if (!net.relay) unknown++; }
    clearTimeout(t);
  }));
  const pl = S.playlists.find((p) => p.id === id);
  const res = { ok, n: pick.length, unknown, at: Date.now() };
  if (pl) { pl.probe = res; savePlaylists(); bus.emit('sources'); }
  return res;
}

// ---------- favourites, history, reminders ----------

export function isFav(id) { return S.favs.has(id); }
export function toggleFav(id) {
  snap(S.meta.get(id) || S.showById.get(id));
  if (S.favs.has(id)) S.favs.delete(id); else S.favs.add(id);
  ls.set('favs', [...S.favs]);
  bus.emit('favs', id);
  return S.favs.has(id);
}

// ---------- My channels ----------
// Your own channel list in your own order; its numbers are the positions (1, 2, 3…).
export function myChannels() {
  return (S.settings.myList || []).map((id) => S.byId.get(id)).filter((c) => c && c.type === 'live');
}
export function inMyList(id) { return (S.settings.myList || []).includes(id); }
export function toggleMyList(id) {
  const list = (S.settings.myList || []).slice();
  const i = list.indexOf(id);
  if (i >= 0) list.splice(i, 1); else list.push(id);
  setSetting('myList', list);
  return i < 0;
}
// Move a channel to a position in My channels (0-based), counting only channels still in the library.
export function moveInMyList(id, to) {
  const live = myChannels().map((c) => c.id);
  const from = live.indexOf(id);
  if (from < 0) return -1;
  to = Math.max(0, Math.min(live.length - 1, to));
  live.splice(from, 1);
  live.splice(to, 0, id);
  // Keep any saved channels that are missing right now (a provider hiccup) at the end.
  const missing = (S.settings.myList || []).filter((x) => !live.includes(x));
  setSetting('myList', [...live, ...missing]);
  return to;
}

// Favourite categories sit at the top of the Live TV sidebar.
export function isFavGroup(name) { return (S.settings.favGroups || []).includes(name); }
export function toggleFavGroup(name) {
  const set = new Set(S.settings.favGroups || []);
  if (set.has(name)) set.delete(name); else set.add(name);
  setSetting('favGroups', [...set]);
  return set.has(name);
}

export function recordPlay(item, pos = 0, dur = 0) {
  snap(item);
  if (item.showId) snap(lookup(item.showId));
  const h = S.history.filter((x) => x.id !== item.id);
  const prev = S.history.find((x) => x.id === item.id);
  h.unshift({ id: item.id, type: item.type, pos: pos || (prev && prev.pos) || 0, dur: dur || (prev && prev.dur) || 0, at: Date.now(), showId: item.showId });
  S.history = h.slice(0, 200);
  ls.set('history', S.history);
  bus.emit('history');
}

export function savePosition(item, pos, dur) {
  const e = S.history.find((x) => x.id === item.id);
  if (!e) return recordPlay(item, pos, dur);
  e.pos = pos; e.dur = dur; e.at = Date.now();
  ls.set('history', S.history);
}

export function getPosition(id) {
  const e = S.history.find((x) => x.id === id);
  if (!e || !e.dur) return 0;
  if (e.pos / e.dur > 0.95) return 0;
  return e.pos > 15 ? e.pos : 0;
}

export function progressOf(id) {
  const e = S.history.find((x) => x.id === id);
  return e && e.dur ? Math.min(1, e.pos / e.dur) : 0;
}

export function continueWatching() {
  const out = [];
  const seenShow = new Set();
  for (const e of S.history) {
    if (e.type === 'live' || !e.dur) continue;
    const p = e.pos / e.dur;
    if (p < 0.02 || p > 0.95) continue;
    const it = S.byId.get(e.id) || S.meta.get(e.id) || S.snaps.get(e.id);
    if (!it) continue;
    if (e.showId) { if (seenShow.has(e.showId)) continue; seenShow.add(e.showId); }
    out.push(it);
    if (out.length >= 20) break;
  }
  return out;
}

export function recentChannels(limit = 20) {
  return S.history.filter((e) => e.type === 'live').map((e) => S.byId.get(e.id)).filter(Boolean).slice(0, limit);
}

// Take a title off Continue watching (a whole show for an episode) or a channel off Recently watched.
export function forget(item) {
  if (item.type === 'live') S.history = S.history.filter((e) => e.id !== item.id);
  else S.history = S.history.filter((e) => e.type === 'live' || !(e.id === item.id || (item.showId && e.showId === item.showId)));
  ls.set('history', S.history);
  bus.emit('history');
}
export function forgetAll(live) {
  S.history = S.history.filter((e) => (e.type === 'live') !== live);
  ls.set('history', S.history);
  bus.emit('history');
}

export function addReminder(ch, prog) {
  const key = ch.id + '|' + prog[0];
  if (S.reminders.some((r) => r.key === key)) return false;
  S.reminders.push({ key, ch: ch.id, start: prog[0], title: prog[2] });
  ls.set('reminders', S.reminders);
  return true;
}
export function hasReminder(ch, prog) { return S.reminders.some((r) => r.key === ch.id + '|' + prog[0]); }
export function removeReminder(key) { S.reminders = S.reminders.filter((r) => r.key !== key); ls.set('reminders', S.reminders); }
export function dueReminders() {
  const now = Date.now();
  const due = S.reminders.filter((r) => r.start - now < 60000);
  if (due.length) { S.reminders = S.reminders.filter((r) => !due.includes(r)); ls.set('reminders', S.reminders); }
  return due.filter((r) => now - r.start < 15 * 60000);
}

// ---------- EPG ----------

function epgSources() {
  const out = new Set(S.settings.epgUrls);
  if (S.settings.epgAuto) for (const pl of S.playlists) if (pl.enabled !== false) for (const u of pl.epg || []) out.add(u);
  // github.com/…/raw/… redirects without CORS headers; ask raw.githubusercontent.com directly.
  return [...out].map((u) => u.replace(/^https:\/\/github\.com\/([^/]+)\/([^/]+)\/raw\//, 'https://raw.githubusercontent.com/$1/$2/'));
}

// Guide channels worth keeping while parsing, so huge guides stay small in memory.
function guideChannels() {
  const pick = S.settings.countries.length ? new Set(S.settings.countries) : null;
  return pick ? S.live.filter((c) => pick.has(c.cc)) : S.live;
}
const guideSig = () => S.settings.countries.join(',');
// After you change countries, fetch the guide again for the new set, in the background.
export function guideForCountries() { if (epgSources().length) loadEpg(true).catch(() => {}); }
function epgWanted() {
  const ids = [], names = [];
  for (const ch of guideChannels()) { if (ch.tvgId) ids.push(ch.tvgId.toLowerCase()); names.push(normName(ch.tvgName || ch.name)); }
  return { ids, names };
}

function runWorker(msg, onProgress) {
  return new Promise((resolve, reject) => {
    const w = new Worker('js/epg-worker.js');
    w.onmessage = (e) => {
      if (e.data.progress != null) { onProgress && onProgress(e.data.progress); return; }
      w.terminate();
      if (e.data.error) reject(new Error(e.data.error)); else resolve(e.data);
    };
    w.onerror = (e) => { w.terminate(); reject(new Error(e.message || 'Guide parser crashed')); };
    w.postMessage(msg);
  });
}

export async function loadEpg(force = false, onProgress) {
  if (S.epg.loading) return;
  const cached = await db.get('epg');
  // A guide saved for other countries doesn't count as fresh.
  const fresh = cached && Date.now() - cached.updated < 12 * 3600000 && (cached.sig || '') === guideSig();
  if (cached && (!force || !epgSources().length)) {
    applyEpg(cached);
    if (fresh || !epgSources().length) return;
  }
  const sources = epgSources();
  if (!sources.length) return;
  S.epg.loading = true;
  bus.emit('epg');
  const anyCatchup = S.live.some((c) => c.catchup);
  // With tens of thousands of channels a full guide won't fit in a TV's memory: keep the next day
  // (and a little catch-up), drop long descriptions, and cap the total.
  // Choosing countries shrinks this, which brings back descriptions and a longer guide.
  const big = guideChannels().length > 8000;
  const from = Date.now() - (anyCatchup ? (big ? 86400000 : 8 * 86400000) : (big ? 2 * 3600000 : 6 * 3600000));
  const to = Date.now() + (big ? 86400000 : 3 * 86400000);
  const lite = big, maxProgs = big ? 400000 : 2000000;
  const want = epgWanted();
  const merged = { channels: {}, progs: {}, updated: Date.now() };
  const errors = [];
  for (const src of sources) {
    const abs = new URL(src, location.href).href;
    const tryUrls = net.relayFirst(abs) ? [net.wrap(abs)] : [abs, ...(net.relay && net.mode !== 'never' ? [net.wrap(abs)] : [])];
    let ok = false;
    for (const u of tryUrls) {
      try {
        const r = await runWorker({ url: new URL(u, location.href).href, from, to, shift: S.settings.epgShift * 60, want, lite, maxProgs }, onProgress);
        Object.assign(merged.channels, r.channels);
        for (const [k, v] of Object.entries(r.progs)) merged.progs[k] = merged.progs[k] ? merged.progs[k].concat(v) : v;
        ok = true; break;
      } catch (e) { errors.push(e.message); }
    }
    if (!ok) console.warn('EPG source failed', src, errors);
  }
  S.epg.loading = false;
  if (!Object.keys(merged.progs).length) {
    bus.emit('epg');
    if (errors.length) throw new Error(errors[errors.length - 1]);
    return;
  }
  // Keep only guide channels we can match, so the cache stays small.
  const keep = matchKeys(merged.channels);
  const slim = { channels: {}, progs: {}, updated: merged.updated, sig: guideSig() };
  for (const k of keep) { if (merged.progs[k]) { slim.progs[k] = merged.progs[k]; slim.channels[k] = merged.channels[k] || { names: [] }; } }
  await db.set('epg', slim);
  applyEpg(slim);
}

export async function loadEpgFile(file) {
  const text = await fileText(file);
  const from = Date.now() - 8 * 86400000, to = Date.now() + 4 * 86400000;
  const r = await runWorker({ text, from, to, shift: S.settings.epgShift * 60 });
  const slim = { channels: r.channels, progs: r.progs, updated: Date.now() };
  await db.set('epg', slim);
  applyEpg(slim);
  return r.count;
}

let epgRaw = null;
function applyEpg(data) {
  epgRaw = data;
  S.epg.updated = data.updated;
  matchEpg();
}

function matchKeys(channels) {
  const ids = new Set(), names = new Set();
  for (const ch of S.live) { if (ch.tvgId) ids.add(ch.tvgId.toLowerCase()); names.add(normName(ch.tvgName || ch.name)); }
  const out = [];
  for (const [k, c] of Object.entries(channels)) {
    if (ids.has(k.toLowerCase()) || (c.names || []).some((n) => names.has(normName(n)))) out.push(k);
  }
  // Programmes may reference channels missing from <channel> tags.
  return out.length ? out : Object.keys(channels);
}

function matchEpg() {
  S.epg.map = new Map();
  if (!epgRaw) { S.epg.count = 0; bus.emit('epg'); return; }
  const byId = new Map(), byName = new Map();
  for (const k of Object.keys(epgRaw.progs)) byId.set(k.toLowerCase(), k);
  for (const [k, c] of Object.entries(epgRaw.channels)) for (const n of c.names || []) byName.set(normName(n), k);
  let matched = 0;
  for (const ch of S.live) {
    const key = (ch.tvgId && byId.get(ch.tvgId.toLowerCase())) || byName.get(normName(ch.tvgName || ch.name)) || byId.get(normName(ch.name));
    if (key && epgRaw.progs[key]) {
      let progs = epgRaw.progs[key];
      if (ch.shift) progs = progs.map((p) => [p[0] + ch.shift * 3600000, p[1] + ch.shift * 3600000, ...p.slice(2)]);
      S.epg.map.set(ch.id, progs);
      matched++;
    }
  }
  for (const [id, progs] of shortGuide) if (!S.epg.map.has(id)) S.epg.map.set(id, progs);
  S.epg.count = matched;
  bus.emit('epg');
}

// ---------- per-channel guide from Xtream providers ----------
// Fills in now/next for channels the XMLTV guide doesn't cover, a few at a time, newest
// request first (the rows on screen and the channel you're on).
const shortGuide = new Map(), shortTried = new Map();
let shortQueue = [], shortBusy = 0, shortEmit = 0;
export function ensureGuide(ch) {
  if (!ch || !ch.xc || !ch.xc.sid || nowNext(ch).now) return;
  const t = shortTried.get(ch.id);
  if (t && Date.now() - t < 20 * 60000) return;
  shortTried.set(ch.id, Date.now());
  shortQueue.unshift(ch);
  if (shortQueue.length > 40) shortQueue.length = 40;
  pumpGuide();
}
function pumpGuide() {
  while (shortBusy < 3 && shortQueue.length) {
    const ch = shortQueue.shift();
    const acc = getAccount(ch.pl);
    if (!acc) continue;
    shortBusy++;
    import('./xtream.js').then((x) => x.xtreamShortEpg(acc, ch.xc.sid)).then((progs) => {
      if (!progs.length) return;
      // Backup and other-quality versions usually share the guide id, so they get it too.
      const same = ch.tvgId ? S.live.filter((c) => c.tvgId === ch.tvgId) : [ch];
      for (const c of same) {
        const old = S.epg.map.get(c.id) || [];
        const merged = [...old.filter((p) => !progs.some((q) => q[0] === p[0])), ...progs].sort((a, b) => a[0] - b[0]);
        shortGuide.set(c.id, merged);
        S.epg.map.set(c.id, merged);
      }
      clearTimeout(shortEmit);
      shortEmit = setTimeout(() => bus.emit('epg'), 250);
    }).catch(() => {}).finally(() => { shortBusy--; pumpGuide(); });
  }
}

export function progsFor(ch) { return S.epg.map.get(ch.id) || []; }

export function nowNext(ch, t = Date.now()) {
  const list = S.epg.map.get(ch.id);
  if (!list || !list.length) return { now: null, next: null, p: 0 };
  let lo = 0, hi = list.length - 1, idx = -1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (list[mid][0] <= t) { idx = mid; lo = mid + 1; } else hi = mid - 1;
  }
  const now = idx >= 0 && list[idx][1] > t ? list[idx] : null;
  const next = list[idx + 1] || null;
  const p = now ? (t - now[0]) / (now[1] - now[0]) : 0;
  return { now, next, p, idx };
}

export function upcoming(ch, n = 6, t = Date.now()) {
  const list = S.epg.map.get(ch.id) || [];
  return list.filter((p) => p[1] > t).slice(0, n);
}

export function searchProgrammes(q, limit = 40) {
  const out = [];
  const t = Date.now();
  for (const ch of S.live) {
    if (isHidden('live', ch.group)) continue;
    for (const p of S.epg.map.get(ch.id) || []) {
      if (p[1] < t - 3600000 && !ch.catchup) continue;
      if (p[2].toLowerCase().includes(q)) { out.push({ ch, p }); if (out.length >= limit) return out; }
    }
  }
  return out;
}

// ---------- catch-up ----------

export function canCatchup(ch, prog) {
  if (!ch.catchup || !prog) return false;
  const days = ch.catchupDays || 3;
  return prog[1] < Date.now() + 60000 && prog[0] > Date.now() - days * 86400000 && prog[0] < Date.now();
}

function fillTemplate(tpl, start, end) {
  const s = Math.floor(start / 1000), e = Math.floor(end / 1000), now = Math.floor(Date.now() / 1000);
  const p = (n) => String(n).padStart(2, '0');
  const fmt = (t, f, utc) => {
    const d = new Date(t * 1000);
    const g = utc
      ? { Y: d.getUTCFullYear(), m: p(d.getUTCMonth() + 1), d: p(d.getUTCDate()), H: p(d.getUTCHours()), M: p(d.getUTCMinutes()), S: p(d.getUTCSeconds()) }
      : { Y: d.getFullYear(), m: p(d.getMonth() + 1), d: p(d.getDate()), H: p(d.getHours()), M: p(d.getMinutes()), S: p(d.getSeconds()) };
    return f.replace(/[YmdHMS]/g, (c) => g[c]);
  };
  return tpl
    .replace(/\{(utc|start|utcend|end|lutc|now|timestamp):([^}]+)\}/g, (_, k, f) => fmt(/end/.test(k) ? e : /lutc|now|timestamp/.test(k) ? now : s, f, true))
    .replace(/\$?\{(utc|start)\}/g, s)
    .replace(/\$?\{(utcend|end)\}/g, e)
    .replace(/\$?\{(lutc|now|timestamp)\}/g, now)
    .replace(/\$?\{duration:(\d+)\}/g, (_, n) => Math.floor((e - s) / Number(n)))
    .replace(/\$?\{duration\}/g, e - s)
    .replace(/\$?\{offset:(\d+)\}/g, (_, n) => Math.floor((now - s) / Number(n)))
    .replace(/\$?\{offset\}/g, now - s)
    .replace(/\{(Y|m|d|H|M|S)\}/g, (_, c) => fmt(s, c, false));
}

export function catchupUrl(ch, prog) {
  const [start, end] = prog;
  const mode = (ch.catchup || '').toLowerCase();
  if (mode === 'xc') {
    const acc = getAccount(ch.pl);
    if (acc) return xtreamCatchupUrl(acc, ch, start, (end - start) / 60000);
  }
  const src = ch.catchupSource || '';
  if (mode === 'append') return ch.url + fillTemplate(src, start, end);
  if ((mode === 'default' || mode === '') && src) {
    return /^https?:\/\//i.test(src) ? fillTemplate(src, start, end) : ch.url + fillTemplate(src, start, end);
  }
  if (mode.startsWith('flussonic') || mode === 'fs') {
    const s = Math.floor(start / 1000), d = Math.floor((end - start) / 1000);
    const m = /^(.*\/)([^/]*?)\.m3u8(\?.*)?$/.exec(ch.url);
    if (m) return `${m[1]}${m[2] === 'mono' ? 'mono' : 'index'}-${s}-${d}.m3u8${m[3] || ''}`;
    const t = /^(.*\/)(?:mpegts|[^/]*\.ts)(\?.*)?$/.exec(ch.url);
    if (t) return `${t[1]}timeshift_abs-${s}.ts${t[2] || ''}`;
  }
  // shift / timeshift and anything unknown: utc + lutc query parameters.
  const s = Math.floor(start / 1000), now = Math.floor(Date.now() / 1000);
  return ch.url + (ch.url.includes('?') ? '&' : '?') + `utc=${s}&lutc=${now}`;
}

// ---------- extra metadata ----------

export async function vodInfo(item) {
  if (S.meta.has('vod:' + item.id)) return S.meta.get('vod:' + item.id);
  const acc = getAccount(item.pl);
  if (!acc || !item.xc) return null;
  try { const r = await xtreamVodInfo(acc, item); S.meta.set('vod:' + item.id, r); return r; } catch { return null; }
}

export async function seriesInfo(show) {
  if (!show.xc) return { episodes: show.episodes || [], plot: show.plot || '' };
  if (S.meta.has('ser:' + show.id)) return S.meta.get('ser:' + show.id);
  const acc = getAccount(show.pl);
  const r = await xtreamSeriesInfo(acc, show);
  S.meta.set('ser:' + show.id, r);
  for (const ep of r.episodes) S.meta.set(ep.id, ep);
  return r;
}

export function lookup(id) { return S.byId.get(id) || S.meta.get(id) || S.showById.get(id) || S.snaps.get(id); }

// ---------- backup ----------

export function exportBackup() {
  return JSON.stringify({
    app: 'lumen', v: 1, at: new Date().toISOString(),
    settings: S.settings, playlists: S.playlists.filter((p) => p.kind !== 'm3u-file'),
    favs: [...S.favs], history: S.history, reminders: S.reminders,
  }, null, 2);
}

export async function importBackup(text, onStep) {
  const j = JSON.parse(text);
  if (j.app !== 'lumen') throw new Error('This is not a Lumen backup file.');
  S.settings = { ...DEFAULTS, ...j.settings }; saveSettings();
  S.favs = new Set(j.favs || []); ls.set('favs', [...S.favs]);
  S.history = j.history || []; ls.set('history', S.history);
  S.reminders = j.reminders || []; ls.set('reminders', S.reminders);
  for (const pl of j.playlists || []) {
    if (pl.builtin) {
      const ex = S.playlists.find((p) => p.id === pl.id);
      if (ex) { ex.enabled = pl.enabled; ex.hideHome = pl.hideHome; savePlaylists(); }
      continue;
    }
    if (S.playlists.some((p) => p.id === pl.id)) continue;
    S.playlists.push(pl); savePlaylists();
    try { await refreshPlaylist(pl.id, onStep); } catch (e) { console.warn(e); }
  }
  await loadLibrary();
}
