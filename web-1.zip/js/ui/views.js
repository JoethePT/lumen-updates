// Main screens: Home, Live TV, Guide, Movies, Series, Search, Favourites.
import { h, add, clear, fmtClock, fmtDay, debounce, logoTile, normName } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import {
  S, bus, nowNext, upcoming, visible, visibleGroups, continueWatching, recentChannels, isFav,
  progsFor, canCatchup, searchProgrammes, toggleFav, lookup, removeReminder,
  mainPlaylist, orderedPlaylists, sourceItems, sourceGroups, isHidden, syncBuiltins,
  hasLazy, isLazyGroup, loadLazyGroup, loadedLazy, snapItems, countryCounts, setSetting, countryOrder, forget, forgetAll, QUALITIES, isFavGroup, toggleFavGroup, ensureGuide, myChannels, moveInMyList, catAllowed, catLabel, vodLangs, isLocked, ensureCatalog, catalogTitles, catalogStatus,
} from '../store.js';
import { openCountryPicker, countrySummary } from './countrypicker.js';
import { openLangPicker, langSummary } from './langpicker.js';
import { castAvailable, chooseAndCast } from '../cast.js';
import { BUCKETS } from '../countries.js';
import { appIcon, providerOf } from '../providers.js';
import { serviceRows, serviceList, serviceTitles, serviceIcon, moveService, setServiceHidden, featuredTitles, featuredDetails } from '../services.js';
import { openAddPlaylist } from './sources.js';
import {
  channelTile, posterCard, wideCard, section, channelRow, topbar, emptyState, setAmbient,
  unlockIfNeeded, sourceCard, menu, confirmBox, withOptions, favOption, myListOption, askNumber,
} from './common.js';
import { VList } from '../vlist.js';
import { openMovie, openShow, openProgramme } from './details.js';
import * as player from './player-ui.js';
import { toast } from '../util.js';

const rem = () => parseFloat(getComputedStyle(document.documentElement).fontSize);

function openItem(it) {
  if (it.type === 'live') return player.open(it, { list: visible('live', S.live) });
  if (it.type === 'movie') return openMovie(it);
  if (it.episodes || (it.xc && it.xc.series)) return openShow(it);
  if (it.type === 'series') {
    const show = lookup(it.showId);
    return player.open(it, { list: show && show.episodes ? show.episodes : [] });
  }
}

function greeting() {
  const hr = new Date().getHours();
  return hr < 5 ? 'Good night' : hr < 12 ? 'Good morning' : hr < 18 ? 'Good afternoon' : 'Good evening';
}

// ---------------- Home ----------------
export function homeView() {
  const el = h('div.view');
  // Once you add your own playlist, Home is built from it alone; free sources stay one click away.
  const main = mainPlaylist();
  const mine = (list) => (main ? list.filter((i) => (i.srcs ? i.srcs.includes(main.id) : i.pl === main.id)) : list);
  const liveVis = visible('live', mine(S.live));
  const moviesVis = visible('movie', mine(S.movies));
  const showsVis = visible('series', S.shows.filter((x) => !main || x.pl === main.id));
  const n = (k, one, many) => `${k.toLocaleString()} ${k === 1 ? one : many}`;
  const lazyCount = (type) => S.lazyCats.filter((c) => c.type === type && (!main || c.pl === main.id)).length;
  const counts = [
    n(liveVis.length, 'channel', 'channels'),
    moviesVis.length || !lazyCount('movie') ? n(moviesVis.length, 'movie', 'movies') : n(lazyCount('movie'), 'movie category', 'movie categories'),
    showsVis.length || !lazyCount('series') ? n(showsVis.length, 'series', 'series') : n(lazyCount('series'), 'series category', 'series categories'),
  ].join(' · ');
  el.append(topbar(greeting(), counts));

  const cont = continueWatching();
  const recent = recentChannels(16).filter((c) => !S.settings.hiddenGroups.includes('live:' + c.group));
  const classicHero = () => {
    let hero;
  if (cont.length) {
    const it = cont[0];
    const e = S.history.find((x) => x.id === it.id);
    const title = it.ep ? it.ep.show : it.name;
    const left = e && e.dur ? Math.max(1, Math.round((e.dur - e.pos) / 60)) : 0;
    hero = h('section.hero.glass',
      h('div.hero-bg', { style: { backgroundImage: it.logo ? `url("${it.logo}")` : 'none' } }),
      h('div', h('div.eyebrow', 'Continue watching'), h('h2', title),
        h('p', it.ep ? `Season ${it.ep.s}, episode ${it.ep.e}${it.ep.title ? ': ' + it.ep.title : ''} · ${left} min left` : `${left} min left · ${it.group}`),
        h('div.row', h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => player.open(it) }, icon('play'), 'Resume'),
          h('button.btn', { onclick: () => it.ep ? openShow(lookup(it.showId) || it) : openMovie(it) }, icon('info'), 'Details'),
          h('button.btn', { onclick: () => { forget(it); toast(`Removed ${title} from Continue watching`); go('home'); } }, icon('close'), 'Remove'))),
      stats(liveVis, moviesVis, showsVis, { movie: lazyCount('movie'), series: lazyCount('series') }));
  } else if (recent.length) {
    const ch = recent[0];
    const { now, p } = nowNext(ch);
    hero = h('section.hero.glass',
      h('div', h('div.eyebrow', 'Pick up where you left off'), h('h2', ch.name),
        h('p', now ? `${now[2]} · until ${fmtClock(now[1])}` : ch.group),
        now ? h('div.bar', { style: { maxWidth: '22rem', marginBottom: '1.6rem' } }, h('i', { style: { width: p * 100 + '%' } })) : null,
        h('div.row', h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => player.open(ch, { list: liveVis }) }, icon('play'), 'Watch'),
          h('button.btn', { onclick: () => go('guide') }, icon('guide'), 'Open guide'))),
      stats(liveVis, moviesVis, showsVis, { movie: lazyCount('movie'), series: lazyCount('series') }));
  } else {
    hero = h('section.hero.glass',
      h('div', h('div.eyebrow', 'Your library'), h('h2', 'Everything you added, in one place.'),
        h('p', 'Browse live channels with the guide, or pick something from your movies and series.'),
        h('div.row', h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => go('live') }, icon('live'), 'Watch live TV'),
          h('button.btn', { onclick: () => go('guide') }, icon('guide'), 'Open guide'))),
      stats(liveVis, moviesVis, showsVis, { movie: lazyCount('movie'), series: lazyCount('series') }));
  }
    return hero;
  };
  // With films or series in the library, Home opens on a featured banner and Continue watching
  // becomes an ordinary row.
  const featured = S.movies.length || S.shows.length || hasLazy('movie') || hasLazy('series');
  const hero = featured ? featuredHero(classicHero) : classicHero();
  el.append(hero);
  const hint = countryHint();
  if (hint) el.append(hint);

  const favCh = liveVis.filter((c) => isFav(c.id));
  const latestMovies = moviesVis.slice().sort((a, b) => (b.added || b.idx) - (a.added || a.idx)).slice(0, 24);
  const latestShows = showsVis.slice().sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 24);
  const favVod = [...moviesVis, ...showsVis, ...snapItems('movie'), ...snapItems('series')].filter((m, i, a) => isFav(m.id) && a.findIndex((x) => x.id === m.id) === i).slice(0, 24);

  const sourcesRow = sourcesSection();
  const rows = {
    continue: () => { const list = featured ? cont : cont.slice(cont.length > 1 ? 0 : 1); return removable(section('Continue watching', list.map((it) => wideCard(it, (x) => player.open(x))), { more: 'Hold OK for options' }), list, false, featured ? null : cont[0]); },
    mylist: () => { const my = myChannels(); return section('My channels', my.map((c, i) => channelTile(c, (x) => player.open(x, { list: my, positions: true }))), { more: my.length ? `${my.length} channel${my.length === 1 ? '' : 's'}` : '' }); },
    favch: () => section('Favourite channels', favCh.slice(0, 30).map((c) => channelTile(c, (x) => player.open(x, { list: favCh })))),
    recent: () => removable(section('Recently watched', recent.map((c) => channelTile(c, (x) => player.open(x, { list: liveVis }))), { more: 'Hold OK for options' }), recent, true, featured || cont.length ? null : recent[0]),
    mine: () => main ? section(main.name, homeChannels(liveVis).map((c) => channelTile(c, (x) => player.open(x, { list: liveVis }))), { more: liveVis.length > 24 ? `${liveVis.length.toLocaleString()} channels` : '' }) : null,
    sources: () => sourcesRow.el,
    services: () => servicesRow(),
    favvod: () => section('Your favourites', favVod.map((m) => posterCard(m, openItem))),
    movies: () => latestMovies.length ? section('Movies', latestMovies.map((m) => posterCard(m, openItem)), { more: moviesVis.length > 24 ? `${moviesVis.length.toLocaleString()} in your library` : '' }) : lazyRow('Movies', 'movie', main),
    series: () => latestShows.length ? section('Series', latestShows.map((m) => posterCard(m, openItem)), { more: showsVis.length > 24 ? `${showsVis.length.toLocaleString()} in your library` : '' }) : lazyRow('Series', 'series', main),
  };
  const order = homeOrder(Object.keys(rows)).filter((k) => !S.settings.homeHidden.includes(k));
  const shown = [];
  for (const key of order) {
    const sec = rows[key]();
    if (!sec) continue;
    sec.dataset.row = key;
    sec.rowOptions = () => rowOptions(key, el);
    giveRowOptions(sec);
    shown.push(sec);
  }
  el.append(...shown);
  return {
    el,
    onShow() {
      const svcCard = focusSvc && el.querySelector(`[data-svc="${focusSvc}"]`);
      focusSvc = null;
      if (svcCard) { focusRow = null; nav.focus(svcCard, { block: 'center' }); return; }
      const sec = focusRow && el.querySelector(`[data-row="${focusRow}"]`);
      focusRow = null;
      const tile = sec && sec.querySelector('.scroller .f');
      if (tile) { nav.focus(tile, { block: 'center' }); return; }
      nav.focusFirst(el);
    },
    destroy: sourcesRow.destroy,
  };
}

// ---------- Home row order ----------
// The order you set in Settings → Home screen (or with Move row up/down), with rows that
// appeared since (a new streaming service, say) slotted in where they'd go by default.
const DEFAULT_ROWS = ['continue', 'mylist', 'favch', 'recent', 'mine', 'services', 'sources', 'favvod', 'movies', 'series'];
const rank = (k) => DEFAULT_ROWS.indexOf(k);
export function homeOrder(keys) {
  const saved = (S.settings.homeOrder || []).filter((k) => keys.includes(k));
  const out = saved.slice();
  for (const k of keys.slice().sort((a, b) => rank(a) - rank(b))) {
    if (out.includes(k)) continue;
    // Place it after the last row that comes before it by default.
    let at = 0;
    out.forEach((x, i) => { if (rank(x) < rank(k)) at = i + 1; });
    out.splice(at, 0, k);
  }
  return out;
}
export function homeRowNames() {
  const main = mainPlaylist();
  const names = { continue: 'Continue watching', mylist: 'My channels', favch: 'Favourite channels', recent: 'Recently watched', mine: main ? main.name : 'Your playlist', services: 'Streaming services', sources: 'Live TV sources', favvod: 'Your favourites', movies: 'Movies', series: 'Series' };
  if (!serviceRows().length) delete names.services;
  return names;
}
export function moveHomeRow(key, delta, among) {
  const all = homeOrder(Object.keys(homeRowNames()));
  const vis = among || all.filter((k) => !S.settings.homeHidden.includes(k));
  const i = vis.indexOf(key), j = i + delta;
  if (i < 0 || j < 0 || j >= vis.length) return false;
  const other = vis[j];
  const a = all.indexOf(key), b = all.indexOf(other);
  [all[a], all[b]] = [all[b], all[a]];
  setSetting('homeOrder', all);
  return true;
}
export function setHomeRowHidden(key, hidden) {
  const set = new Set(S.settings.homeHidden);
  if (hidden) set.add(key); else set.delete(key);
  setSetting('homeHidden', [...set]);
}

let focusRow = null, focusSvc = null;
function rowOptions(key, view) {
  const shown = [...view.querySelectorAll('[data-row]')].map((x) => x.dataset.row);
  const i = shown.indexOf(key);
  const move = (d) => { moveHomeRow(key, d, shown); focusRow = key; go('home'); };
  return [
    i > 0 ? { label: 'Move row up', run: () => move(-1) } : null,
    i < shown.length - 1 ? { label: 'Move row down', run: () => move(1) } : null,
    { label: 'Hide row from Home', run: () => {
      setHomeRowHidden(key, true);
      const sec = view.querySelector(`[data-row="${key}"]`);
      const next = sec && (sec.nextElementSibling || sec.previousElementSibling);
      if (sec) sec.remove();
      toast('Row hidden · bring it back in Settings → Home screen');
      if (next) nav.focusFirst(next);
    } },
  ].filter(Boolean);
}
// Tiles that have no options of their own (source cards, "See all") still offer the row's.
function giveRowOptions(sec) {
  for (const t of sec.querySelectorAll('.scroller .f')) {
    if (!t.lumenOptions) t.lumenOptions = () => menu(t, t.querySelector('.tile-title')?.textContent || '', sec.rowOptions());
  }
}

// One card per streaming service; each opens that service's films and series.
function servicesRow() {
  const list = serviceList();
  if (!list.length) return null;
  const sec = h('section.section', h('div.section-head', h('h2', 'Streaming services'), h('span.more', 'Hold OK to reorder')), h('div.scroller', { 'data-remember': '' }));
  const kinds = (svc) => [...new Set(svc.cats.map((c) => c.type))].map((t) => (t === 'movie' ? 'Films' : 'Series')).join(' & ');
  list.forEach((svc, i) => {
    const card = sourceCard({ icon: serviceIcon(svc), title: svc.name, sub: kinds(svc), onclick: () => go('service', { key: svc.key }) });
    card.dataset.svc = svc.key;
    const move = (d) => { moveService(svc.key, d); focusSvc = svc.key; go('home'); };
    card.lumenOptions = () => menu(card, svc.name, [
      i > 0 ? { label: 'Move left', run: () => move(-1) } : null,
      i < list.length - 1 ? { label: 'Move right', run: () => move(1) } : null,
      { label: `Hide ${svc.name}`, run: () => {
        setServiceHidden(svc.key, true);
        toast(`${svc.name} hidden · bring it back in Settings → Home screen`);
        const next = card.nextElementSibling || card.previousElementSibling;
        card.remove();
        if (next) nav.focus(next); else { const after = sec.nextElementSibling; sec.remove(); if (after) nav.focusFirst(after); }
      } },
      ...sec.rowOptions(),
    ].filter(Boolean));
    sec.lastChild.append(card);
  });
  return sec;
}

// Continue watching and Recently watched: hold OK (or Menu, or right-click) on a tile to
// remove it, or to clear the whole row.
function removable(sec, items, live, heroItem) {
  if (!sec) return sec;
  const row = live ? 'Recently watched' : 'Continue watching';
  const tiles = [...sec.querySelectorAll('.scroller > .tile')];
  tiles.forEach((tile, i) => {
    const it = items[i];
    const name = it.ep ? it.ep.show : it.name;
    withOptions(tile, it, () => [
      ...(live ? [myListOption(it)] : []),
      { label: `Remove from ${row}`, run: () => {
        forget(it);
        toast(`Removed ${name}`);
        // The hero shows the first Continue watching title, so redraw when that one goes.
        if (it === heroItem) { go('home'); return; }
        const next = tile.nextElementSibling || tile.previousElementSibling;
        tile.remove();
        if (next) nav.focus(next); else { const after = sec.nextElementSibling; sec.remove(); nav.focusFirst(after || document.querySelector('.view')); }
      } },
      { label: `Clear ${row}`, run: async () => {
        if (!(await confirmBox(`Clear ${row}?`, live ? 'Your channel history is removed. Favourites stay.' : 'Resume points for every movie and episode are removed.', 'Clear', true))) return;
        forgetAll(live);
        toast(`${row} cleared`);
        go('home');
      } },
    ]);
  });
  return sec;
}

// ---------- featured banner ----------
function featuredHero(fallback, only = null) {
  const bg = h('div.hero-bg.feat-bg');
  const eyebrow = h('div.eyebrow', 'Featured');
  const title = h('h2', 'Finding something to watch…');
  const meta = h('div.feat-meta');
  const plot = h('p');
  const playLabel = h('span', 'Play');
  const play = h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => cur() && (cur().type === 'movie' ? player.open(cur()) : openItem(cur())) }, icon('play'), playLabel);
  const info = h('button.btn', { onclick: () => cur() && openItem(cur()) }, icon('info'), 'More info');
  const prev = h('button.btn.btn-icon', { 'aria-label': 'Previous', onclick: () => step(-1) }, icon('left'));
  const next = h('button.btn.btn-icon', { 'aria-label': 'Next', onclick: () => step(1) }, icon('right'));
  const dots = h('div.feat-dots');
  const hero = h('section.hero.glass.featured.loading', bg, h('div.feat-body', eyebrow, title, meta, plot, h('div.row', play, info, prev, next), dots));
  let items = [], i = 0, token = 0;
  const cur = () => items[i];
  const pretty = (g) => String(g || '').replace(/^\s*[\[(][^\])]+[\])]\s*/, '').toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase());

  async function show(k) {
    i = (k + items.length) % items.length;
    const it = items[i], my = ++token;
    hero.classList.remove('loading');
    eyebrow.textContent = pretty(it.group) || 'Featured';
    title.textContent = it.name;
    playLabel.textContent = it.type === 'movie' ? 'Play' : 'Episodes';
    paintMeta(it);
    dots.replaceChildren(...items.map((_, j) => h('i' + (j === i ? '.on' : ''))));
    bg.classList.add('fade');
    await featuredDetails(it);
    if (my !== token || !hero.isConnected) return;
    paintMeta(it);
    const img = it.backdrop || it.logo;
    bg.classList.toggle('poster-bg', !it.backdrop);
    const swap = () => { if (my !== token) return; bg.style.backgroundImage = img ? `url("${img}")` : 'none'; bg.classList.remove('fade'); };
    if (img) { const pic = new Image(); pic.onload = pic.onerror = swap; pic.src = img; } else swap();
    setAmbient(it.name, it.backdrop || it.logo);
    // Have the next one ready.
    if (items.length > 1) featuredDetails(items[(i + 1) % items.length]);
  }
  function paintMeta(it) {
    const mins = it.dur ? Math.round(it.dur / 60) : 0;
    meta.replaceChildren(...[
      it.year ? h('span', String(it.year)) : null,
      it.rating ? h('span.badge.rating', icon('star'), (it.rating > 10 ? it.rating / 10 : it.rating).toFixed(1)) : null,
      h('span', it.type === 'movie' ? 'Film' : 'Series'),
      mins ? h('span', mins >= 60 ? `${Math.floor(mins / 60)} h ${mins % 60} min` : `${mins} min`) : null,
      it.genre ? h('span', it.genre.split(/,\s*/).slice(0, 2).join(' · ')) : null,
    ].filter(Boolean));
    plot.textContent = it.plot || '';
  }
  function step(d) { if (items.length) show(i + d); }

  featuredTitles(8, only).then((list) => {
    if (!list.length) { const f = fallback(); if (f) hero.replaceWith(f); else hero.remove(); return; }
    items = list;
    show(0);
    // Move on every 9 seconds, but never while you're on the banner.
    const t = setInterval(() => {
      if (!hero.isConnected) { clearInterval(t); return; }
      if (hero.contains(document.activeElement) || document.querySelector('.layer') || document.hidden) return;
      step(1);
    }, 9000);
  }).catch(() => { if (!hero.isConnected) return; const f = fallback(); if (f) hero.replaceWith(f); else hero.remove(); });
  return hero;
}

// ---------- a streaming service's page ----------
export function serviceView(params = {}) {
  const svc = serviceList({ all: true }).find((x) => x.key === params.key);
  const el = h('div.view', { style: { overflow: 'hidden' } });
  if (!svc) { el.append(topbar('Not found', ''), emptyState('movie', 'This service isn’t in your library', 'Your playlist no longer has categories for it.')); return { el }; }
  let kind = 'all', sort = 'added', all = [], list = [];
  const sorts = [['added', 'Recently added'], ['az', 'A–Z'], ['year', 'Newest'], ['rating', 'Top rated']];
  const sortBtn = h('button.btn.btn-sm', { onclick: () => menu(sortBtn, 'Sort by', sorts.map(([k, l]) => ({ label: l, on: sort === k, run: () => { sort = k; sortBtn.lastChild.textContent = l; fill(); } }))) }, icon('list'), h('span', 'Recently added'));
  el.append(topbar(svc.name, 'Loading…'));
  el.querySelector('.topbar h1').prepend(serviceIcon(svc));
  el.querySelector('.topbar h1').classList.add('svc-title');
  const sub = el.querySelector('.topbar .sub');
  const chips = h('div.chips', { 'data-remember': '' });
  el.append(h('div.toolbar', chips, sortBtn));
  const grid = h('div.vod-grid');
  el.append(grid);
  const vl = new VList({
    count: 0, gap: Math.round(rem() * 1.2), overscan: 2,
    cols: (w) => Math.max(2, Math.floor((w + rem() * 1.6) / (rem() * (innerWidth < 720 ? 8 : 11.5) + rem() * 1.6))),
    rowHeight: (w, cols) => {
      const colW = (w - rem() * 2.4 - (cols - 1) * rem() * 1.6) / cols;
      return Math.round(colW * 1.5 + rem() * 3.6);
    },
    render: (i) => posterCard(list[i], openItem, { sub: [list[i].year, list[i].type === 'movie' ? 'Film' : 'Series'].filter(Boolean).join(' · ') }),
  });
  grid.append(vl.el);
  vl.inner.append(h('div.empty-state', h('div.spinner'), h('h3', `Loading ${svc.name}`), h('p', svc.cats.map((c) => c.name).join(' · '))));

  function paintChips() {
    const films = all.filter((x) => x.type === 'movie').length, series = all.length - films;
    const mk = (k, label, n) => h('button.chip' + (kind === k ? '.on' : ''), { onclick: () => { kind = k; paintChips(); fill(); } }, label, h('span.n', n.toLocaleString()));
    chips.replaceChildren(mk('all', 'All', all.length), ...(films && series ? [mk('movie', 'Films', films), mk('series', 'Series', series)] : []));
  }
  function fill() {
    for (const x of vl.inner.querySelectorAll(':scope > :not(.vl-row)')) x.remove();
    list = all.filter((x) => kind === 'all' || (kind === 'movie' ? x.type === 'movie' : x.type !== 'movie'));
    if (sort === 'az') list.sort((a, b) => a.name.localeCompare(b.name));
    else if (sort === 'year') list.sort((a, b) => (b.year || 0) - (a.year || 0));
    else if (sort === 'rating') list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    else list.sort((a, b) => (b.added || 0) - (a.added || 0));
    const films = list.filter((x) => x.type === 'movie').length;
    sub.textContent = [films ? `${films.toLocaleString()} film${films === 1 ? '' : 's'}` : '', list.length - films ? `${(list.length - films).toLocaleString()} series` : ''].filter(Boolean).join(' · ');
    vl.setCount(list.length);
  }
  serviceTitles(svc).then((items) => {
    if (!el.isConnected && !vl.el.isConnected) return;
    all = items;
    paintChips(); fill();
    if (!all.length) vl.inner.append(emptyState('movie', 'Nothing here yet', 'The provider sent no titles for this service.'));
    // Land on the first title once it's there, unless you've already moved somewhere else.
    const a = document.activeElement;
    if (!el.contains(a) || a === sortBtn) requestAnimationFrame(() => { const f = vl.itemEl(0); nav.focus(f || chips.firstChild); });
  }).catch((e) => {
    for (const x of vl.inner.querySelectorAll(':scope > :not(.vl-row)')) x.remove();
    sub.textContent = '';
    vl.inner.append(emptyState('movie', `${svc.name} didn’t load`, e.message || 'The provider didn’t answer. Try again in a moment.'));
  });
  return { el, onShow() { vl.layout(); if (all.length) nav.focus(vl.itemEl(0) || chips.firstChild); }, destroy() { vl.destroy(); } };
}

// How a source reads on its card right now.
export function sourceStatus(pl) {
  const n = S.srcCount.get(pl.id) || 0;
  const org = providerOf(pl);
  const prefix = org && org.org === 'iptv-org' ? 'iptv-org · ' : '';
  if (S.syncing.has(pl.id)) return { sub: prefix + 'Loading channels…', state: 'busy' };
  if (pl.error && !n) return { sub: "Couldn't load · select to retry", state: 'error' };
  if (pl.probe && pl.probe.n && !pl.probe.ok && !pl.probe.unknown) return { sub: `${prefix}${n.toLocaleString()} channels · may not work here`, state: 'error' };
  if (!n && pl.builtin && !pl.updated) return { sub: prefix + 'Not loaded yet', state: 'idle' };
  return { sub: `${prefix}${n.toLocaleString()} channel${n === 1 ? '' : 's'}`, state: 'idle' };
}

// Home suggestion to choose countries when a playlist spans many of them.
function countryHint() {
  if (S.settings.countries.length || !S.settings.countryHint) return null;
  const real = countryCounts().filter((c) => !BUCKETS.includes(c.cc));
  const total = real.reduce((a, c) => a + c.n, 0);
  if (real.length < 5 || total < 1500) return null;
  const el = h('section.country-hint.glass',
    icon('globe'),
    h('div.txt', h('div.t', `${total.toLocaleString()} channels from ${real.length} countries`), h('div.d', 'Choose the countries you watch and Lumen hides the rest.')),
    h('button.btn.btn-accent', { onclick: () => openCountryPicker() }, 'Choose countries'),
    h('button.btn', { onclick: () => { setSetting('countryHint', false); el.remove(); toast('You can choose countries any time in Settings'); } }, 'Not now'));
  return el;
}

// For providers that load by category: fill a Home row from the first category, in the background.
function lazyRow(title, type, main) {
  const cat = S.lazyCats.find((c) => c.type === type && (!main || c.pl === main.id) && !isHidden(type, c.name) && catAllowed(c.name));
  if (!cat) return null;
  const scroller = h('div.scroller', { 'data-remember': '' }, h('div.lazy-note', h('span.spinner'), `Loading ${catLabel(cat.name)}…`));
  const el = h('section.section', h('div.section-head', h('h2', title), h('span.more', catLabel(cat.name))), scroller);
  loadLazyGroup(type, cat.name).then((items) => {
    if (!el.isConnected) return;
    const top = visible(type, items).slice().sort((a, b) => (b.added || 0) - (a.added || 0)).slice(0, 24);
    if (!top.length) { el.remove(); return; }
    clear(scroller).append(...top.map((m) => posterCard(m, openItem)));
  }).catch(() => { if (el.isConnected) el.remove(); });
  return el;
}

// Your playlist's channels for Home: what's on now first, then by channel number.
function homeChannels(list) {
  const on = list.filter((c) => nowNext(c).now);
  const rest = list.filter((c) => !on.includes(c));
  return countryOrder([...on, ...rest]).slice(0, 24);
}

// How free sources appear on Home: every card, one "Free TV" card, or not at all.
// "auto" shows them all until you add a playlist of your own, then folds them away.
export function freeHomeMode() {
  const m = S.settings.freeOnHome || 'auto';
  if (m !== 'auto') return m;
  return mainPlaylist() ? 'collapsed' : 'expanded';
}
let freeOpen = false; // a collapsed row opened for this session only

function freeStack(pls) {
  // One icon per provider, so the stack reads as several services rather than one.
  const seen = new Set();
  const picks = pls.filter((pl) => { const org = (providerOf(pl) || {}).org; if (seen.has(org)) return false; seen.add(org); return true; });
  const icons = picks.slice(0, 3).map((pl) => { const p = providerOf(pl); return appIcon(p ? p.icon : 'iptv-all'); });
  return h('span.icon-stack', icons);
}

// Home "Live TV" row: your main playlist first, then the free sources.
function sourcesSection() {
  const cards = [];
  const main = mainPlaylist();
  if (main) {
    const n = sourceItems(main.id).length;
    cards.push(sourceCard({ icon: 'main', title: main.name, sub: `Your playlist · ${n.toLocaleString()} channel${n === 1 ? '' : 's'}`, onclick: () => go('live', { src: main.id }) }));
  } else {
    cards.push(sourceCard({ icon: 'add', title: 'Add your playlist', sub: 'M3U link, file or Xtream login', onclick: () => openAddPlaylist(() => go('home'), { main: true }) }));
  }
  for (const pl of orderedPlaylists()) {
    if (pl === main || pl.builtin || pl.enabled === false || pl.hideHome) continue;
    const n = sourceItems(pl.id).length;
    cards.push(sourceCard({ icon: 'main', title: pl.name, sub: `${n.toLocaleString()} channel${n === 1 ? '' : 's'}`, onclick: () => go('live', { src: pl.id }) }));
  }

  const free = orderedPlaylists().filter((pl) => pl.builtin && pl.enabled !== false && !pl.hideHome);
  const mode = freeHomeMode();
  const tracked = [];
  const toggle = h('button.btn.btn-sm.row-toggle', { onclick: () => { freeOpen = !freeOpen; rebuild(); } });
  const scroller = h('div.scroller', { 'data-remember': '' });
  const head = h('div.section-head', h('h2', 'Live TV'), free.length && mode !== 'hidden' ? toggle : null);
  const el = h('section.section', head, scroller);

  function freeCard(pl) {
    const prov = providerOf(pl);
    const card = sourceCard({
      icon: prov ? prov.icon : 'main', title: pl.name, ...sourceStatus(pl),
      onclick: () => {
        if (S.syncing.has(pl.id)) { toast(`${pl.name} is still loading`); return; }
        if (pl.builtin && !S.srcCount.get(pl.id)) { toast(`Loading ${pl.name}…`); syncBuiltins({ force: true, only: pl.id }); return; }
        go('live', { src: pl.id });
      },
    });
    tracked.push([pl, card]);
    return card;
  }

  function rebuild() {
    tracked.length = 0;
    const open = mode === 'expanded' || freeOpen;
    const list = [...cards];
    if (free.length && mode !== 'hidden') {
      if (open) {
        list.push(...free.map(freeCard));
        if (mode === 'collapsed') list.push(sourceCard({ icon: 'collapse', title: 'Collapse', sub: 'Fold free TV back into one card', onclick: () => { freeOpen = false; rebuild(); requestAnimationFrame(() => nav.focus(scroller.querySelector('.free-card') || toggle)); } }));
      } else {
        const total = new Set(free.flatMap((pl) => sourceItems(pl.id).map((c) => c.id))).size;
        const c = sourceCard({ icon: freeStack(free), title: 'Free TV', sub: `${free.length} sources · ${total.toLocaleString()} channels`, onclick: () => { freeOpen = true; rebuild(); requestAnimationFrame(() => { const f = scroller.querySelectorAll('.src-tile')[cards.length]; if (f) nav.focus(f); }); } });
        c.classList.add('free-card');
        list.push(c);
      }
    }
    list.push(sourceCard({ icon: 'manage', title: 'Manage sources', sub: 'Turn sources on, off or hide them', onclick: () => go('settings', { section: 'playlists' }) }));
    clear(scroller).append(...list);
    if (mode === 'collapsed') toggle.replaceChildren(icon(freeOpen ? 'chUp' : 'chDown'), freeOpen ? 'Collapse free TV' : 'Show free TV');
    else toggle.hidden = true;
  }
  rebuild();
  const off = bus.on('sources', () => { for (const [pl, card] of tracked) card.update(sourceStatus(pl)); });
  return { el, destroy: off };
}

function stats(l, m, s, lazy = {}) {
  const st = (n, label) => h('div.stat', h('b', n.toLocaleString()), h('span', label));
  return h('div.stats', st(l.length, 'Channels'),
    !m.length && lazy.movie ? st(lazy.movie, 'Movie categories') : st(m.length, 'Movies'),
    !s.length && lazy.series ? st(lazy.series, 'Series categories') : st(s.length, 'Series'));
}

// ---------------- Live TV ----------------
export function liveView(params = {}) {
  const el = h('div.view', { style: { overflow: 'hidden' } });
  let group = params.group || '__all';
  // Live TV opens on your main playlist when you have one; "All sources" shows everything.
  let src = params.src !== undefined ? params.src : (mainPlaylist() ? mainPlaylist().id : null);
  const srcPl = () => S.playlists.find((p) => p.id === src);
  const gOf = (c) => (src ? c.sg[src] || c.group : c.group);
  let sort = 'num';
  let list = [];
  let focusedCh = null;

  const sortBtn = h('button.btn.btn-sm', { onclick: () => { sort = sort === 'num' ? 'az' : 'num'; sortBtn.lastChild.textContent = sort === 'num' ? 'By number' : 'A–Z'; fill(); } }, icon('list'), h('span', 'By number'));
  const countryBtn = h('button.btn.btn-sm', { onclick: () => openCountryPicker() }, icon('globe'), h('span', S.settings.countries.length ? countrySummary() : 'All countries'));
  const qLabel = () => (QUALITIES.find(([k]) => k === S.settings.quality) || QUALITIES[0])[1];
  const qualityBtn = h('button.btn.btn-sm', { onclick: () => menu(qualityBtn, 'Show each channel in', QUALITIES.map(([k, l]) => ({
    label: k === 'all' ? 'All versions' : l, on: S.settings.quality === k,
    run: () => { setSetting('quality', k); qualityBtn.lastChild.textContent = k === 'all' ? 'All versions' : qLabel(); bus.emit('library'); },
  }))) }, icon('quality'), h('span', S.settings.quality === 'all' ? 'All versions' : qLabel()));
  el.append(topbar('Live TV', '', countryBtn, qualityBtn, sortBtn));
  const titleEl = el.querySelector('.topbar h1');
  const sub = el.querySelector('.topbar .sub') || h('div.sub');
  if (!sub.isConnected) el.querySelector('.topbar > div').append(sub);

  const groupsEl = h('div.panel.glass.groups', { 'data-remember': '' });
  const listPanel = h('div.panel.glass', { style: { padding: '.6rem 0' } });
  const screen = h('div.preview-screen', h('div.ph', h('div', h('div', 'Select a channel to preview it here'))));
  const infoEl = h('div.preview-info');
  const actionsEl = h('div.preview-actions');
  const preview = h('div.panel.glass.preview', screen, actionsEl, infoEl);
  el.append(h('div.live-wrap', groupsEl, listPanel, preview));

  const vl = new VList({
    count: 0,
    rowHeight: () => Math.round(rem() * 5),
    render: (i) => {
      const ch = list[i];
      ensureGuide(ch);
      const row = channelRow(ch, {
        playing: player.current() && player.current().id === ch.id,
        group: gOf(ch),
        num: group === '__my' ? i + 1 : null,
        onfocus: () => { focusedCh = ch; showInfo(ch); setAmbient(ch.name); },
        onclick: () => choose(ch),
      });
      if (moving === ch) row.classList.add('moving');
      row.lumenOptions = () => menu(row, ch.name, [
        favOption(ch, () => { vl.refresh(); if (group === '__fav') { paintGroups(); fill(); } }),
        myListOption(ch, () => { paintGroups(); if (group === '__my') { fill(); refocus(i); } }),
        ...(castAvailable() ? [{ label: 'Cast to TV', run: () => chooseAndCast(row, ch, () => { if (player.current() && player.current().id === ch.id) player.close(); return 0; }, list) }] : []),
        ...(group !== '__my' ? [] : [
          { label: 'Move (use ↑ ↓)', run: () => startMove(ch) },
          { label: 'Move to number…', run: async () => {
            const n = await askNumber('Move to number', `${ch.name} is number ${i + 1} of ${list.length}.`, list.length);
            if (!n) return;
            const at = moveInMyList(ch.id, n - 1);
            fill(); refocus(at);
            toast(`${ch.name} is now number ${list.indexOf(ch) + 1}`);
          } },
        ]),
        ...(group !== '__recent' ? [] : [
        { label: 'Remove from Recently watched', run: () => { forget(ch); toast(`Removed ${ch.name}`); paintGroups(); fill(); requestAnimationFrame(() => { const f = vl.itemEl(Math.min(i, list.length - 1)); if (f) nav.focus(f); else nav.focusFirst(groupsEl); }); } },
        { label: 'Clear Recently watched', run: async () => { if (!(await confirmBox('Clear Recently watched?', 'Your channel history is removed. Favourites stay.', 'Clear', true))) return; forgetAll(true); paintGroups(); fill(); nav.focusFirst(groupsEl); } },
      ])]);
      return row;
    },
  });
  vl.el.classList.add('chlist');
  listPanel.append(vl.el);

  // Focus a row by index once the list has redrawn.
  function refocus(i) {
    i = Math.max(0, Math.min(i, list.length - 1));
    vl.scrollToIndex(i);
    requestAnimationFrame(() => { const f = vl.itemEl(i); if (f) nav.focus(f, { scroll: false }); else nav.focusFirst(groupsEl); });
  }

  // Move mode for My channels: ↑ ↓ carry the channel (CH+/CH− ten at a time), OK or Back drops it.
  let moving = null;
  function startMove(ch) {
    moving = ch;
    document.documentElement.classList.add('nav-plain-ok');
    vl.refresh();
    toast('Press ↑ or ↓ to move · OK when done', { ms: 5000 });
    const off = nav.onKey((k) => {
      if (!moving || !el.isConnected) { moving = null; off(); document.documentElement.classList.remove('nav-plain-ok'); return false; }
      const d = { up: -1, down: 1, chup: -10, chdown: 10 }[k];
      if (d) {
        const at = moveInMyList(moving.id, list.indexOf(moving) + d);
        list = myChannels();
        vl.refresh();
        refocus(at);
        return true;
      }
      if (k === 'enter' || k === 'back') {
        const at = list.indexOf(moving);
        moving = null; off();
        document.documentElement.classList.remove('nav-plain-ok');
        vl.refresh(); refocus(at);
        toast('My channels saved');
        return true;
      }
      return false;
    });
  }

  async function choose(ch) {
    if (!(await unlockIfNeeded('live', ch.group))) return;
    const cur = player.current();
    if (cur && cur.id === ch.id && player.mode() !== 'hidden') { if (player.mode() === 'mini') player.full(); return; }
    if (S.settings.previewPlay && getComputedStyle(preview).display !== 'none') {
      player.open(ch, { mini: true, anchor: screen, list, positions: group === '__my' });
      vl.refresh();
    } else {
      player.open(ch, { list, positions: group === '__my', anchor: getComputedStyle(preview).display !== 'none' ? screen : null });
    }
  }

  const showInfo = debounce((ch) => {
    if (!el.isConnected) return;
    clear(infoEl); clear(actionsEl);
    const { now, next } = nowNext(ch);
    const ups = upcoming(ch, 6).filter((p) => !now || p[0] >= now[1]);
    add(infoEl, 
      h('div.eyebrow', `${S.settings.showNumbers ? (group === '__my' ? list.indexOf(ch) + 1 : ch.num) + ' · ' : ''}${ch.name}`),
      h('h3', now ? now[2] : 'No guide information'),
      now ? h('div.when', h('span.badge.live', 'Now'), h('span', `${fmtClock(now[0])} – ${fmtClock(now[1])}`), now[5] ? h('span', now[5]) : null) : h('div.when', ch.group),
      now && now[3] ? h('div.desc', now[3]) : null,
      ups.length ? h('div.upnext', ups.slice(0, 5).map((p) => h('div.upnext-row', h('span.t', fmtClock(p[0])), h('span.n', p[2])))) : null,
    );
    const playingThis = player.current() && player.current().id === ch.id;
    add(actionsEl, 
      h('button.btn.btn-sm' + (playingThis ? '.btn-primary' : ''), { onclick: () => playingThis ? player.full() : player.open(ch, { list, anchor: screen, positions: group === '__my' }) }, icon(playingThis ? 'fullscreen' : 'play'), playingThis ? 'Full screen' : 'Watch'),
      ch.catchup && now ? h('button.btn.btn-sm', { onclick: () => player.playCatchup(ch, now, { list }) }, icon('rewind'), 'Start over') : null,
      h('button.btn.btn-sm.btn-icon', { 'aria-label': 'Favourite', onclick: (e) => { const on = toggleFav(ch.id); e.currentTarget.replaceChildren(icon(on ? 'heartFill' : 'heart')); vl.refresh(); } }, icon(isFav(ch.id) ? 'heartFill' : 'heart')),
      h('button.btn.btn-sm.btn-icon', { 'aria-label': 'Multiview', onclick: () => import('./multiview.js').then((m) => { player.close(); m.openMultiview(ch); }) }, icon('grid')),
      castAvailable() ? h('button.btn.btn-sm.btn-icon', { 'aria-label': 'Cast', onclick: (e) => { const b = e.currentTarget; chooseAndCast(b, ch, () => { if (player.current() && player.current().id === ch.id) player.close(); return 0; }, list); } }, icon('cast')) : null,
    );
  }, 180);

  function sourceList() {
    const all = src ? visible('live', sourceItems(src)).filter((c) => !isHidden('live', gOf(c))) : visible('live', S.live);
    if (group === '__all') return all;
    // Your own list shows everything you put in it, whatever the country or quality filter.
    if (group === '__my') return myChannels();
    if (group === '__fav') return all.filter((c) => isFav(c.id));
    if (group === '__recent') { const set = new Set(all); return recentChannels(60).filter((c) => set.has(c)); }
    if (group === '__cu') return all.filter((c) => c.catchup);
    return all.filter((c) => gOf(c) === group);
  }

  function fill() {
    list = sourceList();
    if (sort === 'az') list = list.slice().sort((a, b) => a.name.localeCompare(b.name));
    else if (group === '__all' || group === '__fav') list = countryOrder(list, src);
    if (sort === 'az' && group === '__my') list = myChannels();
    sub.textContent = `${list.length.toLocaleString()} channel${list.length === 1 ? '' : 's'}`;
    vl.setCount(list.length);
    if (!list.length) {
      const [t, d] = group === '__fav' ? ['No favourite channels yet', 'Hold OK on a channel and choose Add to Favourites.']
        : group === '__my' ? ['Build your own channel list', 'Hold OK on any channel and choose Add to My channels. Then number and order them however you like.']
        : ['Nothing here', 'This group is empty.'];
      vl.inner.append(h('div', { style: { padding: '2rem' } }, emptyState(group === '__my' ? 'list' : 'live', t, d)));
    }
  }

  function setSrc(id) {
    src = id; group = '__all';
    titleEl.textContent = src ? srcPl().name : 'Live TV';
    paintGroups(); fill();
    requestAnimationFrame(() => nav.focusFirst(groupsEl));
  }

  function paintGroups() {
    clear(groupsEl);
    if (src) return paintSourceGroups();
    const all = visible('live', S.live);
    const special = [
      ['__all', 'All channels', all.length, 'live'],
      ['__my', 'My channels', myChannels().length, 'list'],
      ['__fav', 'Favourites', all.filter((c) => isFav(c.id)).length, 'heart'],
      ['__recent', 'Recently watched', recentChannels(60).length, 'history'],
    ];
    const cuCount = all.filter((c) => c.catchup).length;
    if (cuCount) special.push(['__cu', 'Catch-up', cuCount, 'rewind']);
    const btn = (key, label, n, ic) => h('button.group-btn' + (group === key ? '.on' : ''), {
      'data-autofocus': group === key ? '' : null,
      onclick: async () => {
        if (!key.startsWith('__') && !(await unlockIfNeeded('live', key))) return;
        group = key; paintGroups(); fill();
        requestAnimationFrame(() => { const f = vl.itemEl(0); if (f) nav.focus(f); });
      },
    }, ic ? icon(ic) : null, h('span.gname', label), h('span.n', n.toLocaleString()));
    for (const s of special) groupsEl.append(btn(...s));
    const srcs = orderedPlaylists().filter((p) => p.enabled !== false && S.srcCount.get(p.id));
    if (srcs.length > 1) {
      groupsEl.append(h('div.eyebrow.group-label', 'Sources'));
      for (const p of srcs) {
        const prov = providerOf(p);
        groupsEl.append(h('button.group-btn', { onclick: () => setSrc(p.id) }, appIcon(prov ? prov.icon : 'main'), h('span.gname', p.name), h('span.n', (S.srcCount.get(p.id) || 0).toLocaleString())));
      }
    }
    paintGroupList(visibleGroups('live'), (g) => btn(g.name, g.name, g.count, isFavGroup(g.name) ? 'heartFill' : null), paintGroups);
  }

  // Favourite groups first, then the rest. Hold OK on a group to favourite or hide it.
  function paintGroupList(groups, make, repaint) {
    const favs = groups.filter((g) => isFavGroup(g.name));
    const rest = groups.filter((g) => !isFavGroup(g.name));
    const add = (g) => {
      const b = make(g);
      b.lumenOptions = () => menu(b, g.name || 'Other', [
        { label: isFavGroup(g.name) ? 'Remove from favourite groups' : 'Add to favourite groups', run: () => {
          const on = toggleFavGroup(g.name);
          toast(on ? `${g.name} is now at the top` : `${g.name} removed from favourite groups`);
          repaint();
          requestAnimationFrame(() => nav.focus([...groupsEl.querySelectorAll('.group-btn')].find((x) => x.querySelector('.gname').textContent === (g.name || 'Other')) || groupsEl.firstChild));
        } },
        { label: 'Hide this group', run: () => {
          setSetting('hiddenGroups', [...new Set([...S.settings.hiddenGroups, 'live:' + g.name])]);
          toast(`${g.name} hidden · show it again in Settings → Groups`);
          if (group === g.name) group = '__all';
          repaint(); fill();
          requestAnimationFrame(() => nav.focusFirst(groupsEl));
        } },
      ]);
      groupsEl.append(b);
    };
    if (favs.length) { groupsEl.append(h('div.eyebrow.group-label', 'Favourite groups')); favs.forEach(add); }
    if (rest.length) { groupsEl.append(h('div.eyebrow.group-label', favs.length ? 'All groups' : 'Groups')); rest.forEach(add); }
  }

  function paintSourceGroups() {
    const pl = srcPl();
    const prov = providerOf(pl);
    const btn = (key, label, n, ic) => h('button.group-btn' + (group === key ? '.on' : ''), {
      'data-autofocus': group === key ? '' : null,
      onclick: async () => {
        if (!key.startsWith('__') && !(await unlockIfNeeded('live', key))) return;
        group = key; paintSourceGroups(); fill();
        requestAnimationFrame(() => { const f = vl.itemEl(0); if (f) nav.focus(f); });
      },
    }, ic ? icon(ic) : null, h('span.gname', label), h('span.n', n.toLocaleString()));
    clear(groupsEl);
    groupsEl.append(
      h('button.group-btn', { onclick: () => setSrc(null) }, icon('left'), h('span.gname', 'All sources')),
      h('div.src-head', appIcon(prov ? prov.icon : 'main'), h('div', h('div.t', pl.name), h('div.d', prov ? prov.org : 'Your playlist'))),
    );
    const groups = sourceGroups(src).filter((g) => !isHidden('live', g.name));
    groupsEl.append(btn('__all', 'All channels', groups.reduce((a, g) => a + g.count, 0)), btn('__my', 'My channels', myChannels().length, 'list'), btn('__fav', 'Favourites', visible('live', sourceItems(src)).filter((c) => isFav(c.id)).length));
    paintGroupList(S.settings.countries.length ? groups : groups.sort((a, b) => a.name.localeCompare(b.name)), (g) => btn(g.name, g.name || 'Other', g.count, isFavGroup(g.name) ? 'heartFill' : null), paintSourceGroups);
  }

  if (src && srcPl()) titleEl.textContent = srcPl().name; else src = null;
  paintGroups();
  fill();

  const offTuned = (e) => { if (el.isConnected) { vl.refresh(); showInfo(e.detail); } };
  document.addEventListener('lumen:tuned', offTuned);
  const offEpg = bus.on('epg', () => { if (!el.isConnected) return; vl.refresh(); if (focusedCh) showInfo(focusedCh); });
  const scrollFix = () => player.refreshMini();
  el.addEventListener('scroll', scrollFix);

  return {
    el,
    onShow() {
      vl.layout();
      const cur = player.current();
      let idx = cur ? list.findIndex((c) => c.id === cur.id) : -1;
      // Redrawn in the background: back on the channel you were on.
      if (idx < 0 && params.focusId) idx = list.findIndex((c) => c.id === params.focusId);
      if (cur && cur.type === 'live' && idx >= 0) {
        player.open(cur, { mini: true, anchor: screen, list });
      }
      const target = vl.scrollToIndex(Math.max(0, idx));
      if (target) nav.focus(target, { scroll: false });
      if (list[Math.max(0, idx)]) showInfo(list[Math.max(0, idx)]);
    },
    // What a background redraw needs to come back to the same place.
    snapshot: () => ({ group, src, focusId: focusedCh ? focusedCh.id : null }),
    destroy() {
      document.removeEventListener('lumen:tuned', offTuned);
      offEpg();
      vl.destroy();
      player.detachMini();
    },
  };
}

// ---------------- Guide ----------------
export function guideView() {
  const el = h('div.view', { style: { overflow: 'hidden' } });
  const SLOT = 30 * 60000;
  let t0 = Math.floor((Date.now() - SLOT) / SLOT) * SLOT;
  let group = '__all';
  let list = [];

  const dayEl = h('div.guide-day');
  const ruler = h('div.guide-ruler');
  const body = h('div.guide-body');
  const nowLine = h('div.g-now');
  const guide = h('div.guide.glass', h('div.guide-head', dayEl, ruler), body);

  const tools = h('div.guide-tools',
    h('button.btn.btn-sm.btn-icon', { 'aria-label': 'Earlier', onclick: () => shift(-2) }, icon('left')),
    h('button.btn.btn-sm', { onclick: () => { t0 = Math.floor((Date.now() - SLOT) / SLOT) * SLOT; repaint(); } }, 'Now'),
    h('button.btn.btn-sm.btn-icon', { 'aria-label': 'Later', onclick: () => shift(2) }, icon('right')),
  );
  const groupSel = h('select.input#guide-group', { style: { height: '2.4rem', width: 'auto', maxWidth: '16rem', borderRadius: '1.2rem', padding: '0 2.6rem 0 1rem', fontSize: '.92rem' }, onchange: () => { group = groupSel.value; fill(); } });
  const mainPl = mainPlaylist();
  if (mainPl) groupSel.append(h('option', { value: '__main' }, mainPl.name));
  groupSel.append(h('option', { value: '__all' }, mainPl ? 'All sources' : 'All channels'), h('option', { value: '__fav' }, 'Favourites'));
  if (myChannels().length) groupSel.append(h('option', { value: '__my' }, 'My channels'));
  if (mainPl) { group = '__main'; groupSel.value = '__main'; }
  for (const g of visibleGroups('live')) groupSel.append(h('option', { value: g.name }, g.name));
  el.append(topbar('Guide', S.epg.count ? `${S.epg.count.toLocaleString()} channels with programme information` : 'No guide loaded yet. Add a guide link in Settings.', groupSel, tools), guide);

  const ppm = () => parseFloat(getComputedStyle(guide).getPropertyValue('--ppm')) * rem() / 1; // px per minute
  const trackW = () => Math.max(200, body.clientWidth - parseFloat(getComputedStyle(guide).getPropertyValue('--cw')) * rem());
  const span = () => (trackW() / ppm()) * 60000;

  const vl = new VList({
    count: 0,
    overscan: 3,
    rowHeight: () => Math.round(rem() * 4.6),
    render: (i) => renderRow(list[i], i),
  });
  body.append(vl.el, nowLine);

  function renderRow(ch, i) {
    ensureGuide(ch);
    const row = h('div.g-row');
    row.dataset.vi = i;
    const chCell = h('div.g-ch', S.settings.showNumbers ? h('span.num', ch.num) : null, logoTile(ch.name, ch.logo), h('span.nm', ch.name));
    const track = h('div.g-track');
    const progs = progsFor(ch);
    const end = t0 + span();
    const now = Date.now();
    const px = ppm() / 60000;
    let any = false;
    for (const p of progs) {
      if (p[1] <= t0 || p[0] >= end) continue;
      any = true;
      const a = Math.max(p[0], t0), b = Math.min(p[1], end);
      const left = (a - t0) * px, width = Math.max(4, (b - a) * px - 4);
      const isNow = p[0] <= now && p[1] > now;
      const past = p[1] <= now;
      const cu = past && canCatchup(ch, p);
      const cell = h('div.g-cell.f' + (isNow ? '.now' : '') + (past ? '.past' : '') + (cu ? '.cu' : ''), {
        tabindex: '0', style: { left: left + 'px', width: width + 'px' },
        onclick: () => openProgramme(ch, p),
        onfocus: () => { setAmbient(ch.name); dayEl.textContent = fmtDay(p[0]); },
      },
      h('div.t', p[2]),
      width > 90 ? h('div.s', cu ? icon('rewind') : null, `${fmtClock(p[0])} – ${fmtClock(p[1])}`) : null);
      cell.dataset.start = p[0]; cell.dataset.stop = p[1];
      track.append(cell);
    }
    if (!any) {
      const cell = h('div.g-cell.f', { tabindex: '0', style: { left: '0px', width: trackW() - 4 + 'px' }, onclick: () => player.open(ch, { list }) },
        h('div.t', ch.name), h('div.s', 'No programme information'));
      cell.dataset.start = t0; cell.dataset.stop = end;
      track.append(cell);
    }
    chCell.addEventListener('click', () => player.open(ch, { list }));
    row.append(chCell, track);
    return row;
  }

  function paintRuler() {
    clear(ruler);
    const px = ppm() / 60000;
    const end = t0 + span();
    for (let t = t0; t < end; t += SLOT) {
      ruler.append(h('span', { style: { left: (t - t0) * px + 'px' } }, fmtClock(t)));
    }
    dayEl.textContent = fmtDay(t0 + SLOT);
    const now = Date.now();
    const cw = parseFloat(getComputedStyle(guide).getPropertyValue('--cw')) * rem();
    nowLine.hidden = now < t0 || now > end;
    nowLine.style.left = cw + (now - t0) * px + 'px';
  }

  function repaint(keepTime) {
    paintRuler();
    const act = document.activeElement;
    const rowIdx = act && act.closest && act.closest('.g-row') ? Number(act.closest('.g-row').dataset.vi) : null;
    vl.clearRows();
    vl.paint();
    if (rowIdx != null) focusAt(rowIdx, keepTime || t0 + SLOT);
  }

  function shift(hours, keepTime) {
    t0 += hours * 3600000;
    repaint(keepTime);
  }

  function fill() {
    const all = visible('live', S.live);
    list = group === '__my' ? myChannels() : group === '__all' ? all : group === '__main' ? all.filter((c) => c.srcs && c.srcs.includes(mainPl.id)) : group === '__fav' ? all.filter((c) => isFav(c.id)) : all.filter((c) => c.group === group);
    if (group === '__all' || group === '__main' || group === '__fav') list = countryOrder(list, group === '__main' ? mainPl.id : null);
    vl.setCount(list.length);
    paintRuler();
  }

  function cellsIn(rowIdx) {
    const r = vl.rows.get(rowIdx);
    return r ? Array.from(r.querySelectorAll('.g-cell')) : [];
  }

  function focusAt(rowIdx, t) {
    if (rowIdx < 0 || rowIdx >= list.length) return false;
    if (!vl.rows.get(rowIdx)) vl.scrollToIndex(rowIdx, 'top');
    const cells = cellsIn(rowIdx);
    if (!cells.length) return false;
    const c = cells.find((x) => Number(x.dataset.start) <= t && Number(x.dataset.stop) > t) || cells.reduce((best, x) => (Math.abs(Number(x.dataset.start) - t) < Math.abs(Number(best.dataset.start) - t) ? x : best), cells[0]);
    nav.focus(c);
    return true;
  }

  nav.custom(body, (k, t) => {
    const cell = t.closest('.g-cell');
    if (!cell) return false;
    const row = cell.closest('.g-row');
    const rowIdx = Number(row.dataset.vi);
    const start = Number(cell.dataset.start), stop = Number(cell.dataset.stop);
    const cursor = Math.max(start, t0) + Math.min(stop - Math.max(start, t0), 3600000) / 2;
    if (k === 'up' || k === 'down') {
      const target = rowIdx + (k === 'up' ? -1 : 1);
      if (target < 0) return false; // let focus leave to the toolbar
      if (target >= list.length) return true;
      focusAt(target, cursor);
      return true;
    }
    const cells = cellsIn(rowIdx);
    const i = cells.indexOf(cell);
    if (k === 'right') {
      if (cells[i + 1]) { nav.focus(cells[i + 1]); return true; }
      shift(1, stop + 1);
      return true;
    }
    if (k === 'left') {
      if (cells[i - 1]) { nav.focus(cells[i - 1]); return true; }
      if (start <= t0 && t0 > Date.now() - 7 * 86400000) { shift(-1, start - 1); return true; }
      return false; // leave to the rail
    }
    return false;
  });

  fill();
  const offEpg = bus.on('epg', () => { if (el.isConnected) repaint(); });
  const tick = setInterval(() => { if (el.isConnected) paintRuler(); }, 30000);

  return {
    el,
    onShow() {
      vl.layout();
      paintRuler();
      requestAnimationFrame(() => focusAt(0, Date.now()));
      new ResizeObserver(() => { if (el.isConnected) repaint(); }).observe(body);
    },
    destroy() { offEpg(); clearInterval(tick); vl.destroy(); },
  };
}

// ---------------- Movies & Series ----------------
// ---------- Movies and Series: Netflix-style rows ----------
// A featured banner, what you're watching and your favourites, then one row per category in
// your languages. Each category loads when its row comes near the screen and ends with
// "See all", which opens the full grid for that category.
function vodBrowse(kind) {
  const isMovie = kind === 'movie';
  const type = isMovie ? 'movie' : 'series';
  const route = isMovie ? 'movies' : 'series';
  const el = h('div.view.vod-browse');
  const groups = visibleGroups(type).filter((g) => !isLocked(type, g.name));
  const langBtn = h('button.btn.btn-sm', { onclick: () => openLangPicker() }, icon('globe'), h('span', vodLangs() ? langSummary().replace(' (from your countries)', '') : 'All languages'));
  const gridBtn = h('button.btn.btn-sm', { onclick: () => go(route, { group: groups[0] ? groups[0].name : '__all', grid: true }) }, icon('grid'), h('span', 'All categories'));
  el.append(topbar(isMovie ? 'Movies' : 'Series', `${groups.length} categor${groups.length === 1 ? 'y' : 'ies'}`, langBtn, gridBtn));
  if (!groups.length) {
    el.append(emptyState(isMovie ? 'movie' : 'series', `No ${isMovie ? 'films' : 'series'} here`, vodLangs() ? 'Nothing matches your languages. Choose more with the Languages button.' : 'Films and series appear when your playlist includes them.'));
    return { el };
  }
  el.append(featuredHero(() => null, type));

  const sub = (m) => [m.year, m.episodes ? null : catLabel(m.group)].filter(Boolean).join(' · ');
  const isType = (it) => (isMovie ? it.type === 'movie' : it.type !== 'movie');
  const cont = continueWatching().filter(isType);
  if (cont.length) el.append(removable(section('Continue watching', cont.map((it) => wideCard(it, (x) => player.open(x))), { more: 'Hold OK for options' }), cont, false, null));
  const favs = [...(isMovie ? S.movies : S.shows), ...loadedLazy(type), ...snapItems(type)].filter((m, i, a) => isFav(m.id) && a.findIndex((x) => x.id === m.id) === i);
  const favSec = section('Your favourites', favs.slice(0, 30).map((m) => posterCard(m, openItem)));
  if (favSec) el.append(favSec);

  for (const g of groups) el.append(categoryRow(g));

  function categoryRow(g) {
    // A placeholder you can land on while the row loads; focus moves to the first title after.
    const ph = h('div.tile.poster.f.ph-tile', { tabindex: '0', onfocus: () => start() }, h('div.tile-frame', h('span.spinner')), h('div.tile-meta', h('div.tile-title', 'Loading…')));
    const scroller = h('div.scroller', { 'data-remember': '' }, ph);
    const more = h('span.more', g.count ? `${g.count.toLocaleString()} titles` : '');
    const sec = h('section.section', h('div.section-head', h('h2', catLabel(g.name)), more), scroller);
    let started = false;
    const start = async () => {
      if (started) return;
      started = true;
      io.disconnect();
      try {
        const items = isLazyGroup(type, g.name) ? await loadLazyGroup(type, g.name) : (isMovie ? S.movies : S.shows).filter((x) => x.group === g.name);
        if (!sec.isConnected) return;
        const list = visible(type, items).sort((a, b) => (b.added || 0) - (a.added || 0) || (b.idx || 0) - (a.idx || 0));
        if (!list.length) { const n = sec.nextElementSibling || sec.previousElementSibling; const had = document.activeElement === ph; sec.remove(); if (had && n) nav.focusFirst(n); return; }
        more.textContent = `${list.length.toLocaleString()} title${list.length === 1 ? '' : 's'}`;
        const all = h('div.tile.poster.f.see-all', { tabindex: '0', onclick: () => go(route, { group: g.name, grid: true }) },
          h('div.tile-frame', icon('grid'), h('div.see-all-t', 'See all')), h('div.tile-meta', h('div.tile-title', catLabel(g.name)), h('div.tile-sub', `${list.length.toLocaleString()} titles`)));
        // If you were waiting on this row, move onto its first title.
        const wasHere = document.activeElement === ph || document.activeElement === document.body;
        clear(scroller).append(...list.slice(0, 24).map((m) => posterCard(m, openItem, { sub: m.year ? String(m.year) : '' })), all);
        if (wasHere) nav.focus(scroller.firstChild, { scroll: false });
      } catch {
        if (sec.isConnected) ph.querySelector('.tile-title').textContent = 'Couldn’t load · try later';
      }
    };
    // The page itself scrolls, so watch against it: rows start loading about two rows ahead.
    const io = new IntersectionObserver((e) => { if (e.some((x) => x.isIntersecting)) start(); }, { root: el, rootMargin: '1100px 0px' });
    requestAnimationFrame(() => io.observe(sec));
    return sec;
  }

  return { el };
}

export function vodView(kind, params = {}) {
  // Without a category the page shows rows; "See all" and "All categories" open the grid.
  if (!params.grid) return vodBrowse(kind);
  const route = kind === 'movie' ? 'movies' : 'series';
  const isMovie = kind === 'movie';
  const type = isMovie ? 'movie' : 'series';
  // Titles in memory: your playlists' own, plus any on-demand categories opened this session.
  const source = () => {
    const base = isMovie ? S.movies : S.shows;
    const seen = new Set(base.map((x) => x.id));
    return visible(type, [...base, ...loadedLazy(type).filter((x) => !seen.has(x.id))]);
  };
  const favourites = () => {
    const all = source();
    const ids = new Set(all.map((x) => x.id));
    return [...all.filter((x) => isFav(x.id)), ...snapItems(type).filter((x) => isFav(x.id) && !ids.has(x.id))];
  };
  const el = h('div.view', { style: { overflow: 'hidden' } });
  const ownCount = () => visible(type, isMovie ? S.movies : S.shows).length;
  const firstLazy = () => visibleGroups(type).find((g) => g.lazy);
  // Big Xtream providers load one category at a time, so open on the first category instead of "All".
  let group = params.group && visibleGroups(type).some((g) => g.name === params.group) ? params.group : !ownCount() && firstLazy() ? firstLazy().name : '__all';
  let sort = 'added';
  let list = [];
  let loadingToken = 0;

  const sorts = [['added', 'Recently added'], ['az', 'A–Z'], ['year', 'Newest'], ['rating', 'Top rated']];
  const sortBtn = h('button.btn.btn-sm', { onclick: () => import('./common.js').then((c) => c.menu(sortBtn, 'Sort by', sorts.map(([k, l]) => ({ label: l, on: sort === k, run: () => { sort = k; sortBtn.lastChild.textContent = l; fill(); } })))) }, icon('list'), h('span', 'Recently added'));
  el.append(topbar(isMovie ? 'Movies' : 'Series', ''));
  const sub = h('div.sub');
  el.querySelector('.topbar > div').append(sub);

  const chips = h('div.chips', { 'data-remember': '' });
  const langBtn = h('button.btn.btn-sm', { onclick: () => openLangPicker() }, icon('globe'), h('span', vodLangs() ? langSummary().replace(' (from your countries)', '') : 'All languages'));
  el.append(h('div.toolbar', chips, h('div.row', { style: { gap: '.8rem', flex: 'none' } }, langBtn, sortBtn)));

  const grid = h('div.vod-grid');
  el.append(grid);
  const vl = new VList({
    count: 0, gap: Math.round(rem() * 1.2), overscan: 2,
    cols: (w) => Math.max(2, Math.floor((w + rem() * 1.6) / (rem() * (innerWidth < 720 ? 8 : 11.5) + rem() * 1.6))),
    rowHeight: (w, cols) => {
      const colW = (w - rem() * 2.4 - (cols - 1) * rem() * 1.6) / cols;
      return Math.round(colW * 1.5 + rem() * 3.6);
    },
    render: (i) => posterCard(list[i], openItem),
  });
  grid.append(vl.el);

  function paintChips() {
    clear(chips);
    const favN = favourites().length;
    const mk = (key, label, n) => h('button.chip' + (group === key ? '.on' : ''), {
      onclick: async () => {
        if (!key.startsWith('__') && !(await unlockIfNeeded(type, key))) return;
        group = key; paintChips(); fill();
      },
    }, label, n != null ? h('span.n', n.toLocaleString()) : null);
    if (ownCount() || !firstLazy()) chips.append(mk('__all', 'All', ownCount()));
    if (favN) chips.append(mk('__fav', 'Favourites', favN));
    for (const g of visibleGroups(type)) chips.append(mk(g.name, catLabel(g.name), g.lazy ? null : g.count));
  }

  function show(items) {
    for (const x of vl.inner.querySelectorAll(':scope > :not(.vl-row)')) x.remove();
    list = items.slice();
    if (sort === 'az') list.sort((a, b) => a.name.localeCompare(b.name));
    else if (sort === 'year') list.sort((a, b) => (b.year || 0) - (a.year || 0));
    else if (sort === 'rating') list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    else list.sort((a, b) => (b.added || 0) - (a.added || 0) || (b.idx || 0) - (a.idx || 0));
    sub.textContent = `${list.length.toLocaleString()} ${isMovie ? (list.length === 1 ? 'movie' : 'movies') : 'series'}`;
    vl.setCount(list.length);
  }

  async function fill() {
    const tok = ++loadingToken;
    if (group === '__fav') return show(favourites());
    if (group === '__all') {
      show(visible(type, isMovie ? S.movies : S.shows));
      if (!list.length) vl.inner.append(emptyState(isMovie ? 'movie' : 'series', `No ${isMovie ? 'movies' : 'series'} here`, isMovie ? 'Movies appear when your playlist includes VOD entries.' : 'Series appear when your playlist includes episodes.'));
      return;
    }
    const own = source().filter((x) => x.group === group);
    if (isLazyGroup(type, group)) {
      show(own);
      sub.textContent = 'Loading…';
      vl.inner.append(h('div.empty-state', h('div.spinner'), h('h3', `Loading ${group}`), h('p', 'Large providers send one category at a time.')));
      try {
        await loadLazyGroup(type, group);
      } catch (e) {
        if (tok !== loadingToken) return;
        show([]);
        vl.inner.append(emptyState(isMovie ? 'movie' : 'series', 'This category didn’t load', e.message || 'The provider didn’t answer. Try again in a moment.'));
        return;
      }
      if (tok !== loadingToken) return;
      paintChips();
      return show(source().filter((x) => x.group === group));
    }
    show(own);
  }

  paintChips();
  fill();
  return {
    el,
    onShow() { vl.layout(); requestAnimationFrame(() => nav.focus(chips.querySelector('.chip.on') || chips.firstChild)); },
    destroy() { vl.destroy(); },
    // Back returns to the rows.
    back: () => go(route),
  };
}

// ---------------- Search ----------------
export function searchView() {
  const el = h('div.view');
  el.append(topbar('Search', 'Channels, movies, series and what is on TV'));
  const input = h('input.input#search-q', { type: 'search', placeholder: 'Search', autocomplete: 'off', 'data-autofocus': '' });
  el.append(h('div.search-box', icon('search'), input));
  const status = h('div.search-status');
  const results = h('div');
  el.append(status, results);

  // Big providers: fetch the film and series catalogue (in your languages) in the background,
  // and search it as it arrives.
  const catalogNote = (done, total) => {
    if (!el.isConnected) return;
    status.replaceChildren(done < total ? h('span', h('span.spinner'), `Getting the film and series list from your provider… ${done} of ${total} categories`) : '');
    if (input.value.trim().length >= 2) rerun();
  };
  let rerunT = 0;
  const rerun = () => { if (rerunT) return; rerunT = setTimeout(() => { rerunT = 0; run(); }, 900); };
  if (hasLazy('movie') || hasLazy('series')) {
    const st = catalogStatus();
    if (!st.done) status.replaceChildren(h('span', h('span.spinner'), 'Getting the film and series list from your provider…'));
    ensureCatalog(catalogNote).then(() => { if (el.isConnected) { status.replaceChildren(); if (input.value.trim().length >= 2) run(); } });
  }
  // Everything searchable of one kind, each title once.
  const pool = (type) => {
    const seen = new Set(), out = [];
    for (const x of [...(type === 'movie' ? S.movies : S.shows), ...loadedLazy(type), ...catalogTitles(type)]) if (!seen.has(x.id)) { seen.add(x.id); out.push(x); }
    return out;
  };

  const run = debounce(() => {
    const q = input.value.trim().toLowerCase();
    clear(results);
    if (q.length < 2) {
      results.append(emptyState('search', 'Start typing', 'Find a channel by name or number, a movie, a series, or a programme in the guide.'));
      return;
    }
    const nq = normName(q);
    const score = (name) => { const n = name.toLowerCase(); return n.startsWith(q) ? 0 : n.includes(q) ? 1 : normName(name).includes(nq) ? 2 : 9; };
    const pick = (arr, type) => visible(type, arr).map((x) => [score(x.name), x]).filter((x) => x[0] < 9).sort((a, b) => a[0] - b[0]).slice(0, 40).map((x) => x[1]);
    const liveVis = visible('live', S.live);
    let ch = pick(S.live, 'live');
    if (/^\d+$/.test(q)) ch = [...liveVis.filter((c) => String(c.num) === q), ...ch];
    const mv = pick(pool('movie'), 'movie');
    const sh = pick(pool('series'), 'series');
    const pr = S.epg.count ? searchProgrammes(q, 30) : [];
    const secs = [
      section('Channels', ch.map((c) => channelTile(c, (x) => player.open(x, { list: liveVis })))),
      section('On TV', pr.map(({ ch: c, p }) => progResult(c, p))),
      section('Movies', mv.map((m) => posterCard(m, openItem))),
      section('Series', sh.map((m) => posterCard(m, openItem))),
    ].filter(Boolean);
    if (!secs.length) results.append(emptyState('search', catalogStatus().busy ? 'Still looking…' : 'No results', catalogStatus().busy ? 'Films and series are still arriving from your provider.' : `Nothing matches “${input.value.trim()}”. Check the spelling or try fewer words.`));
    results.append(...secs);
  }, 220);

  input.addEventListener('input', run);
  // On a TV the search box only opens the keyboard when you press OK on it. Moving onto it
  // with the arrows just highlights it; Down goes to the first result.
  input.addEventListener('blur', () => { input.readOnly = true; });
  // Re-focusing after making it editable is what makes Android show the keyboard.
  const edit = () => { if (!input.readOnly) return; input.blur(); input.readOnly = false; input.focus(); };
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && input.readOnly) { e.preventDefault(); e.stopPropagation(); edit(); return; }
    // A real keyboard: typing just starts typing.
    if (e.key.length === 1 && input.readOnly) input.readOnly = false;
    if (e.key === 'ArrowDown') {
      const first = results.querySelector('.f');
      if (first) { e.preventDefault(); e.stopPropagation(); nav.focus(first, { block: 'center' }); }
    }
  });
  input.addEventListener('pointerdown', () => { input.readOnly = false; });
  run();
  return { el, onShow() { input.readOnly = false; input.focus(); } };
}

function progResult(ch, p) {
  return h('div.tile.prog-res.f', { tabindex: '0', onclick: () => openProgramme(ch, p) },
    h('div.tile-frame', logoTile(ch.name, ch.logo), h('div', { style: { minWidth: 0 } }, h('div.tile-title', p[2]), h('div.tile-sub', `${fmtDay(p[0])} ${fmtClock(p[0])} · ${ch.name}`))));
}

// ---------------- Favourites ----------------
export function favouritesView() {
  const el = h('div.view');
  el.append(topbar('Favourites', 'Everything you have saved'));
  const liveVis = visible('live', S.live);
  const ch = liveVis.filter((c) => isFav(c.id));
  const favOf = (type, base) => {
    const ids = new Set();
    return [...base, ...loadedLazy(type), ...snapItems(type)].filter((m) => isFav(m.id) && !ids.has(m.id) && ids.add(m.id));
  };
  const mv = visible('movie', favOf('movie', S.movies));
  const sh = visible('series', favOf('series', S.shows));
  const reminders = S.reminders.slice().sort((a, b) => a.start - b.start);
  const remEls = reminders.map((r) => {
    const c = S.byId.get(r.ch);
    if (!c) return null;
    return h('div.tile.prog-res.f', { tabindex: '0', onclick: () => { removeReminder(r.key); toast('Reminder removed'); go('favourites'); } },
      h('div.tile-frame', logoTile(c.name, c.logo), h('div', { style: { minWidth: 0 } }, h('div.tile-title', r.title), h('div.tile-sub', `${fmtDay(r.start)} ${fmtClock(r.start)} · Select to remove`))));
  }).filter(Boolean);
  const secs = [
    section('Channels', ch.map((c) => channelTile(c, (x) => player.open(x, { list: ch })))),
    section('Movies', mv.map((m) => posterCard(m, openItem))),
    section('Series', sh.map((m) => posterCard(m, openItem))),
    section('Reminders', remEls),
  ].filter(Boolean);
  if (!secs.length) el.append(emptyState('heart', 'Nothing saved yet', 'Select the heart on any channel, movie or series to keep it here.'));
  el.append(...secs);
  return { el };
}

let goFn = () => {};
export function setGo(fn) { goFn = fn; }
function go(v, p) { goFn(v, p); }
