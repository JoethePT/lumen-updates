// Detail sheets for movies, series and guide programmes.
import { h, add, clear, fmtClock, fmtDay, fmtMins, fmtDur, toast, posterTile, logoTile } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import {
  S, isFav, toggleFav, getPosition, progressOf, vodInfo, seriesInfo, canCatchup,
  addReminder, hasReminder, isLocked,
} from '../store.js';
import { openLayer, setAmbient, unlockIfNeeded } from './common.js';
import * as player from './player-ui.js';
import { castButton } from '../cast.js';

function favBtn(id) {
  const b = h('button.btn.btn-icon', { 'aria-label': 'Favourite', onclick: () => { const on = toggleFav(id); b.replaceChildren(icon(on ? 'heartFill' : 'heart')); toast(on ? 'Added to favourites' : 'Removed from favourites'); } }, icon(isFav(id) ? 'heartFill' : 'heart'));
  return b;
}

function shell(bgImg, ...content) {
  const closeBtn = h('button.btn.btn-icon.close', { 'aria-label': 'Close', onclick: () => L.close() }, icon('close'));
  const sheet = h('div.sheet.glass-strong', bgImg ? h('div.sheet-bg', { style: { backgroundImage: `url("${bgImg}")` } }) : null, closeBtn, h('div.sheet-body', ...content));
  const L = openLayer(sheet);
  return L;
}

export async function openMovie(item) {
  if (!(await unlockIfNeeded('movie', item.group))) return;
  setAmbient(item.name, item.logo);
  const pos = getPosition(item.id);
  const meta = h('div.meta', item.year ? h('span', item.year) : null, item.rating ? h('span.star', icon('star'), (item.rating > 10 ? item.rating / 10 : item.rating).toFixed(1)) : null, h('span', item.group));
  const plot = h('p.plot', item.plot || '');
  const credits = h('p.credits');
  const actions = h('div.row',
    h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => { L.close(); player.open(item, { startAt: pos }); } }, icon('play'), pos ? `Resume from ${fmtDur(pos)}` : 'Play'),
    pos ? h('button.btn', { onclick: () => { L.close(); player.open(item, { startAt: 0 }); } }, icon('refresh'), 'Start over') : null,
    castButton(item, () => getPosition(item.id)),
    favBtn(item.id),
  );
  const prog = progressOf(item.id);
  const L = shell(item.logo,
    h('div.tile.poster', h('div.tile-frame', posterTile(item.name, item.logo), prog ? h('div.bar', h('i', { style: { width: prog * 100 + '%' } })) : null)),
    h('div', { style: { minWidth: 0 } }, h('div.eyebrow', 'Movie'), h('h2', item.name.replace(/\s*\((19|20)\d\d\)\s*$/, '')), meta, plot, credits, actions),
  );
  const info = await vodInfo(item);
  if (info) {
    if (info.plot) plot.textContent = info.plot;
    if (info.dur) meta.append(h('span', fmtMins(info.dur / 60)));
    if (info.genre) meta.append(h('span', info.genre));
    const c = [info.director && `Director: ${info.director}`, info.cast && `Cast: ${info.cast}`].filter(Boolean).join('  ·  ');
    credits.textContent = c;
    if (info.backdrop) { const bg = L.el.querySelector('.sheet-bg'); if (bg) bg.style.backgroundImage = `url("${info.backdrop}")`; }
  }
  if (!plot.textContent) plot.remove();
  if (!credits.textContent) credits.remove();
}

export async function openShow(show) {
  if (!(await unlockIfNeeded('series', show.group))) return;
  setAmbient(show.name, show.logo);
  const meta = h('div.meta', show.year ? h('span', show.year) : null, show.rating ? h('span.star', icon('star'), (show.rating > 10 ? show.rating / 10 : show.rating).toFixed(1)) : null, h('span', show.group));
  const plot = h('p.plot', show.plot || '');
  const actions = h('div.row');
  const seasonsEl = h('div.seasons', h('div.progress-line', h('div.spinner'), h('span', 'Loading episodes…')));
  const L = shell(show.backdrop || show.logo,
    h('div.tile.poster', h('div.tile-frame', posterTile(show.name, show.logo))),
    h('div', { style: { minWidth: 0 } }, h('div.eyebrow', 'Series'), h('h2', show.name), meta, plot, actions, seasonsEl),
  );
  let info;
  try { info = await seriesInfo(show); } catch (e) {
    clear(seasonsEl).append(h('div.err', e.message || 'Episodes could not be loaded.'));
    if (resume) { const cb = castButton(resume, () => getPosition(resume.id)); if (cb) actions.append(cb); }
  actions.append(favBtn(show.id));
    return;
  }
  if (info.plot) plot.textContent = info.plot;
  if (!plot.textContent) plot.remove();
  if (info.genre) meta.append(h('span', info.genre));
  const eps = info.episodes.slice().sort((a, b) => a.ep.s - b.ep.s || a.ep.e - b.ep.e);
  for (const e of eps) { e.showId = show.id; S.meta.set(e.id, e); }
  const seasons = [...new Set(eps.map((e) => e.ep.s))];
  meta.append(h('span', `${seasons.length} season${seasons.length === 1 ? '' : 's'} · ${eps.length} episodes`));

  // Resume where the viewer left off, otherwise start at the beginning.
  const last = S.history.find((x) => x.showId === show.id);
  let resume = eps[0];
  if (last) {
    const i = eps.findIndex((e) => e.id === last.id);
    if (i >= 0) resume = last.dur && last.pos / last.dur > 0.95 ? eps[i + 1] || eps[i] : eps[i];
  }
  const play = (ep) => { L.close(); player.open(ep, { list: eps }); };
  if (resume) {
    actions.append(h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => play(resume) }, icon('play'), last ? `Continue S${resume.ep.s} E${resume.ep.e}` : `Play S${resume.ep.s} E${resume.ep.e}`));
  }
  if (resume) { const cb = castButton(resume, () => getPosition(resume.id)); if (cb) actions.append(cb); }
  actions.append(favBtn(show.id));

  let cur = resume ? resume.ep.s : seasons[0];
  const tabs = h('div.tabs', { style: { display: 'inline-flex', marginBottom: 0 } });
  const list = h('div.ep-list');
  function paint() {
    clear(tabs);
    for (const s of seasons) tabs.append(h('button.tab' + (s === cur ? '.on' : ''), { onclick: () => { cur = s; paint(); } }, `Season ${s}`));
    clear(list);
    for (const ep of eps.filter((e) => e.ep.s === cur)) {
      const p = progressOf(ep.id);
      list.append(h('div.ep.f', { tabindex: '0', onclick: () => play(ep) },
        h('div.thumb', posterTile(ep.ep.title || show.name, ep.logo || show.logo), p ? h('div.bar', h('i', { style: { width: p * 100 + '%' } })) : null),
        h('div', { style: { minWidth: 0 } }, h('div.et', `${ep.ep.e}. ${ep.ep.title || 'Episode ' + ep.ep.e}`), ep.plot ? h('div.ed', ep.plot) : null),
        h('div.en', ep.dur ? fmtMins(ep.dur / 60) : `E${ep.ep.e}`)));
    }
  }
  add(clear(seasonsEl), seasons.length > 1 ? tabs : null, list);
  paint();
  if (!L.el.contains(document.activeElement)) nav.focusFirst(L.el.querySelector('.sheet'));
}

export function openProgramme(ch, prog) {
  const now = Date.now();
  const live = prog[0] <= now && prog[1] > now;
  const past = prog[1] <= now;
  const cu = canCatchup(ch, prog) || (live && ch.catchup);
  const actions = h('div.row');
  let L;
  if (live) actions.append(h('button.btn.btn-primary', { 'data-autofocus': '', onclick: () => { L.close(); player.open(ch); } }, icon('play'), 'Watch live'));
  if (cu) actions.append(h('button.btn' + (past ? '.btn-primary' : ''), { 'data-autofocus': past ? '' : null, onclick: () => { L.close(); player.playCatchup(ch, prog); } }, icon('rewind'), live ? 'Start over' : 'Watch now'));
  if (!live && !past) {
    const on = hasReminder(ch, prog);
    actions.append(h('button.btn.btn-primary', { 'data-autofocus': '', disabled: on, onclick: (e) => { if (addReminder(ch, prog)) { toast(`We'll remind you when ${prog[2]} starts`); e.currentTarget.textContent = 'Reminder set'; e.currentTarget.disabled = true; } } }, icon('bell'), on ? 'Reminder set' : 'Remind me'));
  }
  actions.append(h('button.btn', { onclick: () => { L.close(); player.open(ch); } }, icon('live'), `Go to ${ch.name}`));
  const dur = (prog[1] - prog[0]) / 60000;
  L = shell(prog[6] || null,
    h('div', { style: { display: 'flex', flexDirection: 'column', gap: '1rem' } },
      h('div.tile.ch-tile', { style: { width: '100%' } }, h('div.tile-frame', logoTile(ch.name, ch.logo))),
      h('div.muted', { style: { fontWeight: 600 } }, ch.name)),
    h('div', { style: { minWidth: 0 } },
      h('div.row', { style: { gap: '.6rem' } }, live ? h('span.badge.live', 'On now') : null, past && cu ? h('span.badge', icon('rewind'), 'Catch-up') : null, prog[8] ? h('span.badge', 'New') : null),
      h('h2', prog[2]),
      h('div.meta', h('span', `${fmtDay(prog[0])} · ${fmtClock(prog[0])} – ${fmtClock(prog[1])}`), h('span', fmtMins(dur)), prog[5] ? h('span', prog[5]) : null, prog[4] ? h('span', prog[4]) : null),
      prog[7] ? h('p.plot', { style: { fontWeight: 600, color: 'var(--fg)', marginBottom: '.6rem' } }, prog[7]) : null,
      prog[3] ? h('p.plot', prog[3]) : null,
      actions),
  );
  if (isLocked('live', ch.group)) actions.prepend(h('span.badge', icon('lock'), 'Locked'));
}
