// Adding playlists: M3U file, M3U link, Xtream Codes login, or the sample playlist.
import { h, add, clear, toast } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import { S, addPlaylist, loadEpgFile, loadEpg } from '../store.js';
import { openLayer } from './common.js';
import { describeCounts } from '../store.js';
import { companion, pairPanel } from '../companion.js';

export function playlistForm(onDone, opts = {}) {
  let tab = 'file';
  let file = null;
  const wrap = h('div');
  const status = h('div', { style: { minHeight: '1.6rem', marginTop: '1rem' } });

  const tabs = h('div.tabs', { role: 'tablist' });
  const body = h('div.stack');
  const TABS = [['file', 'M3U file'], ['url', 'M3U link'], ['xtream', 'Xtream login']];

  function paintTabs() {
    clear(tabs);
    for (const [k, l] of TABS) {
      tabs.append(h('button.tab' + (k === tab ? '.on' : ''), { role: 'tab', onclick: () => { tab = k; paintTabs(); paintBody(); } }, l));
    }
  }

  const name = h('input.input#pl-name', { placeholder: 'Living room', autocomplete: 'off' });
  const url = h('input.input#pl-url', { placeholder: 'https://provider.example/playlist.m3u', autocomplete: 'off', inputmode: 'url' });
  const server = h('input.input#xc-server', { placeholder: 'http://provider.example:8080', autocomplete: 'off', inputmode: 'url' });
  const user = h('input.input#xc-user', { placeholder: 'Username', autocomplete: 'off' });
  const pass = h('input.input#xc-pass', { placeholder: 'Password', type: 'password', autocomplete: 'off' });
  const fileInput = h('input', { type: 'file', accept: '.m3u,.m3u8,.txt,.gz,audio/x-mpegurl,application/vnd.apple.mpegurl', hidden: true });
  const dropLabel = h('b', 'Choose an M3U file');
  const drop = h('div.drop', { tabindex: '0', onclick: () => fileInput.click() },
    icon('upload'), dropLabel, h('span', 'or drag it here. .m3u, .m3u8 and .gz files work.'));
  fileInput.addEventListener('change', () => setFile(fileInput.files[0]));
  drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]); });
  function setFile(f) {
    if (!f) return;
    file = f;
    dropLabel.textContent = f.name;
    if (!name.value) name.value = f.name.replace(/\.(m3u8?|txt|gz)$/i, '').replace(/[_-]+/g, ' ');
  }

  const field = (label, input) => h('div.field', h('label', { for: input.id }, label), input);

  function paintBody() {
    clear(body);
    if (tab === 'file') body.append(drop, fileInput, field('Name', name));
    if (tab === 'url') body.append(field('Playlist link', url), field('Name', name));
    if (tab === 'xtream') body.append(field('Server address', server), h('div', { style: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' } }, field('Username', user), field('Password', pass)), field('Name', name));
  }

  const submit = h('button.btn.btn-accent', { onclick: () => go() }, 'Add playlist');
  const demo = h('button.btn', { onclick: () => addDemo(status, onDone) }, icon('sparkle'), 'Try the sample playlist');

  async function go() {
    let def;
    if (tab === 'file') {
      if (!file) return err('Choose a playlist file first.');
      def = { kind: 'm3u-file', name: name.value.trim() || file.name, file };
    } else if (tab === 'url') {
      const u = url.value.trim();
      if (!/^https?:\/\//i.test(u)) return err('Enter a link that starts with http:// or https://');
      def = { kind: 'm3u-url', name: name.value.trim() || new URL(u).host, url: u };
    } else {
      if (!server.value.trim() || !user.value.trim()) return err('Enter the server address, username and password from your provider.');
      def = { kind: 'xtream', name: name.value.trim() || server.value.trim().replace(/^https?:\/\//, ''), acc: { server: server.value.trim(), user: user.value.trim(), pass: pass.value } };
    }
    def.main = !!opts.main;
    await run(def, status, onDone);
  }

  function err(m) { clear(status); status.append(h('div.err', m)); }

  paintTabs(); paintBody();
  const extra = opts.freeStart
    ? h('button.btn', { onclick: opts.freeStart }, icon('live'), 'Start with free channels')
    : window.LUMEN_PREVIEW && opts.showDemo !== false ? demo : null;
  add(wrap, tabs, body, status, h('div.actions', extra, submit));
  return wrap;
}

async function run(def, status, onDone) {
  const line = h('div.progress-line', h('div.spinner'), h('span', 'Starting'));
  clear(status); status.append(line);
  try {
    const pl = await addPlaylist(def, (step) => { line.lastChild.textContent = step + '…'; });
    const c = pl.counts;
    const n = (k, one, many) => `${k.toLocaleString()} ${k === 1 ? one : many}`;
    toast(`Added ${pl.name}: ${describeCounts(c)}`);
    onDone && onDone(pl);
  } catch (e) {
    clear(status);
    status.append(h('div.err', e.message || String(e)));
  }
}

async function addDemo(status, onDone) {
  await run({ kind: 'demo', name: 'Sample playlist', url: new URL('samples/demo.m3u', location.href).href }, status, async (pl) => {
    try { await loadEpgFile(new File([demoEpg()], 'sample-guide.xml')); } catch (e) { console.warn(e); }
    onDone && onDone(pl);
  });
}

export function openAddPlaylist(onDone, opts = {}) {
  const box = h('div.modal.glass-strong', h('h2', opts.main ? 'Add your main playlist' : 'Add a playlist'),
    h('p.lead', opts.main ? 'Your main playlist is the first card on Home and comes first in Live TV.' : 'Bring your own M3U playlist or sign in with the Xtream details your provider gave you.'));
  let L;
  if (companion.info) box.append(pairPanel(), h('div.or', h('span', 'or type it here')));
  box.append(playlistForm((pl) => { L.close(); onDone && onDone(pl); }, { main: opts.main, showDemo: false }));
  L = openLayer(box);
}

// A rolling sample guide so the demo channels have a realistic schedule.
export function demoEpg() {
  const shows = {
    'demo.1': [['Morning Signal', 'Live test transmission from the edge network.', 'News'], ['Latency Lab', 'Measuring glass-to-glass delay in real time.', 'Technology'], ['The Bitrate Hour', 'Adaptive streaming, explained frame by frame.', 'Documentary'], ['Night Feed', 'Overnight continuous programming.', 'Ambient']],
    'demo.2': [['Eight O\'Clock Live', 'Evening magazine show.', 'Entertainment'], ['Studio Eight', 'Interviews and performances.', 'Talk'], ['Weekend Replay', 'Highlights from the week.', 'Entertainment']],
    'demo.3': [['24x7 Headlines', 'Top stories every half hour.', 'News'], ['Business Today', 'Markets and money.', 'Business'], ['The Big Fight', 'Debate on the issues of the day.', 'Current affairs'], ['World This Week', 'Global news round-up.', 'News']],
    'demo.4': [['Bip-Bop Test Card', 'Colour bars and line-up tone.', 'Test'], ['Calibration Loop', 'Audio and video sync pattern.', 'Test']],
    'demo.5': [['Big Buck Bunny', 'A giant rabbit takes on three bullies.', 'Animation'], ['Open Movie Night', 'Films from the open-source animation community.', 'Film']],
    'demo.6': [['Blender Showcase', 'Short films made with Blender.', 'Animation'], ['Render Farm', 'Behind the scenes of an open movie.', 'Documentary'], ['Studio Shorts', 'Student and studio short films.', 'Film']],
  };
  const pad = (n) => String(n).padStart(2, '0');
  const ts = (t) => { const d = new Date(t); return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}00 +0000`; };
  const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<tv>\n';
  const names = { 'demo.1': 'Akamai Live Test', 'demo.2': 'Eight Live', 'demo.3': 'NDTV 24x7', 'demo.4': 'Bip-Bop Test Card', 'demo.5': 'Mux Test Channel', 'demo.6': 'Blender Channel' };
  for (const [id, n] of Object.entries(names)) xml += `<channel id="${id}"><display-name>${esc(n)}</display-name></channel>\n`;
  const start = new Date(); start.setMinutes(0, 0, 0);
  const t0 = start.getTime() - 26 * 3600000, t1 = start.getTime() + 30 * 3600000;
  for (const [id, list] of Object.entries(shows)) {
    let t = t0, i = id.charCodeAt(5) % list.length, ep = 1;
    while (t < t1) {
      const [title, desc, cat] = list[i % list.length];
      const len = [30, 60, 60, 90, 30, 120][(i + ep) % 6] * 60000;
      xml += `<programme start="${ts(t)}" stop="${ts(t + len)}" channel="${id}"><title>${esc(title)}</title><desc>${esc(desc)} Sample schedule.</desc><category>${esc(cat)}</category><episode-num system="xmltv_ns">0.${ep - 1}.</episode-num></programme>\n`;
      t += len; i++; ep = (ep % 12) + 1;
    }
  }
  return xml + '</tv>\n';
}

export async function refreshGuide() {
  if (window.LUMEN_PREVIEW && S.playlists.some((p) => p.kind === 'demo')) {
    await loadEpgFile(new File([demoEpg()], 'sample-guide.xml'));
    return;
  }
  await loadEpg(true);
}

export { nav };
