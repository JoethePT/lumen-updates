// Settings: playlists, guide, playback, appearance, parental controls, groups, backup.
import { h, clear, toast, fmtClock, fmtDay } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import { net } from '../net.js';
import {
  S, bus, setSetting, saveSettings, refreshPlaylist, removePlaylist, renamePlaylist, loadEpgFile,
  exportBackup, importBackup, groupKey, mainPlaylist, setMain, builtinSources, setSource, syncBuiltins,
  probeSource, loadLibrary, describeCounts, guideForCountries,
} from '../store.js';
import { appIcon, providerOf } from '../providers.js';
import { pairPanel, newPin } from '../companion.js';
import { openCountryPicker, countrySummary } from './countrypicker.js';
import { QUALITIES } from '../store.js';
import { updatesAvailable, updateStatus, checkForUpdates, installAppUpdate, restartForUpdate, onUpdate } from '../updates.js';
import { openLangPicker, langSummary } from './langpicker.js';
import { homeOrder, homeRowNames, moveHomeRow, setHomeRowHidden } from './views.js';
import { serviceList, serviceIcon, moveService, setServiceHidden } from '../services.js';
import { menu, confirmBox, askPin, openLayer, topbar, toggleEl } from './common.js';
import { openAddPlaylist, refreshGuide } from './sources.js';
import { applyTheme, UI_SCALES } from '../theme.js';

const ACCENTS = [['#0A84FF', 'Blue'], ['#5E5CE6', 'Indigo'], ['#BF5AF2', 'Violet'], ['#FF375F', 'Rose'], ['#FF9F0A', 'Amber'], ['#30D158', 'Mint'], ['#64D2FF', 'Sky']];
const ROW_INFO = {
  mylist: 'Your own channel list, in your order', services: 'Netflix, Disney+ and the other services your provider carries',
  continue: 'Films and episodes you started', favch: 'Channels you hearted', recent: 'Channels you watched last',
  mine: 'Channels from your main playlist', sources: 'Your playlists and the free TV cards', favvod: 'Films and series you hearted',
  movies: 'Newest films', series: 'Newest series',
};
const LANGS = [['', 'Automatic'], ['en', 'English'], ['es', 'Spanish'], ['fr', 'French'], ['de', 'German'], ['it', 'Italian'], ['pt', 'Portuguese'], ['nl', 'Dutch'], ['ar', 'Arabic'], ['tr', 'Turkish'], ['pl', 'Polish'], ['hi', 'Hindi']];

export function settingsView(params = {}) {
  const el = h('div.view');
  el.append(topbar('Settings', 'Make Lumen yours'));
  const SECTIONS = [
    ['playlists', 'Playlists', 'server'], ['homescreen', 'Home screen', 'home'], ['countries', 'Countries & languages', 'globe'], ['phone', 'Phone & laptop', 'link'], ['guide', 'TV guide', 'guide'], ['playback', 'Playback', 'play'],
    ['appearance', 'Appearance', 'palette'], ['parental', 'Parental controls', 'shield'], ['groups', 'Groups', 'list'],
    ['backup', 'Backup', 'download'], ['updates', 'About & updates', 'refresh'], ['help', 'Remote & keys', 'info'],
  ];
  let cur = params.section || 'playlists';
  const navEl = h('nav.set-nav.glass', { 'data-remember': '' });
  const content = h('div', { style: { minWidth: 0 } });
  el.append(h('div.settings', navEl, content));

  function paintNav() {
    clear(navEl);
    for (const [k, l, ic] of SECTIONS) {
      navEl.append(h('button.group-btn' + (k === cur ? '.on' : ''), { 'data-autofocus': k === cur ? '' : null, onclick: () => { cur = k; paintNav(); paint(); } }, icon(ic), h('span.gname', l)));
    }
  }

  const row = (t, d, val, onclick, extra = {}) => h('button.set-row.f', { onclick, ...extra },
    h('div.txt', h('div.t', t), d ? h('div.d', d) : null), val instanceof Node ? val : val != null ? h('span.val', val, icon('right')) : null);
  const toggle = (t, d, key, after) => row(t, d, toggleEl(S.settings[key]), (e) => {
    setSetting(key, !S.settings[key]);
    e.currentTarget.querySelector('.toggle').classList.toggle('on', S.settings[key]);
    after && after();
  });
  const choose = (t, d, key, options, after) => {
    const label = () => (options.find((o) => o[0] === S.settings[key]) || options[0])[1];
    const r = row(t, d, label(), () => menu(r, t, options.map(([v, l]) => ({ label: l, on: S.settings[key] === v, run: () => { setSetting(key, v); r.querySelector('.val').firstChild.textContent = label(); after && after(); } }))));
    return r;
  };
  const card = (...rows) => h('div.set-card.glass', rows.filter(Boolean));
  const head = (title, lead) => [h('h2', title), lead ? h('p.lead', lead) : null].filter(Boolean);

  function paint() {
    clear(content);
    const sec = h('section.set-section');
    content.append(sec);
    ({ playlists, homescreen, updates, countries, phone, guide, playback, appearance, parental, groups, backup, help })[cur](sec);
  }

  function playlists(sec) {
    sec.append(...head('Playlists', 'Your main playlist is the first card on Home. Free sources fill in the rest, and a channel carried by several sources only appears once.'));
    const main = mainPlaylist();
    const rows = S.playlists.filter((p) => !p.builtin).map((pl) => {
      const c = pl.counts || { live: 0, movie: 0, series: 0 };
      const kind = { 'm3u-url': 'M3U link', 'm3u-file': 'M3U file', xtream: 'Xtream Codes', demo: 'Sample' }[pl.kind];
      const exp = pl.info && pl.info.expires ? ` · Expires ${new Date(pl.info.expires).toLocaleDateString()}` : '';
      const r = h('button.set-row.f', {
        onclick: () => menu(r, pl.name, [
          pl === main ? null : { label: 'Make this my main playlist', run: () => { setMain(pl.id); toast(`${pl.name} is now your main playlist`); paint(); } },
          { label: 'Refresh now', run: () => doRefresh(pl) },
          { label: 'Rename', run: () => rename(pl) },
          { label: 'Remove', run: async () => { if (await confirmBox(`Remove ${pl.name}?`, 'Its channels, movies and series leave your library. Favourites stay saved in case you add it again.', 'Remove', true)) { await removePlaylist(pl.id); toast('Playlist removed'); paint(); } } },
        ].filter(Boolean)),
      },
      appIcon('main'),
      h('div.txt', h('div.t', pl.name, pl === main ? h('span.badge', { style: { marginLeft: '.6rem' } }, 'Main') : null), h('div.d', `${kind} · ${describeCounts(c)}${exp}`), h('div.d', `Updated ${fmtDay(pl.updated)} ${fmtClock(pl.updated)}`)),
      h('span.val', icon('dots')));
      return r;
    });
    sec.append(h('div.eyebrow', 'Your playlists'));
    sec.append(card(...rows, row(main ? 'Add another playlist' : 'Add your main playlist', 'M3U file, M3U link or Xtream Codes login', null, () => openAddPlaylist(() => paint(), { main: !main }))));
    sec.append(card(toggle('Refresh my playlists on start', 'Download linked playlists again every time Lumen opens.', 'refreshOnStart')));
    freeSources(sec);
    async function doRefresh(pl) {
      const t = toast('Refreshing ' + pl.name + '…', { ms: 60000 });
      try { await refreshPlaylist(pl.id); t.remove(); toast(pl.name + ' is up to date'); paint(); } catch (e) { t.remove(); toast(e.message); }
    }
    function rename(pl) {
      const input = h('input.input#rename', { value: pl.name });
      let L;
      const save = () => { renamePlaylist(pl.id, input.value.trim() || pl.name); L.close(); paint(); };
      input.addEventListener('commit', save);
      L = openLayer(h('div.modal.glass-strong', h('h2', 'Rename playlist'), h('div.field', { style: { marginTop: '1.2rem' } }, input),
        h('div.actions', h('button.btn', { onclick: () => L.close() }, 'Cancel'), h('button.btn.btn-accent', { onclick: save }, 'Save'))));
    }
  }

  // Built-in free sources: on/off, show on Home, and a quick check of whether streams answer here.
  function freeSources(sec) {
    sec.append(h('div.eyebrow', { style: { marginTop: '1.2rem' } }, 'Free TV sources'));
    sec.append(h('p.lead', { style: { margin: 0 } }, 'Some free channels only play in certain countries. Run a check, then turn off or hide the sources that don\'t work where you are.'));
    const status = (pl) => {
      if (pl.enabled === false) return 'Off';
      if (S.syncing.has(pl.id)) return 'Downloading…';
      const n = S.srcCount.get(pl.id) || 0;
      const parts = [];
      if (pl.error && !n) parts.push(`Couldn't load: ${pl.error}`);
      else if (!pl.updated) parts.push('Not downloaded yet');
      else parts.push(`${n.toLocaleString()} channels · updated ${fmtDay(pl.updated)} ${fmtClock(pl.updated)}`);
      const pr = pl.probe;
      if (pr && pr.n) parts.push(pr.unknown === pr.n ? 'Check needs the Lumen server running' : `${pr.ok} of ${pr.n} test streams answered${pr.ok ? '' : ': probably blocked here'}`);
      return parts.join(' · ');
    };
    const rowsEl = h('div.set-card.glass');
    const paintRows = () => {
      clear(rowsEl);
      for (const pl of builtinSources()) {
        const prov = providerOf(pl);
        const on = pl.enabled !== false;
        const d = h('div.d', status(pl));
        const check = h('button.btn.btn-sm', { disabled: !on || !S.srcCount.get(pl.id), onclick: async () => { check.disabled = true; d.textContent = 'Checking…'; await probeSource(pl.id); paintRows(); } }, 'Check');
        const home = h('button.btn.btn-sm', { disabled: !on, 'aria-label': pl.hideHome ? 'Show on Home' : 'Hide from Home', onclick: () => { setSource(pl.id, { hideHome: !pl.hideHome }); paintRows(); } }, icon(pl.hideHome ? 'plus' : 'check'), pl.hideHome ? 'Hidden from Home' : 'On Home');
        const power = h('button.switch-btn', { 'aria-label': on ? `Turn ${pl.name} off` : `Turn ${pl.name} on`, 'aria-pressed': String(on), onclick: async () => { power.disabled = true; await setSource(pl.id, { enabled: !on }); paintRows(); } }, toggleEl(on));
        rowsEl.append(h('div.set-row', appIcon(prov.icon), h('div.txt', h('div.t', pl.name, h('span.faint', { style: { fontWeight: 500, marginLeft: '.5rem' } }, prov.org === 'iptv-org' ? 'iptv-org' : '')), d), h('div.row', { style: { gap: '.5rem', flexWrap: 'nowrap' } }, check, home, power)));
      }
    };
    paintRows();
    sec.append(rowsEl);
    sec.append(card(
      row('Check every source', 'Tests a few streams from each source that is on.', null, async (e) => {
        const d = e.currentTarget.querySelector('.d');
        const list = builtinSources().filter((p) => p.enabled !== false && S.srcCount.get(p.id));
        let i = 0;
        for (const pl of list) { d.textContent = `Checking ${++i} of ${list.length}…`; await probeSource(pl.id); paintRows(); }
        d.textContent = 'Done. Sources marked “probably blocked here” can be turned off.';
      }),
      row('Download free sources again', 'Fetch the latest channel lists now.', null, async (e) => {
        const d = e.currentTarget.querySelector('.d');
        d.textContent = 'Downloading…';
        const n = await syncBuiltins({ force: true });
        d.textContent = `Updated ${n} source${n === 1 ? '' : 's'}`;
        paintRows();
      }),
      choose('Free TV on Home', 'Automatic shows every source until you add a playlist of your own, then folds them into one card.', 'freeOnHome',
        [['auto', 'Automatic'], ['expanded', 'Show every source'], ['collapsed', 'Collapse into one card'], ['hidden', 'Hide']]),
      toggle('Hide geo-blocked channels', 'Leaves out channels that iptv-org marks as only playing in certain countries.', 'hideGeo', () => loadLibrary()),
    ));
    const off = bus.on('sources', () => { if (rowsEl.isConnected && !rowsEl.contains(document.activeElement)) paintRows(); });
    rowsEl.addEventListener('focusout', () => setTimeout(() => { if (!rowsEl.isConnected) off(); }, 0));
  }

  function updates(sec) {
    sec.append(...head('About & updates', 'Lumen keeps itself up to date. Updates to its screens download by themselves and are used the next time it opens; app updates need one tap on Install.'));
    if (!updatesAvailable()) {
      sec.append(card(row('Version', 'This is the web version of Lumen. It updates when the files on its server are updated.', null, null)));
      return;
    }
    const box = h('div');
    sec.append(box);
    const paintU = (st) => {
      if (!box.isConnected) { off(); return; }
      st = st || updateStatus() || {};
      const busy = { checking: 'Checking…', 'downloading-web': `Downloading the screen update… ${st.progress >= 0 ? st.progress + '%' : ''}`, 'downloading-app': `Downloading Lumen ${st.app ? st.app.version : ''}… ${st.progress >= 0 ? st.progress + '%' : ''}`, installing: 'Opening the installer…', 'needs-permission': 'Allow Lumen to install apps in the screen that opened, then tap Update again.' }[st.state];
      const had = box.contains(document.activeElement) ? document.activeElement.dataset.k : null;
      clear(box).append(
        card(
          row('Lumen app', st.app ? `Version ${st.appVersion} · Lumen ${st.app.version} is available${st.app.notes ? ': ' + st.app.notes : ''}` : `Version ${st.appVersion} · up to date`, st.app ? 'Update' : null, st.app ? () => installAppUpdate() : null, { dataset: { k: 'app' } }),
          row('Screens', st.webReady ? `Update ${st.webReady} downloaded · used the next time Lumen opens` : `Version ${st.webVersion}${st.webNotes && st.webLatest === st.webVersion ? ' · ' + st.webNotes : ''}`, st.webReady ? 'Restart now' : null, st.webReady ? () => restartForUpdate() : null, { dataset: { k: 'web' } }),
          row('Check for updates', busy || st.error || (st.checkedAt ? `Last checked ${fmtClock(st.checkedAt)}` : 'Lumen checks when it opens and every 12 hours'), null, () => checkForUpdates(), { dataset: { k: 'check' } }),
        ),
        h('p.lead', { style: { marginTop: '1rem' } }, 'Updates come from github.com/JoethePT/lumen-updates and are only accepted if they’re signed with Lumen’s update key. Your playlists and settings stay as they are.'),
      );
      if (had) { const b = box.querySelector(`[data-k="${had}"]`); if (b) nav.focus(b); }
    };
    const off = onUpdate(paintU);
    paintU();
  }

  function homescreen(sec) {
    sec.append(...head('Home screen', 'Choose which rows appear on Home and in what order. On Home you can also hold OK on any tile to move or hide its row.'));
    const list = h('div');
    sec.append(list);
    // One reorderable list: up/down buttons plus Shown/Hidden. Focus stays on the button you pressed.
    const orderCard = (keys, name, info, icon_, isHidden, move, setHidden, focusKey, focusWhat) => card(...keys.map((k, i) => {
      const hidden = isHidden(k);
      const up = h('button.btn.btn-sm.btn-icon', { 'aria-label': 'Move up', disabled: i === 0, dataset: { k, w: 'up' }, onclick: () => { move(k, -1); paintH(k, i - 1 === 0 ? 'down' : 'up'); } }, icon('chUp'));
      const down = h('button.btn.btn-sm.btn-icon', { 'aria-label': 'Move down', disabled: i === keys.length - 1, dataset: { k, w: 'down' }, onclick: () => { move(k, 1); paintH(k, i + 1 === keys.length - 1 ? 'up' : 'down'); } }, icon('chDown'));
      const vis = h('button.btn.btn-sm' + (hidden ? '' : '.on'), { dataset: { k, w: 'vis' }, onclick: () => { setHidden(k, !hidden); paintH(k, 'vis'); } }, hidden ? 'Hidden' : 'Shown');
      return h('div.set-row' + (hidden ? '.is-off' : ''), icon_ ? icon_(k) : null, h('div.txt', h('div.t', name(k)), h('div.d', info(k))), h('div.row', up, down, vis));
    }));
    const paintH = (focusKey, focusWhat) => {
      const names = homeRowNames();
      const order = homeOrder(Object.keys(names));
      const svcs = serviceList({ all: true });
      clear(list).append(
        orderCard(order, (k) => names[k], (k) => ROW_INFO[k] || '', null, (k) => S.settings.homeHidden.includes(k), (k, d) => moveHomeRow(k, d, order), setHomeRowHidden),
        svcs.length ? h('h3.set-sub', 'Streaming services') : null,
        svcs.length ? orderCard(svcs.map((x) => x.key), (k) => svcs.find((x) => x.key === k).name, (k) => svcs.find((x) => x.key === k).cats.map((c) => c.name).join(' · '), (k) => serviceIcon(svcs.find((x) => x.key === k)), (k) => (S.settings.svcHidden || []).includes(k), moveService, setServiceHidden) : null,
        card(row('Reset Home to the standard layout', 'Every row and service shown, in the original order', null, () => { for (const k of ['homeOrder', 'homeHidden', 'svcOrder', 'svcHidden']) setSetting(k, []); paintH(); toast('Home reset'); })),
      );
      if (focusKey) { const b = list.querySelector(`[data-k="${focusKey}"][data-w="${focusWhat}"]`); if (b) nav.focus(b); }
    };
    paintH();
  }

  function countries(sec) {
    sec.append(...head('Countries', 'Big playlists carry channels from dozens of countries. Choose the ones you watch and Lumen hides the rest from Live TV, the guide, Home and search.'));
    const n = S.settings.countries.length;
    sec.append(card(
      row('Choose countries', n ? countrySummary() : 'Showing every country', null, () => openCountryPicker(() => paint())),
      n ? row('Show all countries again', 'Clears your choice', null, () => { setSetting('countries', []); bus.emit('library'); guideForCountries(); toast('Showing all countries'); paint(); }) : null,
      toggle('Suggest this on Home', 'Show a reminder on Home when a playlist covers many countries.', 'countryHint'),
    ));
    sec.append(h('h3.set-sub', 'Film & series languages'), card(
      row('Choose languages', langSummary(), null, () => openLangPicker(() => paint())),
      S.settings.vodLangs.length ? row('Follow my countries again', 'Use the languages of the countries you chose', null, () => { setSetting('vodLangs', []); bus.emit('library'); toast('Languages follow your countries'); paint(); }) : null,
    ));
    sec.append(h('h3.set-sub', 'Channel quality'), card(
      choose('Show each channel in', 'Providers often list a channel several times (SD, HD, Full HD, 4K, HEVC). Pick one and Lumen shows a single version of each channel, the nearest quality when yours isn’t offered.', 'quality', QUALITIES, () => bus.emit('library')),
    ));
  }

  function phone(sec) {
    sec.append(...head('Phone & laptop', 'Add playlists, Xtream logins and guide links from your phone or laptop instead of typing long links with the remote. Both devices need to be on the same Wi-Fi.'));
    const panel = pairPanel({ large: true, title: 'Scan with your phone camera' });
    if (!panel) {
      sec.append(card(row('Not available here', 'Start Lumen with node server.js, or use the Android TV app, to pair a phone.', null, () => {})));
      return;
    }
    sec.append(h('div.set-card.glass', { style: { padding: '1.6rem' } }, panel));
    sec.append(card(row('Make a new PIN', 'Phones paired with the old PIN have to scan again.', null, async () => {
      if (!(await confirmBox('Make a new PIN?', 'Phones and laptops using the current PIN will need to scan the new code.', 'New PIN'))) return;
      await newPin(); toast('New PIN ready'); paint();
    })));
  }

  function guide(sec) {
    sec.append(...head('TV guide', 'Lumen reads XMLTV guides, including compressed .xml.gz files, and matches them to your channels automatically.'));
    const status = S.epg.loading ? 'Downloading…' : S.epg.updated ? `${S.epg.count.toLocaleString()} channels matched · updated ${fmtDay(S.epg.updated)} ${fmtClock(S.epg.updated)}` : 'No guide loaded';
    const auto = [...new Set(S.playlists.flatMap((p) => p.epg || []))];
    sec.append(card(
      row('Refresh guide now', status, null, async (e) => {
        const d = e.currentTarget.querySelector('.d');
        d.textContent = 'Downloading…';
        try { await refreshGuide(); d.textContent = `${S.epg.count.toLocaleString()} channels matched`; toast('Guide updated'); } catch (err) { d.textContent = err.message; }
      }),
      toggle('Use guides from playlists', auto.length ? auto.join(', ') : 'Your playlists do not name a guide.', 'epgAuto'),
      choose('Time offset', 'Shift every programme if the guide runs early or late.', 'epgShift', Array.from({ length: 25 }, (_, i) => [i - 12, i === 12 ? 'None' : `${i - 12 > 0 ? '+' : ''}${i - 12} h`])),
    ));
    const extra = S.settings.epgUrls.map((u) => row(u, 'Extra guide', null, async () => {
      if (await confirmBox('Remove this guide?', u, 'Remove', true)) { setSetting('epgUrls', S.settings.epgUrls.filter((x) => x !== u)); paint(); }
    }));
    sec.append(card(...extra,
      row('Add a guide link', 'An XMLTV address ending in .xml or .xml.gz', null, () => {
        const input = h('input.input#epg-url', { placeholder: 'https://provider.example/guide.xml.gz', inputmode: 'url' });
        let L;
        const save = () => {
          const v = input.value.trim();
          if (!/^https?:\/\//i.test(v)) { toast('Enter a link that starts with http:// or https://'); return; }
          setSetting('epgUrls', [...S.settings.epgUrls, v]); L.close(); paint();
          refreshGuide().then(() => toast('Guide updated')).catch((e) => toast(e.message));
        };
        input.addEventListener('commit', save);
        L = openLayer(h('div.modal.glass-strong', h('h2', 'Add a guide link'), h('div.field', { style: { marginTop: '1.2rem' } }, input),
          h('div.actions', h('button.btn', { onclick: () => L.close() }, 'Cancel'), h('button.btn.btn-accent', { onclick: save }, 'Add guide'))));
      }),
      row('Load a guide file', 'Pick an XMLTV file from this device', null, () => {
        const inp = h('input', { type: 'file', accept: '.xml,.gz,text/xml,application/xml' });
        inp.onchange = async () => {
          const t = toast('Reading guide…', { ms: 60000 });
          try { const n = await loadEpgFile(inp.files[0]); t.remove(); toast(`Loaded ${n.toLocaleString()} programmes`); paint(); } catch (e) { t.remove(); toast(e.message); }
        };
        inp.click();
      }),
    ));
  }

  function playback(sec) {
    sec.append(...head('Playback', 'Tune how streams start, buffer and recover.'));
    sec.append(card(
      choose('Stream relay', net.relay ? 'The Lumen server is running, so it can fetch streams your browser is blocked from.' : 'Start Lumen with node server.js to enable the relay.', 'relay', [['auto', 'Automatic'], ['always', 'Always'], ['never', 'Never']], () => { net.mode = S.settings.relay; }),
      choose('Player engine', 'Automatic picks the best decoder for each stream and falls back if one fails.', 'engine', [['auto', 'Automatic'], ['hls', 'HLS (hls.js)'], ['mpegts', 'MPEG-TS (mpegts.js)'], ['native', 'Native']]),
      toggle('Low latency', 'Stay closer to live. Uses a smaller buffer, so weak connections may stutter.', 'lowLatency'),
      toggle('Reconnect automatically', 'Retry a live channel when the stream drops or stalls.', 'reconnect'),
      toggle('Switch to a backup stream', 'When a channel stops working, play another copy of it from your provider (a backup or another quality) instead.', 'autoBackup'),
      choose('Xtream live format', 'The format requested from Xtream servers after the next refresh.', 'xcLiveFormat', [['m3u8', 'HLS (.m3u8)'], ['ts', 'MPEG-TS (.ts)']]),
    ));
    sec.append(card(
      toggle('Preview in Live TV', 'Play the selected channel in the preview window before going full screen.', 'previewPlay'),
      toggle('Resume where you left off', 'Movies and episodes continue from the last position.', 'resume'),
      toggle('Play next episode', 'Start the next episode automatically, with a countdown you can cancel.', 'autoNext'),
      choose('Default picture', null, 'aspect', [['fit', 'Fit'], ['fill', 'Fill screen'], ['zoom', 'Zoom'], ['stretch', 'Stretch'], ['16:9', '16:9'], ['4:3', '4:3']]),
    ));
    sec.append(card(
      choose('Audio language', 'Used when a stream offers several audio tracks.', 'audioLang', LANGS),
      choose('Subtitle language', 'Turns subtitles on when a matching track exists.', 'subLang', [['', 'Off'], ...LANGS.slice(1)]),
      choose('Subtitle size', null, 'subSize', [[80, 'Small'], [100, 'Medium'], [125, 'Large'], [150, 'Extra large']], () => import('./player-ui.js').then((p) => p.applySubStyle())),
      toggle('Subtitle background', 'A dark band behind subtitle text for readability.', 'subBg', () => import('./player-ui.js').then((p) => p.applySubStyle())),
    ));
  }

  function appearance(sec) {
    sec.append(...head('Appearance'));
    const sw = h('div.swatches', ACCENTS.map(([c, n]) => h('button.swatch' + (S.settings.accent === c ? '.on' : ''), {
      'aria-label': n, style: { background: c },
      onclick: (e) => { setSetting('accent', c); applyTheme(); Array.from(sw.children).forEach((x) => x.classList.toggle('on', x === e.currentTarget)); },
    })));
    sec.append(card(
      choose('Text & tile size', 'Bigger text, posters and buttons for reading from across the room. Automatic is Large on a TV.', 'uiScale', UI_SCALES, () => { applyTheme(); paint(); }),
      choose('Theme', null, 'theme', [['dark', 'Dark'], ['light', 'Light'], ['auto', 'Match system']], applyTheme),
      h('div.set-row', h('div.txt', h('div.t', 'Accent colour'), h('div.d', 'Used for highlights and progress.')), sw),
      toggle('Glass effects', 'Blur and translucency. Turn off on slower TV boxes for smoother scrolling.', 'glass', applyTheme),
      toggle('Motion', 'Animated transitions and focus effects.', 'motion', applyTheme),
      toggle('24-hour clock', null, 'clock24', applyTheme),
      toggle('Show channel numbers', null, 'showNumbers'),
    ));
  }

  function parental(sec) {
    sec.append(...head('Parental controls', 'Lock groups behind a 4-digit PIN. Adult groups are detected by name and locked automatically once a PIN is set.'));
    const has = !!S.settings.pin;
    sec.append(card(
      row(has ? 'Change PIN' : 'Set a PIN', has ? 'PIN is on' : 'No PIN set', null, async () => {
        if (has && !(await askPin('Current PIN'))) return;
        const a = await askPin('New PIN', { set: true, lead: 'Choose 4 digits.' });
        if (!a) return;
        const b = await askPin('Confirm PIN', { set: true, lead: 'Enter the same 4 digits again.' });
        if (a !== b) { toast("The PINs didn't match. Try again."); return; }
        setSetting('pin', a); S.unlocked = false; toast('PIN saved'); paint();
      }),
      has ? row('Turn off PIN', 'Unlocks every group', null, async () => { if (await askPin('Current PIN')) { setSetting('pin', ''); toast('PIN removed'); paint(); } }) : null,
      toggle('Hide adult groups', 'Remove them from browsing and search until unlocked.', 'hideAdult', () => bus.emit('library')),
      has ? row('Lock again now', S.unlocked ? 'Locked groups are open for this session' : 'Locked groups are closed', null, () => { S.unlocked = false; toast('Locked'); bus.emit('library'); paint(); }) : null,
    ));
    sec.append(h('p.lead', { style: { marginTop: '.8rem' } }, 'Choose which groups need the PIN in Groups.'));
  }

  function groups(sec) {
    sec.append(...head('Groups', 'Hide groups you never watch, or lock them with your PIN.'));
    let tab = 'live';
    const tabs = h('div.tabs', { style: { maxWidth: '28rem' } });
    const list = h('div');
    sec.append(tabs, list);
    const paintG = async () => {
      if (S.settings.pin && !S.unlocked) {
        clear(list).append(card(row('Unlock to edit groups', 'Enter your PIN to see and change every group.', null, async () => { if (await askPin()) { S.unlocked = true; paintG(); } })));
        return;
      }
      clear(tabs);
      for (const [k, l] of [['live', 'Live TV'], ['movie', 'Movies'], ['series', 'Series']]) tabs.append(h('button.tab' + (tab === k ? '.on' : ''), { onclick: () => { tab = k; paintG(); } }, l));
      clear(list);
      const gs = S.groups[tab];
      if (!gs.length) { list.append(h('p.lead', 'No groups here yet.')); return; }
      list.append(card(...gs.map((g) => {
        const key = groupKey(tab, g.name);
        const hidden = S.settings.hiddenGroups.includes(key);
        const locked = S.settings.lockedGroups.includes(key);
        const vis = h('button.btn.btn-sm' + (hidden ? '' : '.on'), { onclick: () => { const s = new Set(S.settings.hiddenGroups); s.has(key) ? s.delete(key) : s.add(key); setSetting('hiddenGroups', [...s]); bus.emit('library'); paintG(); } }, hidden ? 'Hidden' : 'Shown');
        const lock = h('button.btn.btn-sm.btn-icon' + (locked ? '.on' : ''), { 'aria-label': 'Lock', disabled: !S.settings.pin, onclick: () => { const s = new Set(S.settings.lockedGroups); s.has(key) ? s.delete(key) : s.add(key); setSetting('lockedGroups', [...s]); paintG(); } }, icon(locked ? 'lock' : 'unlock'));
        return h('div.set-row', h('div.txt', h('div.t', g.name), h('div.d', g.count != null ? `${g.count.toLocaleString()} ${tab === 'live' ? 'channels' : tab === 'movie' ? 'movies' : 'series'}` : 'Loads when opened')), h('div.row', vis, lock));
      })));
    };
    paintG();
  }

  function backup(sec) {
    sec.append(...head('Backup', 'Save your settings, playlists, favourites and history to a file, and restore them on another TV.'));
    sec.append(card(
      row('Save a backup file', 'Playlists added from a file are not included; add those again after restoring.', null, () => {
        const blob = new Blob([exportBackup()], { type: 'application/json' });
        const a = h('a', { href: URL.createObjectURL(blob), download: `lumen-backup-${new Date().toISOString().slice(0, 10)}.json` });
        document.body.append(a); a.click(); a.remove();
        toast('Backup saved');
      }),
      row('Restore from a file', 'Merges playlists and replaces settings, favourites and history.', null, () => {
        const inp = h('input', { type: 'file', accept: '.json,application/json' });
        inp.onchange = async () => {
          const t = toast('Restoring…', { ms: 120000 });
          try { await importBackup(await inp.files[0].text()); t.remove(); toast('Backup restored'); applyTheme(); paint(); } catch (e) { t.remove(); toast(e.message); }
        };
        inp.click();
      }),
    ));
    sec.append(card(
      row('Clear watch history', 'Removes Continue watching and Recently watched.', null, async () => {
        if (await confirmBox('Clear watch history?', 'Resume positions are removed too.', 'Clear', true)) {
          S.history = []; localStorage.removeItem('lumen.history'); bus.emit('history'); toast('History cleared');
        }
      }),
      row('Reset Lumen', 'Removes every playlist, setting and favourite from this device.', null, async () => {
        if (await confirmBox('Reset Lumen?', 'This removes everything stored on this device and cannot be undone.', 'Reset', true)) {
          for (const p of S.playlists.slice()) await removePlaylist(p.id);
          Object.keys(localStorage).filter((k) => k.startsWith('lumen.')).forEach((k) => localStorage.removeItem(k));
          try { indexedDB.deleteDatabase('lumen'); } catch {}
          location.reload();
        }
      }),
    ));
  }

  function help(sec) {
    sec.append(...head('Remote & keys', 'Lumen works with a TV remote, a keyboard, a mouse or touch.'));
    const k = (keys, what) => [h('div.row', { style: { gap: '.4rem' } }, keys.map((x) => h('span.kbd', x))), h('div.muted', what)];
    sec.append(h('div.set-card.glass.shortcuts',
      k(['↑', '↓', '←', '→'], 'Move around. In full screen, ↑ ↓ change channel and ← → skip 10 seconds.'),
      k(['OK'], 'Select. In full screen, show the controls.'),
      k(['Back', 'Esc'], 'Go back, hide the controls, or leave full screen.'),
      k(['0–9'], 'Type a channel number while watching.'),
      k(['CH+', 'CH−'], 'Change channel (Page Up / Page Down on a keyboard).'),
      k(['Green', 'Guide'], 'Open the channel list while watching.'),
      k(['Yellow'], 'Jump back to the last channel.'),
      k(['Blue', 'Info'], 'Show stream information.'),
      k(['Space'], 'Play or pause.'),
      k(['M'], 'Mute.'),
      k(['F'], 'Full screen in a desktop browser.'),
    ));
    sec.append(h('p.lead', { style: { marginTop: '1rem' } }, `Relay: ${net.relay ? 'available' : 'not running'} · Lumen 1.0`));
  }

  paintNav();
  paint();
  const off = bus.on('epg', () => { if (cur === 'guide' && el.isConnected && !content.contains(document.activeElement)) paint(); });
  return { el, destroy: off, onShow() { nav.focusFirst(navEl); } };
}

export { saveSettings };
