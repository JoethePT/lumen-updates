// "Choose your countries": a grid of the countries found in your channels. Everything else is
// hidden from Live TV, the guide, Home and search until you change it.
import { h, clear, toast } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import { S, bus, setSetting, countryCounts, guideForCountries } from '../store.js';
import { countryName, countryFlag, BUCKETS } from '../countries.js';
import { openLayer } from './common.js';

export function countrySummary() {
  const pick = S.settings.countries;
  if (!pick.length) return 'All countries';
  const names = pick.map(countryName);
  return names.length > 3 ? `${names.slice(0, 3).join(', ')} and ${names.length - 3} more` : names.join(', ');
}

export function openCountryPicker(onDone) {
  const counts = countryCounts();
  const total = counts.reduce((a, c) => a + c.n, 0);
  const chosen = S.settings.countries.filter((cc) => counts.some((c) => c.cc === cc));
  const summary = h('p.cp-summary');
  const tiles = new Map();

  function paint() {
    for (const [cc, el] of tiles) el.classList.toggle('on', chosen.includes(cc));
    const n = chosen.length ? counts.filter((c) => chosen.includes(c.cc)).reduce((a, c) => a + c.n, 0) : total;
    summary.textContent = chosen.length
      ? `Showing ${n.toLocaleString()} of ${total.toLocaleString()} channels from ${chosen.map(countryName).join(', ')}.`
      : `Showing all ${total.toLocaleString()} channels. Pick countries to hide the rest.`;
  }

  const tile = ({ cc, n }) => {
    const el = h('button.cp-tile', {
      'aria-pressed': 'false',
      onclick: () => {
        const i = chosen.indexOf(cc);
        if (i >= 0) chosen.splice(i, 1); else chosen.push(cc);
        el.setAttribute('aria-pressed', String(chosen.includes(cc)));
        paint();
      },
    }, h('span.cp-flag', countryFlag(cc)), h('span.cp-txt', h('span.cp-name', countryName(cc)), h('span.cp-n', `${n.toLocaleString()} channel${n === 1 ? '' : 's'}`)), h('span.cp-check', icon('check')));
    tiles.set(cc, el);
    return el;
  };

  const countries = counts.filter((c) => !BUCKETS.includes(c.cc));
  const extras = counts.filter((c) => BUCKETS.includes(c.cc));
  let L;
  const box = h('div.modal.glass-strong.cp',
    h('div.cp-head',
      h('div', h('h2', 'Choose your countries'), h('p.lead', 'Pick the countries you watch. Other channels are hidden from Live TV, the guide, Home and search. Your countries’ categories come first, main channels before sport and events.')),
    ),
    summary,
    h('div.cp-scroll',
      h('div.eyebrow', 'Countries'),
      h('div.cp-grid', countries.map(tile)),
      extras.length ? [h('div.eyebrow', { style: { marginTop: '1.4rem' } }, 'Also include'), h('div.cp-grid', extras.map(tile))] : null,
    ),
    h('div.actions',
      h('button.btn', { onclick: () => { chosen.length = 0; paint(); } }, icon('globe'), 'Show all countries'),
      h('button.btn.btn-accent', { onclick: () => done() }, 'Done'),
    ),
  );
  function done() {
    const before = S.settings.countries.join();
    setSetting('countries', chosen.slice());
    guideForCountries();
    L.close();
    if (before !== chosen.join()) {
      toast(chosen.length ? `Showing ${countrySummary()}` : 'Showing all countries');
      bus.emit('library');
    }
    onDone && onDone();
  }
  L = openLayer(box);
  paint();
  // Start on the first chosen country, or the biggest one.
  requestAnimationFrame(() => nav.focus(tiles.get(chosen[0]) || box.querySelector('.cp-tile')));
}
