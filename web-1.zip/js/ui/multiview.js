// Multiview: up to four live channels at once. Sound follows the focused tile.
import { h, toast } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import { Engine } from '../player.js';
import { S, visible } from '../store.js';
import { openLayer, channelRow } from './common.js';
import { VList } from '../vlist.js';
import * as player from './player-ui.js';

export function openMultiview(first) {
  // Each tile is its own stream; a one-stream subscription can only fill one of them.
  const pl = first && S.playlists.find((p) => p.id === first.pl);
  const max = pl && pl.info && pl.info.maxConn;
  if (max && max < 2) toast(`${pl.name} allows one stream at a time, so only one Multiview tile can play.`, { ms: 7000 });
  const tiles = [];
  const root = h('div.mv', { 'data-n': 1 });
  const help = h('div.mv-help', h('span', 'OK · full screen'), h('span', 'Focus a tile to hear it'), h('span', 'Back · close'));
  document.body.append(root, help);

  function layout() {
    root.dataset.n = Math.min(4, Math.max(1, tiles.length + (tiles.length < 4 ? 1 : 0)));
  }

  function addTile(ch) {
    const v = h('video', { playsinline: true, muted: true });
    v.muted = true;
    const eng = new Engine(v, { lowLatency: S.settings.lowLatency, prefer: S.settings.engine });
    const lbl = h('div.lbl', icon('mute'), ch.name);
    const tile = h('div.mv-tile.f', { tabindex: '0' }, v, lbl);
    const t = { ch, v, eng, tile, lbl };
    tile.addEventListener('focus', () => setAudio(t));
    tile.addEventListener('click', () => { const c = t.ch; closeAll(); player.open(c, { list: visible('live', S.live) }); });
    eng.load({ url: ch.url, ua: ch.ua, ref: ch.ref, live: true });
    eng.on('fatal', (m) => toast(`${ch.name}: ${m}`));
    tiles.push(t);
    root.insertBefore(tile, addEl);
    if (tiles.length >= 4) addEl.hidden = true;
    layout();
    return t;
  }

  function setAudio(t) {
    for (const x of tiles) {
      const on = x === t;
      x.v.muted = !on;
      x.tile.classList.toggle('audio', on);
      x.lbl.firstChild.replaceWith(icon(on ? 'audio' : 'mute'));
    }
  }

  const addEl = h('div.mv-tile.f', { tabindex: '0', onclick: () => pick() },
    h('div.empty', h('div', icon('plus'), h('div', { style: { fontWeight: 700, fontSize: '1.1rem' } }, 'Add a channel'), h('div', { style: { fontSize: '.9rem' } }, 'Up to four at once'))));
  root.append(addEl);

  function pick() {
    const list = visible('live', S.live);
    let L;
    const vl = new VList({
      count: list.length,
      rowHeight: () => Math.round(parseFloat(getComputedStyle(document.documentElement).fontSize) * 4.4),
      render: (i) => channelRow(list[i], { compact: true, onclick: () => { L.close(); const t = addTile(list[i]); nav.focus(t.tile); } }),
    });
    const box = h('div.modal.glass-strong', { style: { height: 'min(44rem, calc(100% - 4rem))', display: 'flex', flexDirection: 'column' } },
      h('h2', 'Add to multiview'), h('p.lead', 'Pick a channel to add.'), h('div', { style: { flex: 1, minHeight: 0 } }, vl.el));
    L = openLayer(box, { onClose: () => vl.destroy() });
    requestAnimationFrame(() => { vl.layout(); nav.focusFirst(vl.el); });
  }

  function closeAll() {
    for (const t of tiles) t.eng.stop();
    root.remove(); help.remove();
    nav.pop(root, true);
  }

  nav.push(root, closeAll);
  if (first) addTile(first);
  layout();
  requestAnimationFrame(() => nav.focus(tiles[0] ? tiles[0].tile : addEl));
}
