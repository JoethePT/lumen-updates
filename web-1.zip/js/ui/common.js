// Shared UI pieces: tiles, layers, menus, PIN entry, ambient backdrop.
import { h, hue, logoTile, posterTile, fmtClock, $, toast } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import { S, nowNext, isFav, progressOf, isLocked, toggleFav, inMyList, toggleMyList, catLabel } from '../store.js';
import { appIcon } from '../providers.js';

// ---------- ambient ----------
let ambTimer;
export function setAmbient(seed, img) {
  clearTimeout(ambTimer);
  ambTimer = setTimeout(() => {
    const amb = document.getElementById('ambient');
    // Set on the backdrop only: changing a variable on the page root re-styles every element.
    if (seed) {
      const h1 = hue(seed);
      amb.style.setProperty('--amb-1', h1);
      amb.style.setProperty('--amb-2', (h1 + 70) % 360);
    }
    const layer = amb.querySelector('.amb-img');
    if (img && S.settings.glass) {
      layer.style.backgroundImage = `url("${img.replace(/"/g, '%22')}")`;
      amb.classList.add('has-img');
    } else {
      amb.classList.remove('has-img');
    }
  }, 180);
}

// ---------- tiles ----------
// ---------- hold-OK options ----------
// "Add to Favourites" / "Remove from Favourites" for a channel, film or show (an episode
// favourites its show). `after` redraws whatever shows the heart.
export function favOption(item, after) {
  const id = item.showId || item.id;
  const on = isFav(id);
  return { label: on ? 'Remove from Favourites' : 'Add to Favourites', run: () => {
    const now = toggleFav(id);
    toast(now ? 'Added to Favourites' : 'Removed from Favourites');
    if (after) after(now);
  } };
}
// Give a tile its options: favourite on/off, then anything else the caller adds.
export function withOptions(el, item, extra = () => []) {
  const after = (on) => {
    const dot = el.querySelector(':scope > .fav-dot');
    if (on && !dot) el.append(h('span.fav-dot', icon('heartFill'))); else if (!on && dot) dot.remove();
  };
  // Tiles on Home also get their row's options (move, hide).
  const row = () => { const sec = el.closest('.section'); return sec && sec.rowOptions ? sec.rowOptions() : []; };
  el.lumenOptions = () => menu(el, item.ep ? item.ep.show : item.name, [favOption(item, after), ...extra(), ...row()]);
  return el;
}

export function channelTile(ch, onOpen) {
  const { now, p } = nowNext(ch);
  const el = h('div.tile.ch-tile.f', { tabindex: '0', onclick: () => onOpen(ch), onfocus: () => setAmbient(ch.name) },
    h('div.tile-frame',
      S.settings.showNumbers ? h('span.num', ch.num) : null,
      logoTile(ch.name, ch.logo),
      now ? h('div.bar', h('i', { style: { width: (p * 100).toFixed(1) + '%' } })) : null,
    ),
    isFav(ch.id) ? h('span.fav-dot', icon('heartFill')) : null,
    h('div.tile-meta',
      h('div.tile-title', ch.name),
      h('div.tile-sub', now ? now[2] : ch.group),
    ),
  );
  return withOptions(el, ch, () => [myListOption(ch)]);
}

export function myListOption(ch, after) {
  const on = inMyList(ch.id);
  return { label: on ? 'Remove from My channels' : 'Add to My channels', run: () => {
    const now = toggleMyList(ch.id);
    toast(now ? `${ch.name} added to My channels` : `${ch.name} removed from My channels`);
    if (after) after(now);
  } };
}

// Same footprint as a channel tile, with an app icon in the frame.
export function sourceCard({ icon: ic, title, sub, onclick, state }) {
  const subEl = h('div.tile-sub', sub);
  const frame = h('div.tile-frame', ic instanceof Node ? ic : appIcon(ic), state === 'busy' ? h('span.src-state', h('span.spinner')) : state === 'error' ? h('span.src-state.err', '!') : null);
  const el = h('div.tile.ch-tile.src-tile.f' + (state === 'error' ? '.is-error' : ''), { tabindex: '0', onclick, onfocus: () => setAmbient(title) },
    frame, h('div.tile-meta', h('div.tile-title', title), subEl));
  el.update = (next) => {
    subEl.textContent = next.sub;
    const old = frame.querySelector('.src-state');
    if (old) old.remove();
    if (next.state === 'busy') frame.append(h('span.src-state', h('span.spinner')));
    if (next.state === 'error') frame.append(h('span.src-state.err', '!'));
    el.classList.toggle('is-error', next.state === 'error');
  };
  return el;
}

export function posterCard(item, onOpen, opts = {}) {
  const prog = progressOf(item.id);
  const rating = item.rating ? h('span.badge.rating', icon('star'), (item.rating > 10 ? item.rating / 10 : item.rating).toFixed(1)) : null;
  const sub = opts.sub || [item.year || '', item.episodes ? `${seasonCount(item)} season${seasonCount(item) === 1 ? '' : 's'}` : catLabel(item.group)].filter(Boolean).join(' · ');
  return withOptions(h('div.tile.poster.f', { tabindex: '0', onclick: () => onOpen(item), onfocus: () => setAmbient(item.name, item.logo) },
    h('div.tile-frame', posterTile(item.name, item.logo), rating, prog ? h('div.bar', h('i', { style: { width: prog * 100 + '%' } })) : null),
    isFav(item.id) ? h('span.fav-dot', icon('heartFill')) : null,
    h('div.tile-meta', h('div.tile-title', item.name), h('div.tile-sub', sub)),
  ), item);
}

function seasonCount(show) { return new Set((show.episodes || []).map((e) => e.ep.s)).size || 1; }

export function wideCard(item, onOpen) {
  const prog = progressOf(item.id);
  const e = S.history.find((x) => x.id === item.id);
  const left = e && e.dur ? Math.max(1, Math.round((e.dur - e.pos) / 60)) : 0;
  const title = item.ep ? item.ep.show : item.name;
  const sub = item.ep ? `S${item.ep.s} E${item.ep.e}${item.ep.title ? ' · ' + item.ep.title : ''}` : (left ? `${left} min left` : item.group);
  return withOptions(h('div.tile.wide.f', { tabindex: '0', onclick: () => onOpen(item), onfocus: () => setAmbient(title, item.logo) },
    h('div.tile-frame', posterTile(title, item.logo), h('div.shade'),
      h('div.over', h('div.t', title), h('div.bar', h('i', { style: { width: prog * 100 + '%' } }))),
    ),
    h('div.tile-meta', h('div.tile-sub', sub)),
  ), item);
}

export function section(title, items, opts = {}) {
  if (!items.length) return null;
  return h('section.section',
    h('div.section-head', h('h2', title), opts.more ? h('span.more', opts.more) : null),
    h('div.scroller', { 'data-remember': '' }, items),
  );
}

let unavailable = null, unavailableAt = 0;
function isUnavailable(id) {
  if (Date.now() - unavailableAt > 5000) {
    try { unavailable = JSON.parse(localStorage.getItem('lumen.unavailable') || '{}'); } catch { unavailable = {}; }
    unavailableAt = Date.now();
  }
  const t = unavailable[id];
  return t && Date.now() - t < 3 * 86400000;
}

export function channelRow(ch, opts = {}) {
  const { now, next, p } = nowNext(ch);
  const locked = isLocked('live', ch.group);
  return h('div.ch-row.f' + (opts.playing ? '.playing' : ''), { tabindex: '0', onclick: opts.onclick, onfocus: opts.onfocus, dataset: { id: ch.id } },
    h('span.num', opts.num != null ? opts.num : S.settings.showNumbers ? ch.num : ''),
    logoTile(ch.name, ch.logo),
    h('div.txt',
      h('div.name', h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis' } }, ch.name), isFav(ch.id) ? icon('heartFill') : null, locked ? icon('lock', 'lock') : null, ch.catchup ? icon('rewind') : null, ch.q ? h('span.tag', ch.q) : null, ch.tags && ch.tags.includes('Geo-blocked') ? h('span.tag', 'Geo-blocked') : null, isUnavailable(ch.id) ? h('span.tag.warn', 'Not available here') : null),
      locked ? h('div.prog', 'Locked') : now ? [h('div.prog', now[2]), h('div.bar', h('i', { style: { width: (p * 100).toFixed(1) + '%' } }))] : h('div.prog', opts.group || ch.group),
    ),
    opts.compact ? null : h('div.right', now ? h('span', `${Math.max(1, Math.round((now[1] - Date.now()) / 60000))} min left`) : null, next ? h('span.nx', `${fmtClock(next[0])} ${next[2]}`) : null),
  );
}

// ---------- layers ----------
export function openLayer(content, opts = {}) {
  const host = document.getElementById('layers');
  const scrim = opts.noScrim ? h('div', { style: { position: 'absolute', inset: 0 } }) : h('div.layer-scrim');
  const el = h('div.layer' + (opts.cls ? '.' + opts.cls : ''), scrim, content);
  let closed = false;
  const close = (v) => {
    if (closed) return;
    closed = true;
    nav.pop(el, opts.restore !== false);
    el.remove();
    opts.onClose && opts.onClose(v);
  };
  scrim.addEventListener('click', () => close());
  host.append(el);
  nav.push(el, () => close());
  requestAnimationFrame(() => nav.focusFirst(content));
  return { el, close };
}

export function menu(anchor, title, items, opts = {}) {
  return new Promise((resolve) => {
    const m = h('div.menu.glass-strong', title ? h('h4', title) : null,
      items.map((it) => h('button.menu-item', {
        class: it.on ? 'on' : '',
        'data-autofocus': it.on ? '' : null,
        onclick: () => { L.close(); resolve(it); it.run && it.run(); },
      }, icon('check'), it.label)),
    );
    const L = openLayer(m, { noScrim: true, onClose: () => resolve(null), cls: opts.dark ? 'pui-menu' : '' });
    const r = anchor.getBoundingClientRect();
    m.style.position = 'fixed';
    requestAnimationFrame(() => {
      const mh = m.offsetHeight, mw = m.offsetWidth;
      const left = Math.min(window.innerWidth - mw - 16, Math.max(16, r.left + r.width / 2 - mw / 2));
      const top = r.top - mh - 14 > 16 ? r.top - mh - 14 : Math.min(window.innerHeight - mh - 16, r.bottom + 14);
      m.style.left = left + 'px'; m.style.top = top + 'px';
    });
  });
}

export function confirmBox(title, text, okLabel = 'OK', danger = false) {
  return new Promise((resolve) => {
    let val = false;
    const box = h('div.modal.glass-strong',
      h('h2', title), h('p.lead', text),
      h('div.actions',
        h('button.btn', { onclick: () => L.close() }, 'Cancel'),
        h('button.btn' + (danger ? '.btn-danger' : '.btn-accent'), { 'data-autofocus': '', onclick: () => { val = true; L.close(); } }, okLabel),
      ),
    );
    const L = openLayer(box, { onClose: () => resolve(val) });
  });
}

// PIN prompt with an on-screen keypad that works with a remote's number keys.
export function askPin(title = 'Enter PIN', opts = {}) {
  return new Promise((resolve) => {
    let entered = '';
    let ok = false;
    const dots = h('div.pin-dots', [0, 1, 2, 3].map(() => h('i')));
    const paint = () => Array.from(dots.children).forEach((d, i) => d.classList.toggle('on', i < entered.length));
    const press = (d) => {
      if (d === 'del') entered = entered.slice(0, -1);
      else if (entered.length < 4) entered += d;
      paint();
      if (entered.length === 4) {
        if (opts.set) { ok = entered; L.close(); return; }
        if (entered === S.settings.pin) { ok = true; L.close(); }
        else { box.classList.remove('shake'); void box.offsetWidth; box.classList.add('shake'); entered = ''; setTimeout(paint, 250); }
      }
    };
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0', 'ok'];
    const box = h('div.modal.glass-strong', { style: { width: 'min(26rem, calc(100% - 2rem))', textAlign: 'center' } },
      h('h2', title), h('p.lead', { style: { marginBottom: 0 } }, opts.lead || 'Enter your 4-digit PIN.'),
      dots,
      h('div.keypad', keys.map((k) => k === 'ok'
        ? h('button.btn', { onclick: () => L.close() }, icon('close'))
        : h('button.btn', { 'data-autofocus': k === '5' ? '' : null, onclick: () => press(k) }, k === 'del' ? icon('left') : k))),
    );
    const off = nav.onKey((k, e) => {
      if (k === 'digit') { press(e.key); return true; }
      return false;
    });
    const L = openLayer(box, { onClose: () => { off(); resolve(ok); } });
  });
}

// A number pad for the remote: digits, delete, OK. Resolves to the number, or null.
export function askNumber(title, lead, max = 9999) {
  return new Promise((resolve) => {
    let entered = '', ok = null;
    const shown = h('div.num-entry', '–');
    const paint = () => { shown.textContent = entered || '–'; };
    const press = (d) => {
      if (d === 'del') entered = entered.slice(0, -1);
      else if (d === 'ok') { if (entered) { ok = Math.min(max, Number(entered)); L.close(); } return; }
      else if (entered.length < String(max).length) entered = (entered + d).replace(/^0+/, '');
      paint();
    };
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'del', '0', 'ok'];
    const box = h('div.modal.glass-strong', { style: { width: 'min(26rem, calc(100% - 2rem))', textAlign: 'center' } },
      h('h2', title), lead ? h('p.lead', { style: { marginBottom: 0 } }, lead) : null, shown,
      h('div.keypad', keys.map((k) => h('button.btn' + (k === 'ok' ? '.btn-accent' : ''), { 'data-autofocus': k === '5' ? '' : null, onclick: () => press(k) }, k === 'del' ? icon('left') : k === 'ok' ? icon('check') : k))),
    );
    const off = nav.onKey((k, e) => {
      if (k === 'digit') { press(e.key); return true; }
      return false;
    });
    const L = openLayer(box, { onClose: () => { off(); resolve(ok); } });
  });
}

export async function unlockIfNeeded(type, group) {
  if (!isLocked(type, group)) return true;
  const ok = await askPin('Parental lock', { lead: `“${group}” is locked. Enter your PIN to continue.` });
  if (ok) S.unlocked = true;
  return ok;
}

export function clockEl() {
  const el = h('div.clock', h('span.tnum'), h('small'));
  const tick = () => {
    if (!el.isConnected) return;
    const d = new Date();
    el.firstChild.textContent = fmtClock(d);
    el.lastChild.textContent = d.toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long' });
  };
  tick();
  const t = setInterval(() => { if (!el.isConnected) clearInterval(t); else tick(); }, 15000);
  return el;
}

export function topbar(title, sub, ...extra) {
  return h('header.topbar', h('div', h('h1', title), sub ? h('div.sub', sub) : null), h('div.row', { style: { gap: '1.6rem' } }, ...extra, clockEl()));
}

export function emptyState(ic, title, text, action) {
  return h('div.empty-state', icon(ic), h('h3', title), h('p', text), action || null);
}

export function toggleEl(on) { return h('span.toggle' + (on ? '.on' : '')); }

export function q(sel) { return $(sel); }
