// "Film & series languages": a grid of the languages your provider tags its on-demand
// categories with. Movies, Series, Home and search show only the ones you pick.
import { h, toast } from '../util.js';
import { icon } from '../icons.js';
import { nav } from '../nav.js';
import { S, bus, setSetting, vodLanguages, vodLangs, LANG_NAMES } from '../store.js';
import { openLayer } from './common.js';

const nameOf = (t) => LANG_NAMES[t] || t;

export function langSummary() {
  const set = vodLangs();
  if (!set) return 'All languages';
  // Only languages your provider actually has ("English", not "English, English (UK)").
  const have = new Set(vodLanguages().map((l) => l.tag));
  const names = [...set].filter((t) => t !== 'MULTI' && have.has(t)).map(nameOf).filter((n, i, a) => a.indexOf(n) === i);
  const text = names.length > 3 ? `${names.slice(0, 3).join(', ')} and ${names.length - 3} more` : names.join(', ');
  return (text || 'Multi-language') + (S.settings.vodLangs.length ? '' : ' (from your countries)');
}

export function openLangPicker(onDone) {
  const langs = vodLanguages();
  const start = vodLangs();
  const chosen = new Set(start ? [...start].filter((t) => langs.some((l) => l.tag === t)) : []);
  const tiles = new Map();
  const summary = h('p.cp-summary');

  function paint() {
    for (const [t, el] of tiles) { el.classList.toggle('on', chosen.has(t)); el.setAttribute('aria-pressed', String(chosen.has(t))); }
    const n = langs.filter((l) => chosen.has(l.tag)).reduce((a, l) => a + l.n, 0);
    const total = langs.reduce((a, l) => a + l.n, 0);
    summary.textContent = chosen.size
      ? `Showing ${n} of ${total} film and series categories.`
      : `Showing all ${total} categories. Pick languages to hide the rest.`;
  }
  const tile = ({ tag, n, name }) => {
    const el = h('button.cp-tile', { onclick: () => { chosen.has(tag) ? chosen.delete(tag) : chosen.add(tag); paint(); } },
      h('span.cp-flag.lang-code', tag === 'MULTI' ? '🌐' : tag.slice(0, 4)),
      h('span.cp-txt', h('span.cp-name', name), h('span.cp-n', `${n} categor${n === 1 ? 'y' : 'ies'}`)),
      h('span.cp-check', icon('check')));
    tiles.set(tag, el);
    return el;
  };

  function done() {
    const before = S.settings.vodLangs.join();
    // Picking nothing means "show every language".
    setSetting('vodLangs', [...chosen]);
    L.close();
    if (before !== [...chosen].join()) { toast(chosen.size ? `Films and series in ${langSummary()}` : 'Showing every language'); bus.emit('library'); }
    onDone && onDone();
  }

  let L;
  const box = h('div.modal.glass-strong.cp',
    h('div.cp-head', h('div', h('h2', 'Film & series languages'), h('p.lead', 'Pick the languages you watch. Movies, Series, Home and search only show categories in these languages. “Multi-language” covers categories with several audio or subtitle tracks.'))),
    summary,
    h('div.cp-scroll', h('div.cp-grid', langs.map(tile))),
    h('div.actions',
      h('button.btn', { onclick: () => { chosen.clear(); paint(); } }, icon('globe'), 'Every language'),
      h('button.btn.btn-accent', { onclick: done }, 'Done'),
    ),
  );
  L = openLayer(box);
  paint();
  requestAnimationFrame(() => nav.focus(tiles.get([...chosen][0]) || box.querySelector('.cp-tile')));
}
