// Applies appearance settings to the document.
import { S } from './store.js';
import { setClock24, ls } from './util.js';
import { nav } from './nav.js';

// The Android TV app starts with glass blur off: TV graphics chips struggle with it.
// Done once, so turning it back on in Settings sticks.
if (/LumenTV/.test(navigator.userAgent) && !ls.get('tvPerf')) {
  S.settings.glass = false;
  ls.set('tvPerf', true);
  ls.set('settings', S.settings);
}

// Text and tiles are sized for reading from the sofa on a TV: "auto" is Large there.
export const UI_SCALES = [['auto', 'Automatic'], ['standard', 'Standard'], ['large', 'Large'], ['xl', 'Extra large']];
const SCALE = { standard: 1, large: 1.2, xl: 1.36 };
export function uiScale() {
  const k = S.settings.uiScale === 'auto' || !SCALE[S.settings.uiScale] ? (/LumenTV/.test(navigator.userAgent) ? 'large' : 'standard') : S.settings.uiScale;
  return SCALE[k];
}

export function applyTheme() {
  const s = S.settings;
  const root = document.documentElement;
  root.dataset.theme = s.theme;
  root.style.setProperty('--accent', s.accent);
  root.classList.toggle('no-glass', !s.glass);
  root.classList.toggle('no-motion', !s.motion);
  root.style.setProperty('--ui-scale', String(uiScale()));
  setClock24(s.clock24);
  nav.setMotion(s.motion);
  const dark = s.theme === 'dark' || (s.theme === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = dark ? '#0B0E14' : '#ECEFF5';
}
