// Built-in free TV sources and their app icons.
// The iptv-org category and country lists are subsets of "All channels", so they
// share the same deduplicated channels and act as differently organised views.

export const PROVIDERS = [
  { key: 'iptv-all', name: 'All channels', org: 'iptv-org', icon: 'iptv-all', url: 'https://iptv-org.github.io/iptv/index.m3u' },
  { key: 'iptv-country', name: 'By country', org: 'iptv-org', icon: 'iptv-country', url: 'https://iptv-org.github.io/iptv/index.country.m3u' },
  { key: 'iptv-news', name: 'News', org: 'iptv-org', icon: 'iptv-news', url: 'https://iptv-org.github.io/iptv/categories/news.m3u' },
  { key: 'iptv-sports', name: 'Sports', org: 'iptv-org', icon: 'iptv-sports', url: 'https://iptv-org.github.io/iptv/categories/sports.m3u' },
  { key: 'iptv-movies', name: 'Movies', org: 'iptv-org', icon: 'iptv-movies', url: 'https://iptv-org.github.io/iptv/categories/movies.m3u' },
  { key: 'iptv-kids', name: 'Kids', org: 'iptv-org', icon: 'iptv-kids', url: 'https://iptv-org.github.io/iptv/categories/kids.m3u' },
  { key: 'iptv-ae', name: 'UAE', org: 'iptv-org', icon: 'iptv-ae', url: 'https://iptv-org.github.io/iptv/countries/ae.m3u' },
  { key: 'plex', name: 'Plex', org: 'Plex', icon: 'plex', url: 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plex_all.m3u' },
  { key: 'pluto', name: 'Pluto TV', org: 'Pluto TV', icon: 'pluto', url: 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/plutotv_all.m3u' },
  { key: 'samsung', name: 'Samsung TV Plus', org: 'Samsung', icon: 'samsung', url: 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/samsungtvplus_all.m3u' },
  { key: 'roku', name: 'The Roku Channel', org: 'Roku', icon: 'roku', url: 'https://raw.githubusercontent.com/BuddyChewChew/app-m3u-generator/main/playlists/roku_all.m3u' },
];

const IPTV_BG = ['#24364D', '#0F1A28'];
const glyph = (d) => `<g fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round">${d}</g>`;

// Each icon: [gradient from, gradient to, inner SVG on a 64×64 grid]
const ICONS = {
  main: [null, null, glyph('<path d="M17 30 32 18l15 12v15a2 2 0 0 1-2 2h-8v-9h-10v9h-8a2 2 0 0 1-2-2z"/>')],
  add: [null, null, glyph('<path d="M32 21v22M21 32h22"/>')],
  collapse: ['#3A3F4B', '#22262F', glyph('<path d="M22 37l10-10 10 10"/>')],
  manage: ['#3A3F4B', '#22262F', glyph('<circle cx="32" cy="32" r="5"/><path d="M32 17v4M32 43v4M47 32h-4M21 32h-4M42.6 21.4l-2.8 2.8M24.2 39.8l-2.8 2.8M42.6 42.6l-2.8-2.8M24.2 24.2l-2.8-2.8"/>')],
  'iptv-all': [...IPTV_BG, glyph('<rect x="16" y="21" width="32" height="22" rx="4"/><path d="m26 15 6 6 6-6M24 49h16"/>')],
  'iptv-country': [...IPTV_BG, glyph('<circle cx="32" cy="32" r="14"/><path d="M18 32h28M32 18c4 4 6 9 6 14s-2 10-6 14c-4-4-6-9-6-14s2-10 6-14z"/>')],
  'iptv-news': [...IPTV_BG, glyph('<rect x="17" y="19" width="24" height="27" rx="3"/><path d="M41 26h5v16a4 4 0 0 1-8 0M22 26h14M22 32h14M22 38h9"/>')],
  'iptv-sports': [...IPTV_BG, glyph('<circle cx="32" cy="32" r="14"/><path d="m32 24 7 5-3 8h-8l-3-8zM32 18v6M39 29l7-2M36 37l4 6M28 37l-4 6M25 29l-7-2"/>')],
  'iptv-movies': [...IPTV_BG, glyph('<rect x="17" y="18" width="30" height="28" rx="3"/><path d="M24 18v28M40 18v28M17 26h7M17 38h7M40 26h7M40 38h7"/>')],
  'iptv-kids': [...IPTV_BG, glyph('<path d="m32 17 4.4 9 9.6 1.4-7 6.8 1.7 9.6L32 39.3l-8.7 4.5 1.7-9.6-7-6.8 9.6-1.4z"/>')],
  'iptv-ae': [...IPTV_BG, '<g><rect x="14" y="21" width="36" height="22" rx="3" fill="#fff"/><path d="M24 21h23a3 3 0 0 1 3 3v4.3H24z" fill="#00732F"/><path d="M24 35.7h26V40a3 3 0 0 1-3 3H24z" fill="#000"/><path d="M17 21h7v22h-7a3 3 0 0 1-3-3V24a3 3 0 0 1 3-3z" fill="#FF0000"/></g>'],
  plex: ['#2A2A2A', '#0C0C0C', '<text x="32" y="38.5" text-anchor="middle" font-family="Manrope, system-ui, sans-serif" font-weight="800" font-size="17" fill="#E5A00D" letter-spacing="-.5">plex</text>'],
  pluto: ['#1B1B1B', '#000', '<text x="32" y="33" text-anchor="middle" font-family="Manrope, system-ui, sans-serif" font-weight="800" font-size="15" fill="#FFF200" letter-spacing="-.4">pluto</text><text x="32" y="46" text-anchor="middle" font-family="Manrope, system-ui, sans-serif" font-weight="800" font-size="10" fill="#fff" letter-spacing="1.5">TV</text>'],
  samsung: ['#2246D6', '#0F1F8A', '<text x="32" y="31" text-anchor="middle" font-family="Manrope, system-ui, sans-serif" font-weight="800" font-size="12.5" fill="#fff">TV</text><text x="32" y="44" text-anchor="middle" font-family="Manrope, system-ui, sans-serif" font-weight="700" font-size="9.5" fill="#fff" fill-opacity=".85" letter-spacing=".6">PLUS</text>'],
  roku: ['#7B3FB0', '#4A1F75', '<text x="32" y="38.5" text-anchor="middle" font-family="Manrope, system-ui, sans-serif" font-weight="800" font-size="16.5" fill="#fff" letter-spacing="-.4">Roku</text>'],
};

let uid = 0;
export function appIcon(key) {
  const [a, b, inner] = ICONS[key] || ICONS['iptv-all'];
  const id = 'ai' + uid++;
  const from = a || 'var(--icon-a)', to = b || 'var(--icon-b)';
  const span = document.createElement('span');
  span.className = 'app-icon';
  span.innerHTML = `<svg viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${from}" style="stop-color:${from}"/><stop offset="1" stop-color="${to}" style="stop-color:${to}"/></linearGradient><linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".22"/><stop offset=".5" stop-color="#fff" stop-opacity="0"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#${id})"/>${inner}<rect width="64" height="64" rx="15" fill="url(#${id}s)"/></svg>`;
  return span;
}

export function providerOf(pl) {
  return PROVIDERS.find((p) => p.key === pl.builtin) || null;
}
