// Xtream Codes player_api client. Produces the same item shape as the M3U parser
// plus richer metadata (posters, plots, ratings, archive days).
import { hash } from './util.js';
import { net } from './net.js';

function base(server) {
  let s = server.trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  return s.replace(/\/(player_api\.php|get\.php).*$/i, '');
}

async function api(acc, action, extra = '') {
  const u = `${base(acc.server)}/player_api.php?username=${encodeURIComponent(acc.user)}&password=${encodeURIComponent(acc.pass)}${action ? '&action=' + action : ''}${extra}`;
  const txt = await net.text(u);
  try { return JSON.parse(txt); } catch { throw new Error('The server did not return Xtream data. Check the address and login.'); }
}

export async function xtreamLoad(acc, plId, onStep = () => {}) {
  const b = base(acc.server);
  const U = encodeURIComponent(acc.user), Pw = encodeURIComponent(acc.pass);
  onStep('Signing in');
  const auth = await api(acc, '');
  if (!auth || !auth.user_info || Number(auth.user_info.auth) === 0) throw new Error('Sign-in failed. Check the username and password.');
  const ext = acc.liveFormat || 'm3u8';

  onStep('Loading categories');
  const [lc, vc, sc] = await Promise.all([
    api(acc, 'get_live_categories').catch(() => []),
    api(acc, 'get_vod_categories').catch(() => []),
    api(acc, 'get_series_categories').catch(() => []),
  ]);
  const cat = (list) => Object.fromEntries((list || []).map((c) => [String(c.category_id), c.category_name]));
  const L = cat(lc), V = cat(vc), S = cat(sc);

  const items = [];
  onStep('Loading live channels');
  const live = await api(acc, 'get_live_streams').catch(() => []);
  for (const s of live || []) {
    const url = `${b}/live/${U}/${Pw}/${s.stream_id}.${ext}`;
    const it = {
      id: hash(plId + '|live|' + s.stream_id), pl: plId, type: 'live', idx: items.length,
      name: s.name || 'Channel', url, logo: s.stream_icon || '', group: L[String(s.category_id)] || 'Uncategorised',
      tvgId: s.epg_channel_id || '', tvgName: s.name || '', chno: Number(s.num) || 0,
      xc: { sid: s.stream_id },
    };
    if (Number(s.tv_archive)) { it.catchup = 'xc'; it.catchupDays = Number(s.tv_archive_duration) || 1; }
    items.push(it);
  }
  // Movies and series load one category at a time when opened (xtreamCategory below).
  // Big providers carry hundreds of thousands of titles, far more than a TV can hold at once.
  const cats = {
    movie: (vc || []).map((c) => ({ id: String(c.category_id), name: c.category_name || 'Movies' })),
    series: (sc || []).map((c) => ({ id: String(c.category_id), name: c.category_name || 'Series' })),
  };
  return {
    items, shows: [], cats,
    epg: [`${b}/xmltv.php?username=${U}&password=${Pw}`],
    info: {
      expires: Number(auth.user_info.exp_date) * 1000 || 0,
      maxConn: Number(auth.user_info.max_connections) || 0,
      status: auth.user_info.status,
    },
  };
}

// Now and next for one channel, straight from the provider. Used when the XMLTV guide
// doesn't cover a channel or hasn't loaded. Titles and descriptions arrive base64-encoded.
export async function xtreamShortEpg(acc, sid, limit = 6) {
  const r = await api(acc, 'get_short_epg', `&stream_id=${sid}&limit=${limit}`);
  const b64 = (v) => { try { return new TextDecoder().decode(Uint8Array.from(atob(v || ''), (c) => c.charCodeAt(0))).trim(); } catch { return String(v || ''); } };
  return ((r && r.epg_listings) || [])
    .map((p) => [Number(p.start_timestamp) * 1000, Number(p.stop_timestamp) * 1000, b64(p.title), b64(p.description), '', '', '', '', 0])
    .filter((p) => p[0] && p[1] > p[0] && p[2])
    .sort((a, b) => a[0] - b[0]);
}

// The account as the provider sees it right now: login, status, expiry and connections in use.
export async function xtreamAccount(acc) {
  const r = await api(acc, '');
  return (r && r.user_info) || null;
}

// "Hallowarrior - 2026 [MULTI-SUB]" -> "Hallowarrior". The year is kept in its own field.
export function tidyTitle(name) {
  const t = String(name || '')
    .replace(/\s*[\[(][^\])]*[\])]/g, ' ')
    .replace(/\s*[-–|:]\s*(19|20)\d\d\s*$/, '')
    .replace(/\s+(19|20)\d\d\s*$/, '')
    .replace(/^\s*[A-Z]{2,4}\s*[|:-]\s+/, '')
    .replace(/\s+/g, ' ').trim();
  return t || String(name || '').trim();
}

function mapMovie(acc, plId, s, group) {
  const b = base(acc.server);
  const U = encodeURIComponent(acc.user), Pw = encodeURIComponent(acc.pass);
  const y = /\b(19|20)\d\d\b/.exec(s.name || '');
  return {
    id: hash(plId + '|vod|' + s.stream_id), pl: plId, type: 'movie', lazy: true,
    name: tidyTitle(s.name) || 'Movie', url: `${b}/movie/${U}/${Pw}/${s.stream_id}.${s.container_extension || 'mp4'}`,
    logo: s.stream_icon || '', group,
    rating: Number(s.rating_5based) ? Number(s.rating_5based) * 2 : Number(s.rating) || 0,
    added: Number(s.added) || 0, year: y ? Number(y[0]) : 0,
    xc: { vid: s.stream_id },
  };
}

function mapShow(plId, s, group) {
  return {
    id: hash(plId + '|series|' + s.series_id), pl: plId, name: tidyTitle(s.name) || 'Series', lazy: true,
    logo: s.cover || '', group, plot: s.plot || '',
    rating: Number(s.rating_5based) ? Number(s.rating_5based) * 2 : Number(s.rating) || 0,
    year: Number(String(s.releaseDate || s.release_date || '').slice(0, 4)) || 0,
    genre: s.genre || '', added: Number(s.last_modified) || 0,
    backdrop: Array.isArray(s.backdrop_path) ? s.backdrop_path[0] : '',
    xc: { series: s.series_id },
  };
}

// One movie or series category, fetched when the viewer opens it.
export async function xtreamCategory(acc, plId, type, cat) {
  const action = type === 'movie' ? 'get_vod_streams' : 'get_series';
  const list = await api(acc, action, '&category_id=' + encodeURIComponent(cat.id));
  if (!Array.isArray(list)) return [];
  return type === 'movie' ? list.map((s) => mapMovie(acc, plId, s, cat.name)) : list.map((s) => mapShow(plId, s, cat.name));
}

export async function xtreamSeriesInfo(acc, show) {
  const b = base(acc.server);
  const U = encodeURIComponent(acc.user), Pw = encodeURIComponent(acc.pass);
  const r = await api(acc, 'get_series_info', '&series_id=' + show.xc.series);
  const eps = [];
  for (const [season, list] of Object.entries(r.episodes || {})) {
    for (const e of list || []) {
      eps.push({
        id: hash(show.pl + '|ep|' + e.id), pl: show.pl, type: 'series', lazy: !!show.lazy,
        name: `${show.name} S${String(season).padStart(2, '0')}E${String(e.episode_num).padStart(2, '0')}`,
        url: `${b}/series/${U}/${Pw}/${e.id}.${e.container_extension || 'mp4'}`,
        logo: (e.info && e.info.movie_image) || show.logo, group: show.group,
        ep: { show: show.name, s: Number(season), e: Number(e.episode_num), title: e.title || '' },
        plot: (e.info && e.info.plot) || '', dur: (e.info && Number(e.info.duration_secs)) || 0,
        showId: show.id,
      });
    }
  }
  const info = r.info || {};
  return {
    episodes: eps,
    plot: info.plot || show.plot, cast: info.cast || '', genre: info.genre || show.genre,
    backdrop: (Array.isArray(info.backdrop_path) && info.backdrop_path[0]) || show.backdrop || '',
    rating: Number(info.rating) || show.rating,
  };
}

export async function xtreamVodInfo(acc, item) {
  const r = await api(acc, 'get_vod_info', '&vod_id=' + item.xc.vid);
  const i = r.info || {};
  return {
    plot: i.plot || i.description || '', cast: i.cast || i.actors || '', director: i.director || '',
    genre: i.genre || '', dur: Number(i.duration_secs) || 0, rating: Number(i.rating) || item.rating || 0,
    backdrop: (Array.isArray(i.backdrop_path) && i.backdrop_path[0]) || '', year: Number(String(i.releasedate || '').slice(0, 4)) || item.year,
    trailer: i.youtube_trailer || '',
  };
}

export function xtreamCatchupUrl(acc, item, start, durMin) {
  const b = base(acc.server);
  const d = new Date(start);
  const p = (n) => String(n).padStart(2, '0');
  const stamp = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}:${p(d.getHours())}-${p(d.getMinutes())}`;
  return `${b}/timeshift/${encodeURIComponent(acc.user)}/${encodeURIComponent(acc.pass)}/${Math.ceil(durMin)}/${stamp}/${item.xc.sid}.ts`;
}
