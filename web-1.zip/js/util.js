// Small DOM and formatting helpers shared by every view.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

// h('div.card.f', {onclick}, child, ...) — tiny hyperscript.
export function h(tag, attrs, ...kids) {
  const m = /^([a-z0-9-]+)?((?:[.#][\w-]+)*)$/i.exec(tag) || [];
  const el = document.createElement(m[1] || 'div');
  for (const part of (m[2] || '').match(/[.#][\w-]+/g) || []) {
    if (part[0] === '.') el.classList.add(part.slice(1));
    else el.id = part.slice(1);
  }
  if (attrs && (typeof attrs !== 'object' || attrs instanceof Node || Array.isArray(attrs))) {
    kids.unshift(attrs); attrs = null;
  }
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v == null || v === false) continue;
      if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
      else if (k === 'style' && typeof v === 'object') { for (const [sk, sv] of Object.entries(v)) { if (sk.startsWith('--')) el.style.setProperty(sk, sv); else el.style[sk] = sv; } }
      else if (k === 'class') el.className += ' ' + v;
      else if (k === 'html') el.innerHTML = v;
      else if (k === 'dataset') Object.assign(el.dataset, v);
      else if (k in el && typeof v !== 'string') el[k] = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
  }
  append(el, kids);
  return el;
}

function append(el, kids) {
  for (const k of kids) {
    if (k == null || k === false) continue;
    if (Array.isArray(k)) append(el, k);
    else el.append(k instanceof Node ? k : document.createTextNode(String(k)));
  }
}

// Element.append() that skips null/false children, like h().
export function add(el, ...kids) { append(el, kids); return el; }

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }

export function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

// FNV-1a — stable ids for favourites and history across playlist refreshes.
export function hash(str) {
  let h1 = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h1 ^= str.charCodeAt(i);
    h1 = Math.imul(h1, 0x01000193);
  }
  return (h1 >>> 0).toString(36);
}

export function hue(str) {
  let n = 0;
  for (let i = 0; i < str.length; i++) n = (n * 31 + str.charCodeAt(i)) % 360;
  return n;
}

export function initials(name) {
  const clean = String(name).replace(/\b(HD|FHD|UHD|SD|4K|HEVC|H265)\b/gi, '').replace(/[^\p{L}\p{N} ]/gu, ' ').trim();
  const words = clean.split(/\s+/).filter(Boolean);
  if (!words.length) return '·';
  if (words.length === 1) return words[0].slice(0, 3).toUpperCase();
  if (/^\d+$/.test(words[words.length - 1])) return (words[0][0] + words[words.length - 1]).slice(0, 4).toUpperCase();
  return (words[0][0] + words[1][0] + (words[2] ? words[2][0] : '')).toUpperCase();
}

export function normName(s) {
  return String(s || '').toLowerCase()
    .replace(/\[[^\]]*\]|\([^)]*\)/g, '')
    .replace(/\b(hd|fhd|uhd|sd|4k|hevc|h265|backup|\+1)\b/g, '')
    .replace(/[^a-z0-9]/g, '');
}

let use24 = true;
export function setClock24(v) { use24 = !!v; }

export function fmtClock(d) {
  d = d instanceof Date ? d : new Date(d);
  if (use24) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true });
}

export function fmtDay(d) {
  d = d instanceof Date ? d : new Date(d);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const that = new Date(d); that.setHours(0, 0, 0, 0);
  const diff = Math.round((that - today) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Tomorrow';
  if (diff === -1) return 'Yesterday';
  return d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
}

export function fmtDur(sec) {
  if (!isFinite(sec) || sec < 0) return '--:--';
  sec = Math.floor(sec);
  const hh = Math.floor(sec / 3600), mm = Math.floor((sec % 3600) / 60), ss = sec % 60;
  const p = (n) => String(n).padStart(2, '0');
  return hh ? `${hh}:${p(mm)}:${p(ss)}` : `${mm}:${p(ss)}`;
}

export function fmtMins(min) {
  min = Math.round(min);
  if (min < 60) return `${min} min`;
  const hh = Math.floor(min / 60), mm = min % 60;
  return mm ? `${hh} hr ${mm} min` : `${hh} hr`;
}

export function fmtBytes(n) {
  if (!n) return '0 B';
  const u = ['B', 'KB', 'MB', 'GB'];
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)));
  return (n / 1024 ** i).toFixed(i ? 1 : 0) + ' ' + u[i];
}

export const ls = {
  get(k, d) {
    try { const v = localStorage.getItem('lumen.' + k); return v == null ? d : JSON.parse(v); } catch { return d; }
  },
  set(k, v) {
    try { localStorage.setItem('lumen.' + k, JSON.stringify(v)); } catch {}
  },
};

// Minimal event bus.
export class Emitter {
  constructor() { this.m = new Map(); }
  on(ev, fn) { (this.m.get(ev) || this.m.set(ev, new Set()).get(ev)).add(fn); return () => this.m.get(ev).delete(fn); }
  emit(ev, data) { for (const fn of this.m.get(ev) || []) { try { fn(data); } catch (e) { console.error(e); } } }
}

let toastHost;
export function toast(msg, opts = {}) {
  toastHost ||= document.getElementById('toasts');
  const el = h('div.toast.glass', h('span.toast-msg', msg));
  if (opts.action) {
    const b = h('button.btn.btn-sm.f', { onclick: () => { opts.action.run(); el.remove(); } }, opts.action.label);
    el.append(b);
  }
  toastHost.append(el);
  requestAnimationFrame(() => el.classList.add('in'));
  setTimeout(() => { el.classList.remove('in'); setTimeout(() => el.remove(), 400); }, opts.ms || 3600);
  return el;
}

export function imgOr(src, fallback, cls = '') {
  if (!src) return fallback();
  const img = h('img', { src, loading: 'lazy', decoding: 'async', alt: '', class: cls, referrerPolicy: 'no-referrer' });
  img.addEventListener('error', () => img.replaceWith(fallback()), { once: true });
  return img;
}

export function logoTile(name, src, cls = '') {
  const ph = () => h('div.logo-ph', { style: { '--h': hue(name) } }, initials(name));
  return h('div.logo' + (cls ? '.' + cls : ''), imgOr(src, ph));
}

export function posterTile(name, src) {
  const ph = () => h('div.poster-ph', { style: { '--h': hue(name) } }, h('span', name));
  return imgOr(src, ph, 'poster-img');
}

export function srtToVtt(text) {
  if (/^WEBVTT/.test(text.trim())) return text;
  return 'WEBVTT\n\n' + text.replace(/\r/g, '').replace(/(\d\d:\d\d:\d\d),(\d\d\d)/g, '$1.$2');
}
