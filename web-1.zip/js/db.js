// IndexedDB key/value store for large data (playlists, EPG). Falls back to memory.
const mem = new Map();
let dbp;

function open() {
  if (dbp) return dbp;
  dbp = new Promise((resolve) => {
    try {
      const req = indexedDB.open('lumen', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('kv');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch { resolve(null); }
  });
  return dbp;
}

function tx(db, mode, fn) {
  return new Promise((resolve) => {
    try {
      const t = db.transaction('kv', mode);
      const r = fn(t.objectStore('kv'));
      t.oncomplete = () => resolve(r && r.result);
      t.onerror = () => resolve(undefined);
    } catch { resolve(undefined); }
  });
}

export const db = {
  async get(key) {
    const d = await open();
    if (!d) return mem.get(key);
    return tx(d, 'readonly', (s) => s.get(key));
  },
  async set(key, val) {
    const d = await open();
    if (!d) { mem.set(key, val); return; }
    await tx(d, 'readwrite', (s) => s.put(val, key));
  },
  async del(key) {
    const d = await open();
    if (!d) { mem.delete(key); return; }
    await tx(d, 'readwrite', (s) => s.delete(key));
  },
};
