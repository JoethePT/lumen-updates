// Works out which country each live channel belongs to, from the clues providers leave:
// category names ("EU | UK GENERAL"), channel-name prefixes ("UK| BBC 1 HD"), iptv-org ids
// ("BBCOne.uk@SD") and plain country names ("United Kingdom").

export const COUNTRIES = {
  GB: ['United Kingdom', '🇬🇧'], IE: ['Ireland', '🇮🇪'], US: ['United States', '🇺🇸'], CA: ['Canada', '🇨🇦'],
  AU: ['Australia', '🇦🇺'], NZ: ['New Zealand', '🇳🇿'], DE: ['Germany', '🇩🇪'], AT: ['Austria', '🇦🇹'],
  CH: ['Switzerland', '🇨🇭'], FR: ['France', '🇫🇷'], BE: ['Belgium', '🇧🇪'], NL: ['Netherlands', '🇳🇱'],
  LU: ['Luxembourg', '🇱🇺'], ES: ['Spain', '🇪🇸'], PT: ['Portugal', '🇵🇹'], IT: ['Italy', '🇮🇹'],
  SE: ['Sweden', '🇸🇪'], NO: ['Norway', '🇳🇴'], DK: ['Denmark', '🇩🇰'], FI: ['Finland', '🇫🇮'],
  IS: ['Iceland', '🇮🇸'], PL: ['Poland', '🇵🇱'], CZ: ['Czechia', '🇨🇿'], SK: ['Slovakia', '🇸🇰'],
  HU: ['Hungary', '🇭🇺'], RO: ['Romania', '🇷🇴'], BG: ['Bulgaria', '🇧🇬'], GR: ['Greece', '🇬🇷'],
  CY: ['Cyprus', '🇨🇾'], MT: ['Malta', '🇲🇹'], AL: ['Albania', '🇦🇱'], EXYU: ['Balkans (Ex-Yu)', '🇷🇸'],
  TR: ['Turkey', '🇹🇷'], RU: ['Russia', '🇷🇺'], UA: ['Ukraine', '🇺🇦'], BY: ['Belarus', '🇧🇾'],
  LT: ['Lithuania', '🇱🇹'], LV: ['Latvia', '🇱🇻'], EE: ['Estonia', '🇪🇪'], GE: ['Georgia', '🇬🇪'],
  AM: ['Armenia', '🇦🇲'], AZ: ['Azerbaijan', '🇦🇿'], KU: ['Kurdistan', '🏳️'], ARAB: ['Arabic', '🇸🇦'],
  AE: ['UAE', '🇦🇪'], IL: ['Israel', '🇮🇱'], IR: ['Iran', '🇮🇷'], AFG: ['Afghanistan', '🇦🇫'],
  IN: ['India', '🇮🇳'], PK: ['Pakistan', '🇵🇰'], BD: ['Bangladesh', '🇧🇩'], LK: ['Sri Lanka', '🇱🇰'],
  NP: ['Nepal', '🇳🇵'], CN: ['China', '🇨🇳'], HK: ['Hong Kong', '🇭🇰'], TW: ['Taiwan', '🇹🇼'],
  JP: ['Japan', '🇯🇵'], KR: ['South Korea', '🇰🇷'], PH: ['Philippines', '🇵🇭'], MY: ['Malaysia', '🇲🇾'],
  SG: ['Singapore', '🇸🇬'], TH: ['Thailand', '🇹🇭'], VN: ['Vietnam', '🇻🇳'], ID: ['Indonesia', '🇮🇩'],
  KZ: ['Central Asia', '🇰🇿'], AFR: ['Africa', '🌍'], ZA: ['South Africa', '🇿🇦'], NG: ['Nigeria', '🇳🇬'], EG: ['Egypt', '🇪🇬'],
  MA: ['Morocco', '🇲🇦'], DZ: ['Algeria', '🇩🇿'], TN: ['Tunisia', '🇹🇳'], MX: ['Mexico', '🇲🇽'],
  BR: ['Brazil', '🇧🇷'], AR: ['Argentina', '🇦🇷'], CO: ['Colombia', '🇨🇴'], CL: ['Chile', '🇨🇱'],
  PE: ['Peru', '🇵🇪'], VE: ['Venezuela', '🇻🇪'], LATAM: ['Latin America', '🌎'], CARIB: ['Caribbean', '🏝️'],
  // Buckets that aren't countries.
  '247': ['24/7 movie & series loops', '🔁'], PPV: ['Sports events & pay-per-view', '🏟️'], XX: ['Other channels', '📺'],
};
export const BUCKETS = ['247', 'PPV', 'XX'];

// Words and codes providers use, mapped to the codes above.
const WORDS = {
  UK: 'GB', GB: 'GB', 'UNITED KINGDOM': 'GB', ENGLAND: 'GB', SCOTLAND: 'GB', SCOTTISH: 'GB', WALES: 'GB', CYMRU: 'GB', BRITISH: 'GB', BRITAIN: 'GB',
  IE: 'IE', IRL: 'IE', IRELAND: 'IE', IRISH: 'IE',
  US: 'US', USA: 'US', 'UNITED STATES': 'US', AMERICA: 'US', CA: 'CA', CANADA: 'CA',
  AU: 'AU', AUS: 'AU', AUSTRALIA: 'AU', NZ: 'NZ', 'NEW ZEALAND': 'NZ',
  DE: 'DE', GER: 'DE', GERMANY: 'DE', GERMAN: 'DE', DEUTSCHLAND: 'DE', AT: 'AT', AUSTRIA: 'AT', CH: 'CH', SWITZERLAND: 'CH', SWISS: 'CH',
  FR: 'FR', FRANCE: 'FR', FRENCH: 'FR', BE: 'BE', BELGIUM: 'BE', NL: 'NL', NETHERLANDS: 'NL', HOLLAND: 'NL', DUTCH: 'NL', LU: 'LU',
  ES: 'ES', SPAIN: 'ES', SPANISH: 'ES', ESPANA: 'ES', PT: 'PT', PORTUGAL: 'PT', IT: 'IT', ITALY: 'IT', ITALIA: 'IT', ITALIAN: 'IT',
  SE: 'SE', SWE: 'SE', SWEDEN: 'SE', NO: 'NO', NOR: 'NO', NORWAY: 'NO', DK: 'DK', DENMARK: 'DK', FI: 'FI', FINLAND: 'FI', IS: 'IS', ICELAND: 'IS',
  PL: 'PL', POLAND: 'PL', POLSKA: 'PL', CZ: 'CZ', CZECH: 'CZ', SK: 'SK', SLOVAKIA: 'SK', HU: 'HU', HUNGARY: 'HU', RO: 'RO', ROMANIA: 'RO',
  BG: 'BG', BULGARIA: 'BG', GR: 'GR', GREECE: 'GR', GREEK: 'GR', CY: 'CY', CYPRUS: 'CY', MT: 'MT', MALTA: 'MT', AL: 'AL', ALBANIA: 'AL',
  EXYU: 'EXYU', 'EX-YU': 'EXYU', YU: 'EXYU', BALKAN: 'EXYU', SERBIA: 'EXYU', CROATIA: 'EXYU', BOSNIA: 'EXYU', SLOVENIA: 'EXYU', MACEDONIA: 'EXYU', RS: 'EXYU', HR: 'EXYU', BA: 'EXYU', SI: 'EXYU', MK: 'EXYU', ME: 'EXYU',
  TR: 'TR', TURKEY: 'TR', TURKIYE: 'TR', TURKISH: 'TR', RU: 'RU', RUSSIA: 'RU', UA: 'UA', UKRAINE: 'UA', BY: 'BY',
  LT: 'LT', LITHUANIA: 'LT', LV: 'LV', LATVIA: 'LV', EE: 'EE', ESTONIA: 'EE', GE: 'GE', GEORGIA: 'GE', ARMENIA: 'AM', AZ: 'AZ', AZERBAIJAN: 'AZ',
  KU: 'KU', KURD: 'KU', KURDISTAN: 'KU', KURDISH: 'KU',
  ARAB: 'ARAB', ARABIC: 'ARAB', ARABE: 'ARAB', 'AR': 'ARAB', MENA: 'ARAB', SA: 'ARAB', KSA: 'ARAB', SAUDI: 'ARAB', QATAR: 'ARAB', KUWAIT: 'ARAB', LEBANON: 'ARAB', IRAQ: 'ARAB', SYRIA: 'ARAB', JORDAN: 'ARAB', OMAN: 'ARAB',
  AE: 'AE', UAE: 'AE', EMIRATES: 'AE', IL: 'IL', ISRAEL: 'IL', IR: 'IR', IRAN: 'IR', PERSIAN: 'IR', AFGHANISTAN: 'AFG',
  IN: 'IN', IND: 'IN', INDIA: 'IN', INDIAN: 'IN', HINDI: 'IN', TAMIL: 'IN', TELUGU: 'IN', PUNJABI: 'IN', PK: 'PK', PAKISTAN: 'PK', BD: 'BD', BANGLA: 'BD', BANGLADESH: 'BD',
  LK: 'LK', 'SRI LANKA': 'LK', NP: 'NP', NEPAL: 'NP',
  CN: 'CN', CHINA: 'CN', CHINESE: 'CN', HK: 'HK', 'HONG KONG': 'HK', TW: 'TW', TAIWAN: 'TW', JP: 'JP', JAPAN: 'JP', KR: 'KR', KOREA: 'KR',
  PH: 'PH', PHILIPPINES: 'PH', PHILIPPINE: 'PH', THAILLAND: 'TH', FILIPINO: 'PH', MY: 'MY', MALAYSIA: 'MY', MALASIA: 'MY', SG: 'SG', SINGAPORE: 'SG', TH: 'TH', THAILAND: 'TH',
  VN: 'VN', VIETNAM: 'VN', ID: 'ID', INDONESIA: 'ID',
  AF: 'AFR', AFRICA: 'AFR', AFRICAN: 'AFR', DSTV: 'AFR', ZA: 'ZA', 'SOUTH AFRICA': 'ZA', NG: 'NG', NIGERIA: 'NG', EG: 'EG', EGYPT: 'EG',
  MA: 'MA', MOROCCO: 'MA', MAROC: 'MA', DZ: 'DZ', ALGERIA: 'DZ', TN: 'TN', TUNISIA: 'TN',
  TURK: 'TR', TURKCE: 'TR', KZ: 'KZ', KAZAKHSTAN: 'KZ', EZIDXAN: 'KU', UZBEKISTAN: 'KZ',
  PANAMA: 'LATAM', BOLIVIA: 'LATAM', ECUADOR: 'LATAM', 'EL SALVADOR': 'LATAM', 'COSTA RICA': 'LATAM', HONDURAS: 'LATAM', PARAGUAY: 'LATAM',
  URUGUAY: 'LATAM', GUATEMALA: 'LATAM', NICARAGUA: 'LATAM', 'PUERTO RICO': 'CARIB', SURINAME: 'CARIB', HAITI: 'CARIB', DOMINICAN: 'CARIB',
  JAMAICA: 'CARIB', TRINIDAD: 'CARIB', CUBA: 'CARIB',
  MX: 'MX', MEXICO: 'MX', BR: 'BR', BRAZIL: 'BR', BRASIL: 'BR', ARGENTINA: 'AR', CO: 'CO', COLOMBIA: 'CO', CL: 'CL', CHILE: 'CL',
  PE: 'PE', PERU: 'PE', VE: 'VE', VENEZUELA: 'VE', LATIN: 'LATAM', LATINO: 'LATAM', LATAM: 'LATAM', CARIBBEAN: 'CARIB', CARIB: 'CARIB',
};
// Region prefixes that say nothing about the country ("EU | …", "AM | …").
const NOISE = new Set(['EU', 'EUR', 'EUROPE', 'AM', 'AS', 'ASIA', 'VIP', 'HD', 'FHD', 'UHD', 'SD', '4K', 'HEVC', 'TV', 'PLUS', 'NEW', 'LIVE', 'VOD']);
// iptv-org ids end in an ISO code: "BBCOne.uk@SD" → uk. Those codes mean the country itself.
const ISO = { uk: 'GB', gb: 'GB', ar: 'AR', ae: 'AE', sa: 'ARAB', qa: 'ARAB', kw: 'ARAB', lb: 'ARAB', iq: 'ARAB', sy: 'ARAB', jo: 'ARAB', om: 'ARAB', bh: 'ARAB', ye: 'ARAB', ps: 'ARAB', ly: 'ARAB', sd: 'ARAB', rs: 'EXYU', hr: 'EXYU', ba: 'EXYU', si: 'EXYU', mk: 'EXYU', me: 'EXYU', af: 'AFG' };

function lookup(word) {
  return WORDS[word] || (word.includes('-') ? WORDS[word.split('-').pop()] || WORDS[word.split('-')[0]] : null);
}

// Labels are split into segments at | : - [ ] ( ). A two-letter code only counts as the first
// word of a segment ("UK GENERAL", "AM | USA"), so ordinary words like IN, IT, NO or MY in
// "MOVIES IN 4K" aren't mistaken for countries. Longer names count anywhere.
function fromText(text) {
  // Strip accents so "ISRAËL" and "ESPAÑA" match.
  const up = ` ${String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase()} `;
  for (const w of ['UNITED KINGDOM', 'UNITED STATES', 'NEW ZEALAND', 'SOUTH AFRICA', 'HONG KONG', 'SRI LANKA', 'EL SALVADOR', 'COSTA RICA', 'PUERTO RICO']) if (up.includes(w)) return WORDS[w];
  for (const seg of up.split(/[|:\[\]()–]+|\s-\s/)) {
    const words = seg.trim().split(/\s+/).filter(Boolean);
    for (let i = 0; i < words.length; i++) {
      const word = words[i].replace(/[^A-Z0-9-]/g, '');
      if (!word || NOISE.has(word)) continue;
      if (word.length <= 2 && i > 0) continue;
      const cc = lookup(word);
      if (cc) return cc;
    }
  }
  return null;
}

const cache = new Map();
function groupCountry(group) {
  if (cache.has(group)) return cache.get(group);
  let cc = null;
  if (/24\s*\/\s*7/.test(group)) cc = '247';
  else cc = fromText(group);
  cache.set(group, cc);
  return cc;
}

// "UK| BBC ONE HD" → "BBC ONE HD" when the prefix is a country we recognise.
export function stripCountry(name) {
  const m = /^\s*([A-Za-z][A-Za-z-]{0,10})\s*[|:]\s*/.exec(name || '');
  return m && lookup(m[1].toUpperCase()) && name.length > m[0].length ? name.slice(m[0].length) : name;
}

// Country (or bucket) for one channel.
export function countryOf(ch) {
  const g = ch.group || '';
  const gc = groupCountry(g);
  if (gc === '247') return '247';
  // "UK| BBC 1 HD", "UEFA-UK| ITV 1 HD", "DE: Sky Atlantic"
  const pre = /^\s*([A-Za-z][A-Za-z-]{0,10})\s*[|:]/.exec(ch.name || '');
  if (pre) { const cc = lookup(pre[1].toUpperCase()); if (cc) return cc; }
  if (gc) return gc;
  const id = /\.([a-z]{2})(?:@|$)/i.exec(ch.tvgId || '');
  if (id) { const k = id[1].toLowerCase(); return ISO[k] || k.toUpperCase(); }
  if (/\b(PPV|EVENTS?|VIP|UFC|BOXING|WWE|F1|NFL|NBA|NHL|MLB|UEFA|FIFA)\b/i.test(g)) return 'PPV';
  return 'XX';
}

export function countryName(cc) { return (COUNTRIES[cc] || [cc])[0]; }
export function countryFlag(cc) { return (COUNTRIES[cc] || [null, '🏳️'])[1]; }

// Sensible order for a country's categories: main channels first, events and PPV last.
const RANK = [
  [/PPV|EVENT|VIP|50 ?FPS|4K|UHD/i, 11], [/GENERAL|MAIN|NATIONAL|FREEVIEW|TERRESTRIAL|BBC|ITV/i, 0], [/ENTERTAI|DRAMA|LIFESTYLE/i, 1], [/NEWS/i, 2],
  [/SPORT|FOOTBALL|SKY SPORTS|TNT|BT SPORT|DAZN/i, 3], [/CINEMA|MOVIE|FILM/i, 4], [/DOCUMENT|NATURE|HISTORY/i, 5],
  [/KIDS|CHILD|CARTOON|JUNIOR/i, 6], [/MUSIC/i, 7], [/LOCAL|REGION/i, 8], [/RELIG|FAITH/i, 9],
];
const ranks = new Map();
export function groupRank(name) {
  if (ranks.has(name)) return ranks.get(name);
  let r = 10;
  for (const [rx, n] of RANK) if (rx.test(name)) { r = n; break; }
  ranks.set(name, r);
  return r;
}
