// Streaming-service rows for Home: providers often file films and series under the service
// they came from ("[EN] NETFLIX", "[IT] DISNEY+"). Each service becomes one row, in the
// languages of the countries you chose.
import { S, isHidden, loadLazyGroup, isLazyGroup, visible, setSetting, getAccount, vodLangs, catTag } from './store.js';
import { normName } from './util.js';

// [key, name, category pattern, icon gradient, icon text, text colour, text size]
export const SERVICES = [
  ['netflix', 'Netflix', /NETFLIX/, ['#1A1A1A', '#000'], 'N', '#E50914', 36],
  ['disney', 'Disney+', /DISNEY/, ['#1F4FD8', '#0A1F6E'], 'Disney+', '#fff', 12.5],
  ['prime', 'Prime Video', /AMAZON|PRIME VIDEO|\bPRIME\b/, ['#1F2B38', '#0F171E'], 'prime', '#00A8E1', 16],
  ['apple', 'Apple TV+', /APPLE ?TV/, ['#2E2E2E', '#000'], 'tv+', '#fff', 20],
  ['hbo', 'HBO', /\bHBO\b/, ['#5B2BB5', '#240B52'], 'HBO', '#fff', 19],
  ['hulu', 'Hulu', /HULU/, ['#151719', '#000'], 'hulu', '#1CE783', 19],
  ['paramount', 'Paramount+', /PARAMOUNT/, ['#0A64FF', '#0033A0'], 'P+', '#fff', 21],
  ['peacock', 'Peacock', /PEACOCK/, ['#1A1A1A', '#000'], 'peacock', '#fff', 11.5],
  ['sky', 'Sky', /\bSKY\b/, ['#0B6FD6', '#D2153C'], 'sky', '#fff', 20],
  ['now', 'NOW', /\bNOW ?TV\b/, ['#11A39C', '#06615D'], 'NOW', '#fff', 18],
  ['britbox', 'BritBox', /BRITBOX/, ['#1E2347', '#0D0F1F'], 'BritBox', '#fff', 11.5],
  ['itvx', 'ITVX', /ITVX/, ['#1E1E1E', '#000'], 'ITVX', '#DEEB52', 17],
  ['iplayer', 'BBC iPlayer', /IPLAYER|\bBBC\b/, ['#F54997', '#B11F6A'], 'iPlayer', '#fff', 12.5],
  ['channel4', 'Channel 4', /CHANNEL ?4|\bALL ?4\b/, ['#2A2A2A', '#000'], '4', '#fff', 26],
  ['crunchyroll', 'Crunchyroll', /CRUNCHY/, ['#F47521', '#B4500D'], 'crunchy', '#fff', 11],
  ['marvel', 'Marvel', /MARVEL/, ['#EC1D24', '#8E0D12'], 'MARVEL', '#fff', 12],
  ['discovery', 'Discovery+', /DISCOVERY/, ['#1B5BD6', '#0B2F7A'], 'discovery+', '#fff', 9.5],
  ['showtime', 'Showtime', /SHOWTIME/, ['#B10000', '#5C0000'], 'SHO', '#fff', 19],
  ['starz', 'Starz', /STARZ/, ['#1A1A1A', '#000'], 'STARZ', '#fff', 13.5],
  ['shahid', 'Shahid', /SHAHID/, ['#12202E', '#000'], 'shahid', '#3BC07A', 13],
  ['mubi', 'MUBI', /MUBI/, ['#1A1A1A', '#000'], 'MUBI', '#fff', 15],
].map(([key, name, rx, grad, text, color, size]) => ({ key, name, rx, grad, text, color, size }));

// Languages to show: yours (Settings → Countries & languages), or English when nothing is set.
function prefs() { return vodLangs() || new Set(['EN', 'MULTI']); }
const tagOf = catTag;

// Services the library carries, in your order (Hold OK on a service card, or Settings → Home
// screen), with the ones you hid left out unless asked for.
export function serviceList({ all = false } = {}) {
  const found = serviceRows();
  const saved = S.settings.svcOrder || [];
  const pos = (k) => { const i = saved.indexOf(k); return i < 0 ? 1000 + SERVICES.findIndex((x) => x.key === k) : i; };
  found.sort((a, b) => pos(a.key) - pos(b.key));
  return all ? found : found.filter((x) => !(S.settings.svcHidden || []).includes(x.key));
}
export function moveService(key, delta) {
  const keys = serviceList({ all: true }).map((x) => x.key);
  const i = keys.indexOf(key), j = i + delta;
  if (i < 0 || j < 0 || j >= keys.length) return false;
  [keys[i], keys[j]] = [keys[j], keys[i]];
  setSetting('svcOrder', keys);
  return true;
}
export function setServiceHidden(key, hidden) {
  const set = new Set(S.settings.svcHidden || []);
  if (hidden) set.add(key); else set.delete(key);
  setSetting('svcHidden', [...set]);
}

// Services the library carries, each with its categories (your languages first, at most four).
export function serviceRows() {
  const want = prefs();
  const out = [];
  for (const svc of SERVICES) {
    const cats = [];
    for (const type of ['movie', 'series']) {
      for (const g of S.groups[type] || []) {
        if (isHidden(type, g.name)) continue;
        const bare = g.name.replace(/^\s*[\[(][^\])]+[\])]\s*/, '').toUpperCase();
        if (!svc.rx.test(bare)) continue;
        const tag = tagOf(g.name);
        const rank = !tag ? 1 : tag === 'MULTI' ? (want.has('MULTI') ? 1 : -1) : want.has(tag) ? 0 : -1;
        if (rank >= 0) cats.push({ type, name: g.name, rank });
      }
    }
    if (cats.length) out.push({ ...svc, cats: cats.sort((a, b) => a.rank - b.rank).slice(0, 4) });
  }
  return out;
}

// Newest titles across a service's categories, one copy of each title.
export async function serviceTitles(row, limit = Infinity) {
  const all = [];
  for (const c of row.cats) {
    let items;
    if (isLazyGroup(c.type, c.name)) items = await loadLazyGroup(c.type, c.name).catch(() => []);
    else items = (c.type === 'movie' ? S.movies : S.shows).filter((x) => x.group === c.name);
    all.push(...visible(c.type, items));
  }
  const seen = new Set();
  return all
    .sort((a, b) => (b.added || 0) - (a.added || 0))
    .filter((x) => { const k = normName(x.name); if (seen.has(k)) return false; seen.add(k); return true; })
    .slice(0, limit);
}

export function serviceIcon(svc) {
  const span = document.createElement('span');
  span.className = 'app-icon';
  const id = 'svc' + svc.key;
  span.innerHTML = `<svg viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${svc.grad[0]}"/><stop offset="1" stop-color="${svc.grad[1]}"/></linearGradient></defs><rect width="64" height="64" rx="15" fill="url(#${id})"/><text x="32" y="${32 + svc.size * 0.36}" text-anchor="middle" font-family="Manrope, system-ui, sans-serif" font-weight="800" font-size="${svc.size}" fill="${svc.color}" letter-spacing="-.3">${svc.text}</text></svg>`;
  return span;
}

// ---------- featured banner ----------
// A handful of new, well-rated titles for the Home banner: the provider's "new releases" or
// "top this year" categories in your languages, then your first streaming service, then
// whatever films and series are already loaded.
const FRESH = /NEW RELEASE|LATEST|RECENTLY ADDED|NOUVEAUT|TOP ?20\d\d|TRENDING|POPULAR/;
// `only` limits it to films ('movie') or series ('series'), for the Movies and Series pages.
export async function featuredTitles(n = 8, only = null) {
  const want = prefs();
  const pick = [];
  const isType = (x) => !only || (only === 'movie' ? x.type === 'movie' : x.type !== 'movie');
  for (const type of only ? [only] : ['movie', 'series']) {
    const g = (S.groups[type] || []).find((x) => {
      if (isHidden(type, x.name)) return false;
      const tag = tagOf(x.name), bare = x.name.replace(/^\s*[\[(][^\])]+[\])]\s*/, '').toUpperCase();
      return FRESH.test(bare) && (!tag || want.has(tag));
    });
    if (g) pick.push({ type, name: g.name });
  }
  let pool = [];
  for (const c of pick) {
    const items = isLazyGroup(c.type, c.name) ? await loadLazyGroup(c.type, c.name).catch(() => []) : (c.type === 'movie' ? S.movies : S.shows).filter((x) => x.group === c.name);
    pool.push(...visible(c.type, items));
  }
  const svc = serviceList()[0];
  if (pool.filter(isType).length < n && svc) pool.push(...await serviceTitles(svc, 60).catch(() => []));
  if (pool.filter(isType).length < n) pool.push(...visible('movie', S.movies), ...visible('series', S.shows));
  pool = pool.filter(isType);
  const year = new Date().getFullYear();
  const score = (x) => (x.rating || 5) + (x.year >= year - 1 ? 3 : 0) + (x.added ? Math.min(3, (x.added * 1000 - Date.now() + 60 * 86400000) / (20 * 86400000)) : 0);
  const seen = new Set();
  return pool
    .filter((x) => x.logo && (!x.rating || x.rating >= 6))
    .sort((a, b) => score(b) - score(a))
    .filter((x) => { const k = normName(x.name); if (seen.has(k)) return false; seen.add(k); return true; })
    .slice(0, n);
}

// Backdrop and plot for a featured title. Series carry them already; films ask the provider once.
export async function featuredDetails(it) {
  if (it.backdrop || it.plot || it.detailsTried || it.type !== 'movie' || !it.xc || !it.xc.vid) return it;
  it.detailsTried = true;
  const acc = getAccount(it.pl);
  if (!acc) return it;
  try {
    const { xtreamVodInfo } = await import('./xtream.js');
    const d = await xtreamVodInfo(acc, it);
    it.backdrop = d.backdrop; it.plot = d.plot; it.genre = d.genre || it.genre; it.dur = d.dur;
  } catch {}
  return it;
}
