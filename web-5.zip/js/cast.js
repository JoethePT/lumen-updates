// Casting films, episodes and live channels to a Chromecast or Google TV, from the phone and
// tablet app. The Android side (CastBridge.java) finds devices, connects and plays; this draws
// the device picker and the "now casting" bar, sends subtitle files along, and keeps resume
// points up to date while casting.
import { h, fmtDur, toast, srtToVtt } from './util.js';
import { icon } from './icons.js';
import { S, savePosition, getPosition, nowNext, ensureCatalog, catalogTitles, vodInfo, seriesInfo, catTag, LANG_NAMES, lookup } from './store.js';
import { menu } from './ui/common.js';
import { uploadSub } from './native.js';

const api = () => window.LumenCast || null;
export const castAvailable = () => { try { return !!(api() && api().available()); } catch { return false; } };

let current = null;     // the item being cast
let list = null;        // for live channels: the channel list, so the bar can change channel
let bar = null, poll = 0, waiting = null, retry = null, startAt = 0, errShown = false, errTicks = 0;
let alias = null;          // the title you chose, when another copy of it is playing instead
let tried = new Set();     // copies already tried for that title
let lastDevice = '';

const parse = (s, d) => { try { return JSON.parse(s); } catch { return d; } };
const status = () => parse(api().status(), { connected: false });
const devices = () => parse(api().devices(), []);
const isLive = (it) => it && it.type === 'live';

window.lumenCastEvent = (e) => {
  if (e.type === 'devices' && waiting) waiting();
  if (e.type === 'connecting') paintBar({ state: 'connecting' });
  if (e.type === 'connected') { toast(`Connected to ${e.text}`); startPolling(); }
  if (e.type === 'loaded') { retry = null; startPolling(); }
  if (e.type === 'held') held();
  // Live channels play on every Chromecast, so a channel that won't start is most likely the
  // provider still holding the last stream; a film or episode is most likely its file format.
  if (e.type === 'unplayable') { if (current && isLive(current)) held(); else unplayable(); }
  if (e.type === 'error') toast(e.text, { ms: 7000 });
  if (e.type === 'ended') stopBar();
};

// One-stream subscriptions: the provider holds the last stream for a minute or two after it
// stops, and refuses a new one meanwhile. Try again a few times before giving up.
function held() {
  if (!current) return;
  retry = retry && retry.item === current ? retry : { n: 0, item: current };
  if (retry.n < 3) {
    const wait = [30, 45, 60][retry.n++];
    paintBar({ state: 'waiting', wait });
    setTimeout(() => { if (current === retry?.item) castItem(current, startAt, alias); }, wait * 1000);
    return;
  }
  retry = null;
  toast('Your provider is still busy with another stream. Stop playing on other devices, wait a minute, then cast again.', { ms: 8000 });
  paintBar({ state: 'error' });
}

async function unplayable() {
  if (errShown) return;
  errShown = true;
  paintBar({ state: 'error' });
  const chosen = alias || current;
  await ensureFmt(current);
  learn(formatOf(current));
  tried.add(current.id);
  const alt = await findCopy(chosen);
  if (alt && (alias || current) === chosen) {
    toast('Your TV can’t play this copy. Casting another copy of it that your TV can play…', { ms: 6000 });
    return castItem(alt, startAt, chosen);
  }
  if ((alias || current) !== chosen) return;
  toast(`Your TV couldn’t play this${tried.size > 1 ? ' or the other copies your provider has' : ''}. ${castProblem(current) || 'It’s probably in a format Chromecast can’t play: MKV files with HEVC video or surround sound are the usual cause.'} You can still watch it on this device.`, { ms: 10000 });
}

// What the provider says about a file's format, and what a Chromecast will make of it.
function formatOf(item) {
  if (!item) return {};
  const info = item.fmt || (S.meta.get('vod:' + item.id) || {}).fmt || {};
  const ext = (String(item.url || '').toLowerCase().replace(/[?#].*$/, '').match(/\.(\w+)$/) || [])[1] || '';
  return { ...info, ext };
}

export function castProblem(item) {
  if (!item || isLive(item)) return null;
  const f = formatOf(item);
  if (/^(avi|mpg|mpeg|wmv|flv|m2ts)$/.test(f.ext)) return `It’s an ${f.ext.toUpperCase()} file, which Chromecasts can’t play.`;
  if (/^(dts|truehd|mlp)/.test(f.a || '')) return `Its sound is ${f.a.startsWith('dts') ? 'DTS' : 'Dolby TrueHD'}, which Chromecasts can’t play.`;
  if (/hevc|h265/.test(f.v || '')) return `It’s ${f.bit10 ? '10-bit ' : ''}HEVC video, which only ${f.bit10 ? 'the 4K Chromecast with Google TV and Google TV Streamer' : 'Chromecast Ultra, Chromecast with Google TV and Google TV Streamer'} can play.`;
  if (/mpeg4|msmpeg|xvid|divx|vc1|wmv/.test(f.v || '')) return 'Its video format (DivX or Xvid) isn’t one Chromecasts can play.';
  return null;
}

// The Cast button: pick a device (or use the one already connected), then play there.
export function castButton(item, getStart, cls = '.btn') {
  if (!castAvailable()) return null;
  const b = h('button' + cls, { 'aria-label': 'Cast', onclick: () => chooseAndCast(b, item, getStart) }, icon('cast'), cls === '.btn' ? 'Cast' : null);
  return b;
}

export function chooseAndCast(anchor, item, getStart = () => (isLive(item) ? 0 : getPosition(item.id)), channels = null) {
  if (isLive(item)) list = channels && channels.length ? channels : null;
  if (status().connected) return castItem(item, getStart());
  const found = devices();
  // Devices can take a moment to show up after the app opens: open the list when they do.
  if (!found.length) {
    toast('Looking for Chromecasts on your Wi-Fi…');
    waiting = () => { if (devices().length && anchor.isConnected) { waiting = null; chooseAndCast(anchor, item, getStart, channels); } };
    setTimeout(() => { if (waiting) { waiting = null; toast('No Chromecast found. Check it’s on and on the same Wi-Fi as this device.', { ms: 6000 }); } }, 12000);
    return;
  }
  menu(anchor, 'Cast to', found.map((d) => ({ label: d.name, run: async () => {
    lastDevice = d.name;
    paintBar({ state: 'connecting', device: d.name });
    api().connect(d.id);
    castItem(item, getStart());
  } })));
}

async function payload(item, start) {
  const live = isLive(item);
  // Chromecasts play live channels as HLS; Xtream providers serve every channel both ways.
  let url = item.url;
  if (live && item.xc && /\.ts(\?|$)/.test(url)) url = url.replace(/\.ts(\?|$)/, '.m3u8$1');
  const { now } = live ? nowNext(item) : {};
  const { subFilesFor } = await import('./ui/player-ui.js');
  const subs = subFilesFor(item.id).map((s, i, a) => ({ ...s, on: i === a.length - 1 }));
  return {
    url, live,
    title: live ? item.name : item.ep ? item.ep.show || item.name : item.name,
    subtitle: live ? (now ? now[2] : item.group || '') : item.ep ? `Season ${item.ep.s}, episode ${item.ep.e}${item.ep.title ? ': ' + item.ep.title : ''}` : (item.year ? String(item.year) : ''),
    poster: item.logo || '', start: start || 0, episode: !!item.ep,
    subs, subScale: (S.settings.subSize || 100) / 100, subBox: !!S.settings.subBg,
  };
}

// ---------- finding a copy the TV can play ----------
// Providers often list a title several times (4K, FHD, HD; different categories). When the
// Chromecast can't play one, look for another copy in the same language whose format it can.
const device = () => { try { return status().device || lastDevice; } catch { return lastDevice; } };
const isHevc = (f) => /hevc|h265/.test(f.v || '');
function limits() {
  try { return JSON.parse(localStorage.getItem('lumen.castLimits') || '{}')[device()] || {}; } catch { return {}; }
}
// Remember what this Chromecast couldn't play, so next time Lumen goes straight to a copy it can.
function learn(f) {
  if (!isHevc(f) || !device()) return;
  try {
    const all = JSON.parse(localStorage.getItem('lumen.castLimits') || '{}');
    const d = all[device()] || {};
    if (f.bit10) d.no10 = true; else d.noHevc = true;
    all[device()] = d;
    localStorage.setItem('lumen.castLimits', JSON.stringify(all));
  } catch {}
}
function wontPlay(f) {
  if (/^(avi|mpg|mpeg|wmv|flv|m2ts)$/.test(f.ext || '') || /^(dts|truehd|mlp)/.test(f.a || '') || /mpeg4|msmpeg|xvid|divx|vc1|wmv/.test(f.v || '')) return true;
  const L = limits();
  return isHevc(f) && !!(L.noHevc || (f.bit10 && (L.no10 || L.noHevc)));
}

const QWORDS = /\b(SD|HD|FHD|UHD|4K|8K|HEVC|H\.?26[45]|X26[45]|\d{3,4}P|HDR10?|DV|10 ?BIT|MULTI|SUBS?|DUAL|VOSTFR)\b/gi;
function titleKey(name) {
  return String(name || '')
    .replace(/^\s*(?:\[[^\]]{1,12}\]|\|[^|]{1,12}\||[A-Z]{2,5}\s*(?:\||[-:]\s))\s*/, '')
    .replace(/[([]\s*(19|20)\d\d\s*[)\]]/g, ' ')
    .replace(QWORDS, ' ')
    .toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
}
const yearOf = (it) => Number(it.year) || Number((/[([]\s*((?:19|20)\d\d)\s*[)\]]/.exec(it.name || '') || [])[1]) || 0;
const langOf = (it) => { const t = catTag(it.group) || catTag(it.name); return t === 'MULTI' ? '' : LANG_NAMES[t] || t; };
const sameLang = (a, b) => !langOf(a) || !langOf(b) || langOf(a) === langOf(b);

// Titles opened from Continue watching may not have their format yet: ask the provider.
async function ensureFmt(item) {
  if (!item || item.fmt || isLive(item)) return;
  try {
    if (item.ep && item.showId) {
      const show = lookup(item.showId);
      const ep = show && (await seriesInfo(show)).episodes.find((e) => e.id === item.id);
      if (ep && ep.fmt) item.fmt = ep.fmt;
    } else if (item.xc) {
      const info = await vodInfo(item);
      if (info && info.fmt) item.fmt = info.fmt;
    }
  } catch {}
}

async function findCopy(item) {
  if (!item || isLive(item)) return null;
  // The first search downloads the film and series lists (then keeps them for a day).
  toast('Looking for a copy your TV can play…', { ms: 4000 });
  await Promise.race([ensureCatalog().catch(() => {}), new Promise((r) => setTimeout(r, 25000))]);
  const good = (c, f) => f && (f.v || f.a) && !wontPlay({ ...f, ext: formatOf(c).ext });
  // H.264 first: every Chromecast plays it.
  const rank = (f) => (/h264|avc/.test(f.v || '') ? 0 : isHevc(f) ? 2 : 1);
  const pickBest = (list) => list.sort((a, b) => rank(a.f) - rank(b.f))[0]?.c || null;
  if (item.ep) {
    const key = titleKey(item.ep.show);
    const shows = [...(S.shows || []), ...catalogTitles('series')]
      .filter((x, i, a) => x.id !== item.showId && titleKey(x.name) === key && sameLang(x, item) && a.findIndex((y) => y.id === x.id) === i)
      .slice(0, 5);
    const ok = [];
    for (const show of shows) {
      try {
        const info = await seriesInfo(show);
        const ep = info.episodes.find((e) => e.ep && e.ep.s === item.ep.s && e.ep.e === item.ep.e);
        if (ep && !tried.has(ep.id) && good(ep, ep.fmt)) ok.push({ c: ep, f: ep.fmt });
      } catch {}
    }
    return pickBest(ok);
  }
  const key = titleKey(item.name), year = yearOf(item);
  const films = [...(S.movies || []), ...catalogTitles('movie')]
    .filter((x, i, a) => x.id !== item.id && !tried.has(x.id) && titleKey(x.name) === key && sameLang(x, item)
      && (!year || !yearOf(x) || yearOf(x) === year) && a.findIndex((y) => y.id === x.id) === i)
    .slice(0, 8);
  const ok = [];
  for (const c of films) {
    const info = await vodInfo(c).catch(() => null);
    if (info && good(c, info.fmt)) ok.push({ c, f: info.fmt });
  }
  return pickBest(ok);
}

// Formats that certainly won't play: say so up front, but still try (a newer device may cope).
function warnFormat(item) {
  const why = castProblem(item);
  if (why && /can’t play/.test(why)) toast(`${why} Trying anyway…`, { ms: 6000 });
}

// chosen: the title you picked, when this is another copy of it.
export async function castItem(item, start, chosen = null) {
  if (!chosen) {
    if (item !== (alias || current)) { tried = new Set(); }
    alias = null;
    // Known not to play here (its format, or what this TV turned down before): find a copy that will.
    if (Object.keys(limits()).length) await ensureFmt(item);
    if (wontPlay(formatOf(item))) {
      const alt = await findCopy(item);
      if (alt) { toast('Casting a copy of this that your TV can play', { ms: 5000 }); chosen = item; item = alt; }
    }
  }
  alias = chosen;
  if (item !== current) { retry = null; if (!chosen) warnFormat(item); }
  current = item; startAt = start || 0; errShown = false;
  paintBar({ state: 'buffering' });
  api().load(JSON.stringify(await payload(item, start)));
}

function zap(d) {
  if (!list || !current) return;
  const i = list.findIndex((c) => c.id === current.id);
  const next = list[(i + d + list.length) % list.length];
  retry = null;
  castItem(next, 0);
}

// ---------- subtitles while casting ----------
function subtitlesMenu(anchor) {
  const t = parse(api().tracks(), { tracks: [], active: [] });
  const on = new Set(t.active);
  const items = [{ label: 'Off', on: !t.tracks.some((x) => on.has(x.id)), run: () => api().setTrack(-1) }];
  for (const x of t.tracks) items.push({ label: x.name || (x.lang && x.lang !== 'und' ? x.lang.toUpperCase() : 'Subtitles'), on: on.has(x.id), run: () => api().setTrack(x.id) });
  items.push({ label: 'Load subtitle file…', run: () => pickSubFile() });
  if (!t.tracks.length) items.push({ label: 'Subtitles inside the film file can’t be shown on a Chromecast; load a file instead.', run: () => {} });
  menu(anchor, 'Subtitles on your TV', items);
}

function pickSubFile() {
  const inp = h('input', { type: 'file', accept: '.srt,.vtt,text/vtt' });
  inp.onchange = async () => {
    const f = inp.files[0];
    if (!f) return;
    try {
      const sub = await uploadSub(srtToVtt(await f.text()));
      api().addSub(JSON.stringify({ url: sub.lan, label: f.name.replace(/\.\w+$/, '') }));
      toast('Subtitles sent to your TV');
    } catch (e) { toast(e.message || 'Couldn’t load the subtitle file.'); }
  };
  inp.click();
}

// ---------- the "now casting" bar ----------
function startPolling() {
  clearInterval(poll);
  const tick = () => {
    const st = status();
    if (!st.connected) { stopBar(); return; }
    // The phone may still be offering the file under another type: wait a few seconds.
    errTicks = st.state === 'error' ? errTicks + 1 : 0;
    if (errTicks >= 5 && current && !isLive(current)) unplayable();
    paintBar(st);
    // Keep resume points while casting, so Continue watching picks up where the TV left off.
    if (current && !isLive(current) && st.duration > 60 && st.position > 5) savePosition(alias || current, st.position, st.duration);
  };
  tick();
  poll = setInterval(tick, 1000);
}

function stopBar() {
  clearInterval(poll); poll = 0;
  if (bar) { bar.remove(); bar = null; }
  document.documentElement.classList.remove('casting');
  current = null; list = null; retry = null; alias = null;
}

function paintBar(st) {
  if (!bar) {
    bar = h('div.cast-bar.glass-strong');
    document.body.append(bar);
    document.documentElement.classList.add('casting');
  }
  const live = isLive(current) || st.live;
  const title = (current && (live ? current.name : current.ep ? current.ep.show || current.name : current.name)) || st.title || 'Casting';
  const where = st.device || 'your TV';
  const state = st.state === 'connecting' ? `Connecting to ${where}…`
    : st.state === 'waiting' ? `Your provider is still holding the last stream. Trying again in ${st.wait} s…`
    : st.state === 'buffering' ? 'Loading on your TV…'
    : st.state === 'error' ? 'Your TV couldn’t play this'
    : `${st.state === 'paused' ? 'Paused' : live ? 'Live' : 'Playing'} on ${where}`;
  const now = live && current ? nowNext(current).now : null;
  const pct = !live && st.duration ? Math.min(100, (st.position / st.duration) * 100) : 0;
  const btn = (label, ic, fn) => h('button.btn.btn-icon', { 'aria-label': label, onclick: fn }, icon(ic));
  bar.replaceChildren(
    h('div.cb-icon', icon('cast')),
    h('div.cb-txt', h('div.cb-t', title),
      h('div.cb-d', state + (live ? (now ? ` · ${now[2]}` : '') : st.duration ? ` · ${fmtDur(st.position)} / ${fmtDur(st.duration)}` : '')),
      live ? null : h('div.bar', h('i', { style: { width: pct + '%' } }))),
    h('div.cb-btns',
      live && list ? btn('Previous channel', 'chDown', () => zap(-1)) : null,
      live ? null : btn('Back 10 seconds', 'back10', () => api().control('seekBy', -10)),
      btn(st.state === 'paused' ? 'Play' : 'Pause', st.state === 'paused' ? 'play' : 'pause', () => api().control('toggle', 0)),
      live ? null : btn('Forward 10 seconds', 'fwd10', () => api().control('seekBy', 10)),
      live && list ? btn('Next channel', 'chUp', () => zap(1)) : null,
      btn('Subtitles', 'cc', (e) => subtitlesMenu(e.currentTarget)),
      btn('Stop casting', 'close', () => { api().control('stop', 0); stopBar(); }),
    ),
  );
}

// If the app reopens while still casting, show the bar again.
if (castAvailable()) setTimeout(() => { if (status().connected) startPolling(); }, 1500);
